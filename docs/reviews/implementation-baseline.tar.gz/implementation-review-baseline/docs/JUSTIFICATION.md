# Why this design

Status: implementation rationale. Related: [requirements](SPEC.md), [design](DESIGN.md).

## Decision summary

| Decision | Why | Consequence and example |
|---|---|---|
| Four skills, ten internal prompts | Match four user activities without making discovery a ten-command checklist | Design drafting and design review share context rules but have separate instructions |
| Self-contained bundles | A user may install only one skill | Copying stage-development must retain its stage/review templates; no cross-skill relative dependency |
| On-demand references | Users complained about large mixed documents | A design request loads design material, not release instructions or an interview manual |
| Separate design from stage plan | Reasoning and execution answer different questions | Changing a stage order need not duplicate the architectural argument |
| Fixed review content | Concurrent edits can invalidate review and test evidence | A formatter changing staged code requires inspection and fresh relevant checks |
| Human/agent review status is explicit | Agent confidence is not human approval | A stage waits for human review unless an autonomous policy was actually requested |
| Report coverage without an arbitrary threshold | Execution coverage cannot prove meaningful assertions | Inspect an uncovered error path; never label 100% coverage proof of correctness |
| Root entry documents have separate audiences | Mixed README content makes both usage and maintenance harder | Test counts go to evidence, significant behavior changes go to CHANGELOG |
| Version/release is separate from ordinary commits | Multiple commits may belong to one feature or release | Prepare one version update; tag the verified merged version, not each stage |

## Alternatives and limits

A single large skill would simplify installation but make every invocation load unrelated workflow detail. Ten standalone skills would make operation boundaries explicit but increase discovery overhead and repeated context rules. Four self-contained bundles are the chosen compromise.

Cross-folder shared runtime templates would reduce duplication but break independent installation. Instead, each asset has a clear owner. Short shared review principles may be repeated; the repository documentation explains the overall contract without becoming a required runtime dependency.

A deterministic state machine or automatic PR/release bot could enforce more transitions, but would add integration, authorization and persistence complexity. This version uses prompts plus explicit evidence. It does not promise strong isolation between roles in one context; independent review requires a separate context.

Repository tests establish packaging and checking behavior. Fresh-agent exercises provide limited behavioral evidence. Neither proves all future reasoning or confirms VS Code UI discovery on every machine. Such limitations belong in [validation records](VALIDATION.md).

## Sources

The owner's [original workflow](sources/user-workflow.md) sets the requirements. Tool facts were checked against [official references](SOURCES.md). Interview reports and proprietary/source interview materials are outside this library's content.
