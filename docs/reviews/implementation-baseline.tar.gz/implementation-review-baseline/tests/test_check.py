import shutil
import subprocess
import sys
from pathlib import Path

import pytest

from tools.check import link_errors, validate_bundle, validate_repository

ROOT = Path(__file__).resolve().parents[1]


@pytest.fixture
def bundle(tmp_path):
    path = tmp_path / "example-skill"
    path.mkdir()
    (path / "SKILL.md").write_text(
        "---\nname: example-skill\ndescription: Review a sample change.\n---\n"
        "# Example\n\nRead [rules](rules.md#behavior).\n"
    )
    (path / "rules.md").write_text("# Behavior\n\nPreserve existing behavior.\n")
    return path


def test_standalone_copy_preserves_all_skill_resources(tmp_path):
    for source in (ROOT / "skills").iterdir():
        if source.is_dir():
            target = tmp_path / source.name
            shutil.copytree(source, target)
            assert validate_bundle(target) == []


def test_repository_passes():
    assert validate_repository(ROOT) == []


def test_missing_linked_resource_is_rejected(bundle):
    (bundle / "rules.md").unlink()
    assert any("missing resource" in e for e in validate_bundle(bundle))


def test_existing_resource_outside_bundle_is_rejected(bundle):
    (bundle.parent / "outside.md").write_text("# Outside\n")
    (bundle / "rules.md").write_text("[external dependency](../outside.md)\n")
    assert any("escapes bundle" in e for e in validate_bundle(bundle))


def test_invalid_heading_is_rejected(bundle):
    (bundle / "rules.md").write_text("# Different heading\n")
    assert any("missing heading" in e for e in validate_bundle(bundle))


def test_examples_do_not_create_spurious_links(bundle):
    (bundle / "rules.md").write_text("# Behavior\n```md\n[example](absent.md)\n```\n")
    assert validate_bundle(bundle) == []


@pytest.mark.parametrize(
    "frontmatter",
    ["no frontmatter", "---\n[unclosed\n---\n", "---\n- a list\n---\n"],
)
def test_invalid_metadata_is_rejected(bundle, frontmatter):
    (bundle / "SKILL.md").write_text(frontmatter)
    assert validate_bundle(bundle)


def test_missing_entrypoint_is_rejected(bundle):
    (bundle / "SKILL.md").unlink()
    assert any("missing SKILL.md" in e for e in validate_bundle(bundle))


def test_invalid_name_and_description_are_rejected(bundle):
    (bundle / "SKILL.md").write_text("---\nname: Wrong_Name\ndescription: []\n---\n")
    assert len(validate_bundle(bundle)) == 2


def test_external_and_broken_symlinks_are_rejected(bundle):
    (bundle / "external").symlink_to(bundle.parent)
    (bundle / "broken").symlink_to(bundle / "absent")
    assert sum("bundle symlink" in e for e in validate_bundle(bundle)) == 2


def test_invalid_ui_metadata_is_rejected(bundle):
    (bundle / "agents").mkdir()
    ui = bundle / "agents" / "openai.yaml"
    ui.write_text("interface: {}\n")
    assert any("interface metadata" in e for e in validate_bundle(bundle))
    ui.write_text(
        "interface:\n  default_prompt: no skill name\n  short_description: x\n"
    )
    assert any("invocation prompt" in e for e in validate_bundle(bundle))


def test_web_links_are_not_treated_as_local_files(bundle):
    (bundle / "rules.md").write_text("# Behavior\n[docs](https://example.com/rules)\n")
    assert link_errors(bundle / "rules.md", bundle) == []


def test_empty_repository_exits_unsuccessfully(tmp_path):
    result = subprocess.run(
        [sys.executable, str(ROOT / "tools" / "check.py"), str(tmp_path)],
        text=True,
        capture_output=True,
        timeout=10,
    )
    assert result.returncode == 1
    assert "no skill bundles" in result.stdout


def test_broken_discovery_link_is_rejected(tmp_path, bundle):
    root = tmp_path / "repo"
    shutil.copytree(bundle, root / "skills" / bundle.name)
    assert any("discovery link" in e for e in validate_repository(root))


def test_cli_accepts_complete_repository():
    result = subprocess.run(
        [sys.executable, str(ROOT / "tools" / "check.py")],
        text=True,
        capture_output=True,
        timeout=10,
    )
    assert result.returncode == 0, result.stdout + result.stderr
