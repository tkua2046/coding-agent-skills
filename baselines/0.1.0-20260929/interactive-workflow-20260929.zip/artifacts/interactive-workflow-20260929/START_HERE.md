# VS Code workflow trial — ready, not run

**Pending:** the Mac was locked when computer control tried to access VS Code.
No interactive agent task has started. The fixture's three original tests and
installed local hook pass; all 39 supplied skill files are unchanged.

Open this standalone practice project in VS Code:

`/Users/tk/Documents/coding-agent-skills-tryout-20260929`

1. Use the installed Codex extension with normal settings. Record the visible model.
2. Start a new project conversation with [the first request](01-request.md).
3. After the first candidate, send [the clarification](02-clarification.md) in the
   same conversation. Do not silently skip a failure or restart for a better result.
4. Keep required independent review and any justified repair within the declared
   overall budget. Human acceptance remains separate.

[The reviewed proposal](proposal.md) defines scope and acceptance. The original
review and pre-review proposal are retained beside it. The external CLI checker
tests behavior; it cannot judge documentation, review closure or unnecessary work.

Nothing is globally installed or pushed. Only this practice fixture has a local
baseline commit; the source repository has no new commit. Do not use this prepared
project as evidence that UI operation or skill behavior has already passed.
