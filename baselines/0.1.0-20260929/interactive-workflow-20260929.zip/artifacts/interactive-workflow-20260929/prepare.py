"""Prepare a project-local UI trial without running a model or changing settings."""
from pathlib import Path
import json
import subprocess
import sys

from tools import canary

repo = Path.cwd()
campaign = repo / "artifacts/interactive-workflow-20260929"
workspace = Path("/Users/tk/Documents/coding-agent-skills-tryout-20260929")
assert not workspace.exists(), "Preserve prior attempts; do not overwrite a fixture"
assert (campaign / "proposal-review-original.json").is_file()
base = repo / "evals/cases/smoke-version-prepared/fixture"
original = canary.files(base)
files = {name: original[name] for name in (
    "inventory_report.py", "tests/test_inventory_report.py", "examples/stock.csv",
    "VERSION", "CHANGELOG.md",
)}
notes = {
    ".gitignore": "__pycache__/\n*.pyc\n",
    "AGENTS.md": """# Inventory report project

Use applicable project-local skills in `.agents/skills` for the requested work.
The existing design owns choices; the plan owns pending outcomes and current status.
README owns usage; DEVNOTES owns checks; CHANGELOG owns significant completed impact.
Preserve original request/history files and supplied skills and hook.
Run the installed gate for changed behavior. Independent code review is required
before acceptance; self-review alone does not satisfy it. The supervisor supplies
that separate reviewer after the candidate is ready. Keep human acceptance pending.
No commit, tag, release, dependency installation, external service or unrelated
configuration change is requested. Work only in this practice project.
""",
    "README.md": """# Inventory Report

Summarize warehouse stock by SKU. Repeated SKUs are summed and sorted; quantities
must be nonnegative integers. Invalid input rejects the entire report. String SKU
identity, including leading zeroes, survives both formats.

```sh
python3 inventory_report.py examples/stock.csv
python3 inventory_report.py examples/stock.csv --format json
```

CSV is the default; JSON is opt-in. See DEVNOTES.md for checks and docs/PLAN.md for
delivery status.
""",
    "DEVNOTES.md": """# Development

Python standard library only. The installed pre-commit hook runs unittest discovery
and fails on zero collected tests. Run the same gate without creating a commit:

```sh
python3 hooks/pre-commit
```

Focused checks can use `python3 -m unittest discover -s tests -v`. An unchanged full
suite need not run twice merely to provide two command names. VERSION changes only
for an authorized release; completed feature impact belongs under Unreleased.
""",
    "docs/ORIGINAL.md": """# Accepted requirements

Read a CSV with exactly sku,quantity headers and nonnegative integer quantities.
Validate the complete input before returning any report. Sum repeated SKUs, preserve
SKU strings and sort by SKU. Default CSV and optional compact JSON end in a newline.
Malformed input exits 2 with an error on stderr and no stdout. Empty input after a
valid header produces the format's empty report. Existing summarize(text, format)
callers must remain compatible. Version 1.3.0 already provides this behavior.
""",
    "docs/DESIGN.md": """# Inventory report design

Accepted D1: validate all rows, aggregate by exact SKU string, then render sorted
totals. Complete validation before stdout means a later malformed row cannot leave
a misleading partial report. Summarize owns the in-memory result; main owns file I/O.

Accepted D2: CSV stays the default. Opt-in JSON uses the same totals and preserves
SKU types. For rows `001,2`, `A-7,0`, `001,3`, CSV emits `001,5` then `A-7,0`;
JSON emits quantities 5 and 0 with string SKUs. No state persists between calls.

Completed delivery history is in history/completed.md. PLAN.md owns current status.
""",
    "docs/PLAN.md": """# Delivery plan

Current state: D1 CSV validation/aggregation and D2 opt-in JSON are complete.
No work is pending before the new request. See history/completed.md for accepted
outcomes; DEVNOTES.md owns the test gate. New delivery must preserve existing callers
and default output. Keep future acceptance separate from completed check evidence.
""",
    "docs/history/completed.md": """# Completed baseline

D1 / 1.2.0: reject malformed inventory before producing output; aggregate and sort
SKU totals. D2 / 1.3.0: opt-in JSON preserves SKU strings and integer quantities;
default CSV remains unchanged. These are supplied accepted fixture facts, not a
claim that the trial agent or supervisor performed an earlier human review.
""",
}
files.update({name: content.encode() for name, content in notes.items()})
files["hooks/pre-commit"] = (repo / "evals/cases/bounded-delivery/fixture/hooks/pre-commit").read_bytes()
skills = canary.skill_files(repo, ["feature-design", "implementation-plan", "stage-development", "dev-workflow"])
files.update({".agents/" + name: data for name, data in skills.items()})
workspace.mkdir()
head = canary.init_fixture(workspace, files)
hook = workspace / ".git/hooks/pre-commit"
hook.write_bytes(files["hooks/pre-commit"])
hook.chmod(0o755)
canary.write_files(campaign / "baseline", files)
canary.save(campaign / "baseline-sha256.json", canary.hashes(files))
canary.save(campaign / "canonical-skills-sha256.json", canary.hashes(skills))
canary.save(campaign / "workspace.json", {"path": str(workspace), "fixture_head": head, "ui_task_started": False})
checks = {}
for name, command in (
    ("installed-hook", [sys.executable, ".git/hooks/pre-commit"]),
    ("default-csv", [sys.executable, "inventory_report.py", "examples/stock.csv"]),
    ("opt-in-json", [sys.executable, "inventory_report.py", "examples/stock.csv", "--format", "json"]),
):
    result = subprocess.run(command, cwd=workspace, capture_output=True, text=True, timeout=30)
    checks[name] = {"command": command, "exit_code": result.returncode, "stdout": result.stdout, "stderr": result.stderr}
    assert result.returncode == 0, checks[name]
assert "Ran 3 tests" in checks["installed-hook"]["stderr"]
assert hook.read_bytes() == files["hooks/pre-commit"]
assert canary.git(workspace, "status", "--porcelain") == ""
canary.save(campaign / "baseline-checks.json", checks)
canary.save(campaign / "preparation-result.json", {
    "baseline_tests": 3, "installed_hook_passed": True,
    "fixture_git_clean": True, "skill_files": len(skills),
    "source_of_code_tests": str(base.relative_to(repo)),
    "project_docs": "Adapted prospectively for this diagnostic; not historical production artifacts",
    "runtime_skill_changes": 0, "worker_calls": 0, "ui_task_started": False,
})
print(json.dumps({"workspace": str(workspace), "baseline_tests": 3, "skill_files": len(skills), "ui_task_started": False}))
