"""Independent observable CLI checks; not a skill-quality or review grader."""
import argparse
import json
from pathlib import Path
import subprocess
import sys
import tempfile

parser = argparse.ArgumentParser()
parser.add_argument("workspace", type=Path)
parser.add_argument("--baseline-control", action="store_true")
args = parser.parse_args()
workspace = args.workspace.resolve()
source = "sku,quantity\n001,2\nB,4\n001,3\nZ,0\n"
all_csv = "sku,quantity\n001,5\nB,4\nZ,0\n"
all_json = '[{"sku":"001","quantity":5},{"sku":"B","quantity":4},{"sku":"Z","quantity":0}]\n'
checks = [
    ("default-csv", source, [], 0, all_csv),
    ("existing-json", source, ["--format", "json"], 0, all_json),
    ("aggregated-equality-csv", source, ["--min-quantity", "5"], 0, "sku,quantity\n001,5\n"),
    ("aggregated-equality-json", source, ["--min-quantity", "5", "--format", "json"], 0, '[{"sku":"001","quantity":5}]\n'),
    ("zero-keeps-zero", source, ["--min-quantity", "0"], 0, all_csv),
    ("empty-csv", source, ["--min-quantity", "6"], 0, "sku,quantity\n"),
    ("empty-json", source, ["--min-quantity", "6", "--format", "json"], 0, "[]\n"),
    ("invalid-row-cannot-hide", "sku,quantity\nA,1\nB,-1\n", ["--min-quantity", "99"], 2, ""),
    ("invalid-threshold-negative", source, ["--min-quantity", "-1"], 2, ""),
    ("invalid-threshold-fraction", source, ["--min-quantity", "1.5"], 2, ""),
    ("header-only-json", "sku,quantity\n", ["--min-quantity", "0", "--format", "json"], 0, "[]\n"),
]
results = []
with tempfile.TemporaryDirectory(prefix="inventory-cli-check-") as tmp:
    input_path = Path(tmp) / "input.csv"
    for name, text, flags, exit_code, stdout in checks:
        input_path.write_text(text)
        command = [sys.executable, "-B", str(workspace / "inventory_report.py"), str(input_path), *flags]
        result = subprocess.run(command, cwd=workspace, text=True, capture_output=True, timeout=20)
        passed = result.returncode == exit_code and result.stdout == stdout
        passed = passed and (bool(result.stderr.strip()) if exit_code else not result.stderr)
        results.append({"name": name, "passed": passed, "exit_code": result.returncode, "stdout": result.stdout, "stderr": result.stderr, "expected_exit": exit_code, "expected_stdout": stdout})

if args.baseline_control:
    # Baseline must preserve old behavior and reject the new successful operation.
    expected = {row[0] for row in checks if row[3] == 0 and "--min-quantity" in row[2]}
    failed = {row["name"] for row in results if not row["passed"]}
    accepted = failed == expected and bool(expected)
    status = "baseline-negative-control-pass" if accepted else "baseline-control-fail"
else:
    accepted = all(row["passed"] for row in results)
    status = "functional-pass" if accepted else "functional-fail"
print(json.dumps({"status": status, "mode": "fixture-control" if args.baseline_control else "candidate", "results": results}, indent=2))
sys.exit(0 if accepted else 1)
