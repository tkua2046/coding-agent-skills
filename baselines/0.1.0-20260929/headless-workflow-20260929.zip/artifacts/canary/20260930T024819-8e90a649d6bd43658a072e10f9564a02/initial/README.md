# Inventory Report

Summarize warehouse stock by SKU. Repeated SKUs are summed and sorted; quantities
must be nonnegative integers. Invalid input rejects the entire report. String SKU
identity, including leading zeroes, survives both formats.

```sh
python3 inventory_report.py examples/stock.csv
python3 inventory_report.py examples/stock.csv --format json
```

CSV is the default; JSON is opt-in. See DEVNOTES.md for checks and docs/PLAN.md for
delivery status.
