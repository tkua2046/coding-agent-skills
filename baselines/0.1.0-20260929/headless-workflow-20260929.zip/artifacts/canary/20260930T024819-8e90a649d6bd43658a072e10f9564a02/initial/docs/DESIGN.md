# Inventory report design

Accepted D1: validate all rows, aggregate by exact SKU string, then render sorted
totals. Complete validation before stdout means a later malformed row cannot leave
a misleading partial report. Summarize owns the in-memory result; main owns file I/O.

Accepted D2: CSV stays the default. Opt-in JSON uses the same totals and preserves
SKU types. For rows `001,2`, `A-7,0`, `001,3`, CSV emits `001,5` then `A-7,0`;
JSON emits quantities 5 and 0 with string SKUs. No state persists between calls.

Completed delivery history is in history/completed.md. PLAN.md owns current status.
