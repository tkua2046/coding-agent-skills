# Inventory Report

Summarize warehouse stock by SKU. Repeated SKUs are summed and sorted; quantities
must be nonnegative integers. Invalid input rejects the entire report. String SKU
identity, including leading zeroes, survives both formats.

```sh
python3 inventory_report.py examples/stock.csv
python3 inventory_report.py examples/stock.csv --format json
python3 inventory_report.py examples/stock.csv --min-quantity 3
```

CSV is the default; JSON is opt-in. `--min-quantity N` retains SKUs whose aggregated
quantity is at least the nonnegative integer N. The whole input is still validated
before filtering. If none qualify, the report is the CSV header or an empty JSON
array. See DEVNOTES.md for checks and docs/PLAN.md for delivery status.
