import contextlib
import io
import unittest
from unittest import mock

from inventory_report import main, summarize


class InventoryReportTests(unittest.TestCase):
    def test_default_csv_and_opt_in_json(self):
        source = "sku,quantity\n001,2\nA-7,0\n001,3\n"
        self.assertEqual(summarize(source), "sku,quantity\n001,5\nA-7,0\n")
        self.assertEqual(summarize(source, "json"), '[{"sku":"001","quantity":5},{"sku":"A-7","quantity":0}]\n')

    def test_invalid_input(self):
        for source in ("sku,quantity\nA,2\nB,-1\n", "sku,quantity\nA,1.5\n", "sku,quantity\nA,2,extra\n", "wrong,quantity\nA,2\n"):
            with self.subTest(source=source), self.assertRaises(ValueError):
                summarize(source)

    def test_header_only(self):
        self.assertEqual(summarize("sku,quantity\n"), "sku,quantity\n")
        self.assertEqual(summarize("sku,quantity\n", "json"), "[]\n")

    def test_min_quantity_filters_aggregated_totals_in_both_formats(self):
        source = "sku,quantity\nZ,3\n001,2\nA-7,0\n001,3\n"
        self.assertEqual(
            summarize(source, min_quantity=3),
            "sku,quantity\n001,5\nZ,3\n",
        )
        self.assertEqual(
            summarize(source, "json", 3),
            '[{"sku":"001","quantity":5},{"sku":"Z","quantity":3}]\n',
        )

    def test_omitted_and_zero_min_quantity_preserve_existing_output(self):
        source = "sku,quantity\n001,2\nA-7,0\n001,3\n"
        expected = "sku,quantity\n001,5\nA-7,0\n"
        self.assertEqual(summarize(source), expected)
        self.assertEqual(summarize(source, min_quantity=0), expected)

    def test_empty_filtered_report_succeeds_in_both_formats(self):
        source = "sku,quantity\nA,1\nB,2\n"
        cases = (("csv", "sku,quantity\n"), ("json", "[]\n"))
        for output_format, expected in cases:
            with self.subTest(output_format=output_format):
                stdout = io.StringIO()
                stderr = io.StringIO()
                with mock.patch("pathlib.Path.read_text", return_value=source):
                    with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
                        result = main(
                            [
                                "inventory.csv",
                                "--min-quantity",
                                "3",
                                "--format",
                                output_format,
                            ]
                        )
                self.assertEqual(result, 0)
                self.assertEqual(stdout.getvalue(), expected)
                self.assertEqual(stderr.getvalue(), "")

    def test_min_quantity_does_not_hide_later_invalid_input(self):
        stdout = io.StringIO()
        stderr = io.StringIO()
        source = "sku,quantity\nA,1\nB,-1\n"
        with mock.patch("pathlib.Path.read_text", return_value=source):
            with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
                result = main(["inventory.csv", "--min-quantity", "100"])
        self.assertEqual(result, 2)
        self.assertEqual(stdout.getvalue(), "")
        self.assertIn("invalid inventory row", stderr.getvalue())

    def test_cli_min_quantity(self):
        stdout = io.StringIO()
        with mock.patch("pathlib.Path.read_text", return_value="sku,quantity\nA,1\nB,2\n"):
            with contextlib.redirect_stdout(stdout):
                result = main(["inventory.csv", "--min-quantity", "2", "--format", "json"])
        self.assertEqual(result, 0)
        self.assertEqual(stdout.getvalue(), '[{"sku":"B","quantity":2}]\n')

    def test_cli_rejects_invalid_min_quantity_without_report(self):
        for threshold in ("-1", "1.5", "+1"):
            with self.subTest(threshold=threshold):
                stdout = io.StringIO()
                stderr = io.StringIO()
                with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
                    with self.assertRaises(SystemExit) as raised:
                        main(["inventory.csv", "--min-quantity", threshold])
                self.assertEqual(raised.exception.code, 2)
                self.assertEqual(stdout.getvalue(), "")
                self.assertIn("nonnegative integer", stderr.getvalue())

    def test_api_rejects_invalid_min_quantity(self):
        for threshold in (-1, 1.5, True):
            with self.subTest(threshold=threshold), self.assertRaises(ValueError):
                summarize("sku,quantity\n", min_quantity=threshold)


if __name__ == "__main__":
    unittest.main()
