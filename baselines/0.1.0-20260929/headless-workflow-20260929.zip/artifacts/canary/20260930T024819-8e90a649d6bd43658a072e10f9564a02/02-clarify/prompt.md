Confirm this boundary: when no SKU reaches the threshold, return success with
the CSV header only, or `[]` followed by a newline for JSON. A malformed row must
still reject the whole input even when no SKU would survive filtering.

Check whether the current candidate already meets this. Make only necessary
corrections or amendments, preserve prior decisions/history, and show the actual
verification and remaining review status.

Read fixture AGENTS.md. CANARY_PYTHON is the prepared Python runtime. Use only this practice project and its supplied skills.
Working time already used: 109.310s; hard budget remaining: 790.690s.
