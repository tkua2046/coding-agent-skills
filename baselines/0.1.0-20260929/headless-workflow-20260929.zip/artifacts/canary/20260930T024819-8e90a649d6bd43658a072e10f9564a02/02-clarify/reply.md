Status: candidate ready; independent development review and human acceptance remain pending.

The production code already met the clarified boundary, so no code correction was necessary. I added explicit acceptance wording and regression coverage in [DESIGN.md](</private/var/folders/7w/2jmyflc53t3fhsxzmf590wk80000gn/T/headless-skill-workflow-x7so0ufq/author/docs/DESIGN.md>), [PLAN.md](</private/var/folders/7w/2jmyflc53t3fhsxzmf590wk80000gn/T/headless-skill-workflow-x7so0ufq/author/docs/PLAN.md>), [README.md](</private/var/folders/7w/2jmyflc53t3fhsxzmf590wk80000gn/T/headless-skill-workflow-x7so0ufq/author/README.md>), and [tests](</private/var/folders/7w/2jmyflc53t3fhsxzmf590wk80000gn/T/headless-skill-workflow-x7so0ufq/author/tests/test_inventory_report.py>).

Actual verification with `"$CANARY_PYTHON" hooks/pre-commit`:

- No matching SKU, CSV: exit 0 and exactly `sku,quantity\n`
- No matching SKU, JSON: exit 0 and exactly `[]\n`
- Later malformed row with threshold 100: exit 2, empty stdout, error on stderr
- Installed gate: all 10 tests passed
- `git diff --check`: passed

No commit or release was made.