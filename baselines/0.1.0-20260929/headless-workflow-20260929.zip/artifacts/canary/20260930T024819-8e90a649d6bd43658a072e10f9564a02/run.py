"""One ephemeral, two-turn author conversation plus a separate code review."""
from pathlib import Path
import json
import os
import selectors
import shutil
import signal
import subprocess
import tempfile
import time
import tomllib

from tools import canary as c
from tools import canary_runtime as rt

ROOT = Path.cwd()
CAMPAIGN = ROOT / "artifacts/headless-workflow-20260929"
PREPARED = ROOT / "artifacts/interactive-workflow-20260929"
MODEL = "gpt-5.6-sol"


class Client:
    def __init__(self, workspace, output):
        self.output = output
        self.counter = 0
        self.pending = b""
        self.events = []
        self.argv = [shutil.which("codex"), "app-server", "--stdio", "--strict-config"]
        for value in ["mcp_servers={}", "features.plugins=false", "features.apps=false", "orchestrator.skills.enabled=false", "project_doc_max_bytes=0"]:
            self.argv.extend(["-c", value])
        c.save(output / "server-argv.json", self.argv)
        self.process = subprocess.Popen(self.argv, cwd=workspace, env=os.environ | rt.GIT_ENV, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
        self.selector = selectors.DefaultSelector()
        for stream in [self.process.stdout, self.process.stderr]:
            self.selector.register(stream, selectors.EVENT_READ)
        self.rpc("initialize", {"clientInfo": {"name": "scoped_workflow_diagnostic", "version": "1"}})
        self.send({"method": "initialized", "params": {}})

    def send(self, message):
        with (self.output / "requests.jsonl").open("a") as log:
            log.write(json.dumps({"monotonic": time.monotonic(), "message": message}) + "\n")
        self.process.stdin.write((json.dumps(message) + "\n").encode())
        self.process.stdin.flush()

    def until(self, predicate, timeout):
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            for key, _ in self.selector.select(min(0.25, max(0, deadline-time.monotonic()))):
                chunk = os.read(key.fileobj.fileno(), 65536)
                if not chunk:
                    self.selector.unregister(key.fileobj)
                    continue
                filename = "stderr.txt" if key.fileobj == self.process.stderr else "events.jsonl"
                with (self.output / filename).open("ab") as log:
                    log.write(chunk)
                if key.fileobj == self.process.stderr:
                    continue
                self.pending += chunk
                matched = None
                while b"\n" in self.pending:
                    line, self.pending = self.pending.split(b"\n", 1)
                    try:
                        event = json.loads(line)
                    except ValueError:
                        continue
                    self.events.append(event)
                    if predicate(event):
                        matched = event
                if matched is not None:
                    return matched
            if self.process.poll() is not None:
                raise RuntimeError("App-server stopped before the expected response")
        raise TimeoutError("App-server response/turn deadline reached")

    def rpc(self, method, params, timeout=30):
        self.counter += 1
        request_id = self.counter
        self.send({"id": request_id, "method": method, "params": params})
        response = self.until(lambda event: event.get("id") == request_id and "method" not in event, timeout)
        if "error" in response:
            raise RuntimeError(json.dumps(response["error"]))
        return response["result"]

    def start(self, workspace):
        config = {}
        args = rt.permission_args(workspace)
        for value in args[1::2]:
            key, raw = value.split("=", 1)
            config[key] = tomllib.loads("value=" + raw)["value"]
        filesystem = config["permissions"]["canary"]["filesystem"]
        filesystem[":workspace_roots"].pop("skills")
        filesystem[":workspace_roots"][".agents/skills"] = "read"
        filesystem[":workspace_roots"][".git/hooks"] = "read"
        catalog = self.rpc("skills/list", {"cwds": [str(workspace)], "forceReload": True})
        ambient = [{"path": s["path"], "enabled": False} for group in catalog["data"] for s in group["skills"] if s["scope"] != "repo"]
        config.update({"skills.include_instructions": True, "skills.config": ambient, "orchestrator.skills.enabled": False, "features.plugins": False, "features.apps": False, "project_doc_max_bytes": 0, "web_search": "disabled", "model_reasoning_effort": "medium"})
        return self.rpc("thread/start", {"model": MODEL, "cwd": str(workspace), "ephemeral": True, "config": config})

    def turn(self, thread_id, prompt, timeout, destination):
        destination.mkdir(parents=True)
        (destination / "prompt.md").write_text(prompt)
        begin = len(self.events)
        started = time.monotonic()
        response = self.rpc("turn/start", {"threadId": thread_id, "input": [{"type": "text", "text": prompt}], "effort": "medium", "model": MODEL}, timeout=min(30, timeout))
        turn_id = response["turn"]["id"]
        matches = lambda e: e.get("method") == "turn/completed" and e["params"]["threadId"] == thread_id and e["params"]["turn"]["id"] == turn_id
        complete = next((e for e in self.events[begin:] if matches(e)), None)
        if complete is None:
            complete = self.until(matches, max(0, timeout-(time.monotonic()-started)))
        elapsed = round(time.monotonic()-started, 3)
        events = self.events[begin:]
        replies = [e["params"]["item"]["text"] for e in events if e.get("method") == "item/completed" and e["params"]["item"].get("type") == "agentMessage" and e["params"]["item"].get("phase") == "final_answer"]
        (destination / "reply.md").write_text("\n\n".join(replies))
        c.save(destination / "turn.json", complete)
        c.save(destination / "events.json", events)
        result = {"thread_id": thread_id, "turn_id": turn_id, "elapsed_seconds": elapsed, "status": complete["params"]["turn"]["status"], "server_duration_ms": complete["params"]["turn"].get("durationMs")}
        c.save(destination / "execution.json", result)
        if result["status"] != "completed":
            raise RuntimeError("Turn did not complete: " + json.dumps(result))
        print(json.dumps({"phase": destination.name, **result}), flush=True)
        return result

    def close(self):
        if self.process.poll() is None:
            os.killpg(self.process.pid, signal.SIGTERM)
        try:
            out, err = self.process.communicate(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(self.process.pid, signal.SIGKILL)
            out, err = self.process.communicate()
        for name, data in [("events.jsonl", out), ("stderr.txt", err)]:
            with (self.output / name).open("ab") as log:
                log.write(data)
        self.selector.close()


directory, report = c.new_record(ROOT, "headless-multiturn-workflow-diagnostic")
c.save(CAMPAIGN / "run-location.json", {"directory": str(directory)})
report.update(settings={"model": MODEL, "effort": "medium"}, environment=c.environment(), qualification="not-established", target_seconds=600, hard_cap_seconds=900)
c.save(directory / "attempt.json", report)
baseline = c.files(PREPARED / "baseline")
assert c.hashes(baseline) == c.read_json(PREPARED / "baseline-sha256.json")
c.write_files(directory / "initial", baseline)
for name in ["01-request.md", "02-clarification.md", "proposal.md", "check_candidate.py"]:
    (directory / ("prepared-" + name)).write_bytes((PREPARED / name).read_bytes())
(directory / "proposal.md").write_bytes((CAMPAIGN / "proposal.md").read_bytes())
(directory / "run.py").write_bytes(Path(__file__).read_bytes())
client = None
executions = []
started_campaign = time.monotonic()
try:
    with tempfile.TemporaryDirectory(prefix="headless-skill-workflow-") as temp:
        workspace = Path(temp).resolve() / "author"
        workspace.mkdir()
        head = c.init_fixture(workspace, baseline)
        hook = workspace / ".git/hooks/pre-commit"
        hook.write_bytes(baseline["hooks/pre-commit"])
        hook.chmod(0o755)
        isolation = rt.probe(workspace, CAMPAIGN / "proposal.md")
        c.save(directory / "isolation.json", isolation)
        assert isolation["passed"]
        client = Client(workspace, directory)
        start = client.start(workspace)
        c.save(directory / "author-thread.json", start)
        thread_id = start["thread"]["id"]
        for phase, request in [("01-implement", "01-request.md"), ("02-clarify", "02-clarification.md")]:
            remaining = 900-sum(x["elapsed_seconds"] for x in executions)
            prompt = (PREPARED / request).read_text() + "\nRead fixture AGENTS.md. CANARY_PYTHON is the prepared Python runtime. Use only this practice project and its supplied skills.\n"
            if executions:
                prompt += f"Working time already used: {sum(x['elapsed_seconds'] for x in executions):.3f}s; hard budget remaining: {remaining:.3f}s.\n"
            result = client.turn(thread_id, prompt, remaining, directory / phase)
            executions.append(result)
            c.write_files(directory / phase / "workspace", c.files(workspace))
            c.save(directory / phase / "git.json", c.git_snapshot(workspace, head))
            assert hook.read_bytes() == baseline["hooks/pre-commit"]
            assert all((workspace/p).read_bytes() == data for p,data in baseline.items() if p.startswith(".agents/skills/"))
        candidate = c.files(workspace)
        review_workspace = Path(temp).resolve() / "reviewer"
        review_workspace.mkdir()
        review_head = c.init_fixture(review_workspace, baseline)
        c.write_files(review_workspace, candidate)
        review_hook = review_workspace / ".git/hooks/pre-commit"
        review_hook.write_bytes(baseline["hooks/pre-commit"])
        review_hook.chmod(0o755)
        review = client.start(review_workspace)
        c.save(directory / "review-thread.json", review)
        remaining = 900-sum(x["elapsed_seconds"] for x in executions)
        original_requests = "\n\n".join((PREPARED/p).read_text() for p in ["01-request.md", "02-clarification.md"])
        prompt = "Independently review the complete current candidate using .agents/skills/stage-development and its review operation. Read AGENTS.md and original baseline via Git as needed. Original user requests below are context, not an instruction to implement. Inspect actual code, tests and affected documentation; verify the required gate and relevant behavior. Report supported material findings or readiness and true inspection/check limits. Do not edit any deliverable or claim human acceptance. The author summary is not your independent evidence. CANARY_PYTHON is available.\n\nOriginal requests:\n" + original_requests + f"\n\nWhole-task hard budget remaining: {remaining:.3f}s."
        executions.append(client.turn(review["thread"]["id"], prompt, remaining, directory / "03-review"))
        c.save(directory / "03-review/git.json", c.git_snapshot(review_workspace, review_head))
        assert c.files(review_workspace) == candidate, "Reviewer changed candidate"
        c.write_files(directory / "final", candidate)
        c.save(directory / "final-git.json", c.git_snapshot(workspace, head))
        gate = rt.capture(rt.sandbox_command(workspace, [os.sys.executable, ".git/hooks/pre-commit"]), workspace, 30)
        c.save(directory / "final-hook.json", gate)
        functional = rt.capture([os.sys.executable, str(PREPARED / "check_candidate.py"), str(workspace)], workspace, 60)
        c.save(directory / "functional-checks.json", functional)
        original_source = baseline["tests/test_inventory_report.py"].decode()
        source = "import types, unittest, sys; sys.path.insert(0,'.'); m=types.ModuleType('original_tests'); exec(compile(" + repr(original_source) + ",'original_tests.py','exec'),m.__dict__); suite=unittest.defaultTestLoader.loadTestsFromModule(m); assert suite.countTestCases()==3; r=unittest.TextTestRunner(verbosity=2).run(suite); sys.exit(not r.wasSuccessful())"
        c.save(directory / "original-tests-final.json", rt.capture(rt.sandbox_command(workspace, [os.sys.executable, "-B", "-c", source]), workspace, 30))
        report.update(worker_seconds=round(sum(x["elapsed_seconds"] for x in executions),3), executions=executions, within_target=sum(x["elapsed_seconds"] for x in executions)<=600, functional_checks_passed=functional["exit_code"]==0, original_requests_preserved=all(candidate[p]==baseline[p] for p in ["docs/ORIGINAL.md", "docs/history/completed.md"]), independent_review_preserved_candidate=True)
except (Exception, KeyboardInterrupt) as error:
    report["error"] = f"{type(error).__name__}: {error}"
finally:
    if client:
        client.close()
    report.update(status="inconclusive", qualification="manual outcome assessment pending", campaign_seconds=round(time.monotonic()-started_campaign,3))
    c.finish(directory, report)
    print(json.dumps({"directory":str(directory),"report":report}),flush=True)
