# Headless continuation of the prepared workflow

The user explicitly corrected treating the locked desktop as a work blocker.
Execute the already reviewed inventory task through a headless Codex conversation.
The earlier UI proposal/archive remains unchanged and UI operation remains untested.

Reuse the prepared baseline, both original requests and substantive acceptance from
`../interactive-workflow-20260929/proposal.md`. Use gpt-5.6-sol / medium as in the
recent worker trials. Keep two author turns in one ephemeral app-server thread;
use a fresh ephemeral thread for the required development review, supplying original
requests and the stable complete candidate without evaluator expectations or a
preferred verdict. A necessary repair/recheck consumes the same total budget.

The cumulative model-turn target remains 600s and hard stop 900s, including reviewer
and repair turns. Measure turn/start through turn/completed, including model/tools/
waits; separately record setup, oracle and acceptance-audit cost. One first attempt,
not repeats until green. Keep outcome quality, proportionality and timing separate.

The app-server uses the existing runtime's restricted workspace/read/network
permissions with supplied `.agents/skills` read-only, disables ambient plugins,
external apps, unrelated skills and automatic global instructions for this scoped
test. Explicitly read fixture AGENTS.md. This is a multi-turn workflow diagnostic,
not normal-user-environment or GUI validation and not automatic release qualification.
Do not alter the shared runner, rubric or runtime skills merely for this transport.

Retain exact requests/responses/events, timestamps, baseline and each candidate,
original test/hook checks, evaluator-only CLI results, independent review and any
failures. Review the complete result against the existing contract before deciding
whether a general prompt correction is supported. Preserve the earlier prepared
workspace and archive; model work takes place in an independent temporary fixture.
