Implemented and ready for independent review.

- Added `--min-quantity N`, filtering aggregated totals after complete input validation.
- Preserved default behavior, exact SKU strings, sorting, both output formats, and existing `summarize(text, format)` calls.
- Invalid thresholds exit 2 with an error and no report.
- Updated [design](</private/var/folders/7w/2jmyflc53t3fhsxzmf590wk80000gn/T/headless-skill-workflow-x7so0ufq/author/docs/DESIGN.md>), [plan](</private/var/folders/7w/2jmyflc53t3fhsxzmf590wk80000gn/T/headless-skill-workflow-x7so0ufq/author/docs/PLAN.md>), README, tests, and changelog.
- Installed gate passed: 9 tests.
- No commit, release, or unrelated changes made.

Status: implementation complete; independent development review and human acceptance remain pending.