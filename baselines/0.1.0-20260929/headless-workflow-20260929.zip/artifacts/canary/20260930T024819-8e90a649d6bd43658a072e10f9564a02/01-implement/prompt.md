Add an optional `--min-quantity N` filter to this inventory report CLI. N is a
nonnegative integer. Retain SKUs whose aggregated quantity is at least N, after
validating the entire input. Without the option, existing behavior stays unchanged.
Keep both formats, exact SKU strings and sorted output compatible; invalid thresholds
must fail with an error and no report.

Use the project's existing design and plan where decisions or acceptance change,
implement the feature and run the installed gate. Keep the candidate ready for the
required independent review; I will provide that separate review. Follow repository
scope. No commit or release is requested.

The complete task, including my later clarification, required development review
and any repair, has a 600-second working-time target and 900-second hard stop.
Waiting for my input is excluded. Report a material blocker rather than silently
expanding the task. Make the final status easy to read.

Read fixture AGENTS.md. CANARY_PYTHON is the prepared Python runtime. Use only this practice project and its supplied skills.
