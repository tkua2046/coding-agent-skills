# Completed baseline

D1 / 1.2.0: reject malformed inventory before producing output; aggregate and sort
SKU totals. D2 / 1.3.0: opt-in JSON preserves SKU strings and integer quantities;
default CSV remains unchanged. These are supplied accepted fixture facts, not a
claim that the trial agent or supervisor performed an earlier human review.
