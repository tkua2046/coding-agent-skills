# Development

Python standard library only. The installed pre-commit hook runs unittest discovery
and fails on zero collected tests. Run the same gate without creating a commit:

```sh
python3 hooks/pre-commit
```

Focused checks can use `python3 -m unittest discover -s tests -v`. An unchanged full
suite need not run twice merely to provide two command names. VERSION changes only
for an authorized release; completed feature impact belongs under Unreleased.
