# Inventory report project

Use applicable project-local skills in `.agents/skills` for the requested work.
The existing design owns choices; the plan owns pending outcomes and current status.
README owns usage; DEVNOTES owns checks; CHANGELOG owns significant completed impact.
Preserve original request/history files and supplied skills and hook.
Run the installed gate for changed behavior. Independent code review is required
before acceptance; self-review alone does not satisfy it. The supervisor supplies
that separate reviewer after the candidate is ready. Keep human acceptance pending.
No commit, tag, release, dependency installation, external service or unrelated
configuration change is requested. Work only in this practice project.
