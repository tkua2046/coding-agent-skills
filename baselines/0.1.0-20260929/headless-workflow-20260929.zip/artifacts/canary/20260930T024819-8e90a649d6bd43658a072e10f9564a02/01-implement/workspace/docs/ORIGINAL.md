# Accepted requirements

Read a CSV with exactly sku,quantity headers and nonnegative integer quantities.
Validate the complete input before returning any report. Sum repeated SKUs, preserve
SKU strings and sort by SKU. Default CSV and optional compact JSON end in a newline.
Malformed input exits 2 with an error on stderr and no stdout. Empty input after a
valid header produces the format's empty report. Existing summarize(text, format)
callers must remain compatible. Version 1.3.0 already provides this behavior.
