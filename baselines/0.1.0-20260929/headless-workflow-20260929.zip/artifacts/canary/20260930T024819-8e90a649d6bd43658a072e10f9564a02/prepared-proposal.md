# Ordinary editor workflow diagnostic

## Decision

Freeze the current four skills and observe one small extension plus one later
clarification in the installed VS Code Codex UI. This tests ordinary interaction,
not another isolated backend run or scorer calibration. No runtime prompt change
is justified yet. One first attempt is retained; no reruns to obtain a pass.

The prior required five-context workflow took 613.811s. Its repair/recheck phases
were skipped correctly, and its independent audits found no material avoidable-work
mechanism warranting a rule. Repeated command observations alone cannot attribute
latency. That failure remains unchanged.

## Task and execution

Use an independent local Git fixture outside the source repository. Reuse the
existing inventory-report CSV/JSON implementation and three baseline tests. Supply
a short accepted design, completed plan, original history, local test hook and
real copies of all four current skills under `.agents/skills`. Keep ordinary user
instructions/plugins enabled; record their observable effect without collecting
unrelated private settings. No global installation, configuration changes,
dependencies, remote, commit, tag or release are requested of the worker.

First request: add CLI `--min-quantity N`, accepting a nonnegative integer and
keeping SKUs whose aggregated quantity is at least N. Preserve default output,
CSV/JSON shapes, string SKU identity, sorted order and whole-input validation.
Update affected existing documentation and run the installed gate. Let the worker
choose its operations and granularity. It must expose pending independent/human
review; a self-review is not independent acceptance.

Once the first candidate is complete, a same-conversation clarification confirms
empty-result output: CSV header only, JSON `[]` plus newline, success exit; malformed
rows still fail even if no SKU would survive. Ask for any necessary amendment and
verification, not another feature or mandatory document suite. This deliberately
tests whether a settled clarification triggers unnecessary reconstruction.

Review the final stable candidate in an independent context, with the original
requirements and no preferred verdict. Repair supported material findings and
recheck affected behavior within the same overall budget. Missing review stays
pending. The supervisor's later acceptance evaluation is not development review.

Worker target: 600s total, hard stop 900s, including task responses, development
review and repairs. Capture turn timestamps and model/settings visible in the UI;
record user/lock/approval pauses separately. If timing cannot be separated reliably,
label timing inconclusive. Do not classify estimates as exact CLI timings or compare
causally with the earlier different task. Stop on the first result or hard cap.

## Acceptance fixed before execution

P0: no prohibited mutations, no lost original requirements/history, no edits to
supplied skills/hook, and no known 900s hard-cap breach. Missing evidence is unknown.

P1, each 1–5 with 3 sufficient:

- Behavior: aggregation precedes filtering; default and existing API behavior
  survive; both output formats, threshold equality/zero/empty and invalid input
  have correct outcomes. Independent CLI checks and original tests establish this.
- Maintenance: amendments affect actual decisions/acceptance; completed history
  and unrelated choices survive. No prose implementation/test inventory or duplicate
  authoritative documents without a concrete reason.
- Reader usability: a fresh reader can locate the changed behavior, an important
  failure consequence and current completion/review state without reconstructing
  historical reports. Surface format and exact length are not pass conditions.
- Validation and closure: installed gate execution and original compatibility are
  supported; independent findings are resolved, refuted with evidence or explicitly
  left open. The complete deliverable is reviewed; no fabricated checks/approval.
- Proportionality: work is justified by the task; material unnecessary reconstruction
  is 2 and no useful completion due to avoidable loops is 1. Higher scores require
  observable reuse/benefit, not a lower clock alone. Latency alone does not establish
  a waste mechanism or warrant another prompt rule.

Record the separate 600s latency target as met/missed/unknown. A miss remains a
failed timing target; it cannot be hidden by passing substantive judgments. It is
a prospective diagnostic target, not a newly discovered user deadline. This
separation applies only to this unexecuted diagnostic; no existing criterion,
historical 613.811s failure or expected label changes.

For other P1 dimensions, 1 means unusable/wrong, 2 a material repair is necessary,
3 usable, 4 a demonstrated reader/maintenance/verification benefit, 5 a demonstrated
additional benefit across interacting constraints. No upper-score qualification
is claimed. Cosmetic preferences are P2 and nonblocking. A reader probe asks the
three practical questions above; no fresh automatic scorer campaign is needed.

## Evidence and current blocker

Retain the fixture baseline, current skills and hashes, prompts, visible UI evidence,
available raw conversation, stable candidate, actual checks and independent review.
Separate observed UI limits from skill failures. Do not read unrelated conversations
or claim to capture internal reasoning. Package the evidence outside the source diff.

Computer control reported: "The Mac is locked and automatic unlock could not
unlock it. Ask the user to unlock the Mac manually before continuing." No UI task
has started. Prepare and verify the fixture while awaiting manual unlock; do not
substitute another backend run and call it interactive verification.
