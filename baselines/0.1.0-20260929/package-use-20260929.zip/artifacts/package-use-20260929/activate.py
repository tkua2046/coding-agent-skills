from __future__ import annotations
import concurrent.futures,hashlib,json,os,shutil,subprocess,sys,tempfile,zipfile
from pathlib import Path
repo=Path.cwd();sys.path.insert(0,str(repo))
from tools import canary_runtime as runtime
root=repo/'artifacts/package-use-20260929'
plan=json.loads((root/'probe-plan.json').read_text())
client=json.loads((root/'client.json').read_text())
package=repo/'artifacts/release-version-fix-20260929/coding-agent-skills-local-20260929-r3.zip'
assert hashlib.sha256(package.read_bytes()).hexdigest()==plan['package_sha256']
discovery=json.loads((root/'discovery-attempt-3.json').read_text())['response']['result']['data']
ambient=[{'path':s['path'],'enabled':False} for g in discovery for s in g['skills'] if s['scope']!='repo']
def snapshot(workspace,dest):
    shutil.copytree(workspace,dest,ignore=shutil.ignore_patterns('.git','.tmp','__pycache__'))
def run(case):
    saved=root/'activation'/case['id'];saved.mkdir(parents=True,exist_ok=False)
    (saved/'request.md').write_text(case['prompt']+'\n')
    with tempfile.TemporaryDirectory(prefix='package-activation-') as d:
        workspace=Path(d).resolve()/'project';workspace.mkdir()
        if case['fixture']:shutil.copytree(repo/'evals/cases'/case['fixture']/'fixture',workspace,dirs_exist_ok=True)
        with zipfile.ZipFile(package) as z:
            for info in z.infolist():
                relative=Path(info.filename).relative_to('coding-agent-skills-local-20260929-r3')
                if relative.parts[:2]==('.agents','skills') and not info.is_dir():
                    target=workspace/relative;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(z.read(info))
        assert len(list((workspace/'.agents/skills').glob('*/SKILL.md')))==4
        env=os.environ|runtime.GIT_ENV
        for cmd in [['git','init','-q'],['git','add','.'],['git','-c','user.name=Canary','-c','user.email=canary@example.invalid','commit','-qm','Frozen disposable fixture']]:subprocess.run(cmd,cwd=workspace,env=env,check=True,capture_output=True)
        snapshot(workspace,saved/'before')
        args=runtime.permission_args(workspace)
        for i,arg in enumerate(args):
            if arg.startswith('permissions='):args[i]=arg.replace('"skills"="read"','".agents/skills"="read"')
        base=[client['binary'],'exec','--ignore-user-config','--ignore-rules','--ephemeral','--strict-config','--json','--color','never','-C',str(workspace),'--model',plan['worker']['model'],*args]
        overrides={'model_reasoning_effort':plan['worker']['effort'],'web_search':'disabled','skills.include_instructions':True,'skills.config':ambient,'orchestrator.skills.enabled':False,'project_doc_max_bytes':0,'features.plugins':False,'features.apps':False}
        for key,value in overrides.items():base+=['-c',key+'='+runtime.inline_toml(value)]
        result=runtime.capture([*base,'-'],workspace,plan['worker']['timeout_seconds'],case['prompt'])
        (saved/'raw.json').write_text(json.dumps(result,indent=2)+'\n')
        (saved/'events.jsonl').write_text(result['stdout']);(saved/'stderr.txt').write_text(result['stderr'])
        snapshot(workspace,saved/'after')
        diff=runtime.capture(['git','diff','--no-ext-diff'],workspace,15)
        (saved/'diff.json').write_text(json.dumps(diff,indent=2)+'\n')
        status=runtime.capture(['git','status','--porcelain'],workspace,15)
        (saved/'status.json').write_text(json.dumps(status,indent=2)+'\n')
        print(json.dumps({'case':case['id'],'exit_code':result['exit_code'],'seconds':result['elapsed_seconds'],'timed_out':result['timed_out']}),flush=True)
        return {'case':case['id'],'exit_code':result['exit_code'],'seconds':result['elapsed_seconds'],'timed_out':result['timed_out']}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    results=list(pool.map(run,plan['cases']))
(root/'activation-summary.json').write_text(json.dumps(results,indent=2)+'\n')
