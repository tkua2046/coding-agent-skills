Chosen version: **1.3.0**, dated **2026-09-07**.

Reason: the opt-in JSON output is a backward-compatible public option added after 1.2.0, requiring a minor-version increment. The existing candidate was already correctly prepared, so no second bump or file edits were needed.

- [VERSION](/private/var/folders/7w/2jmyflc53t3fhsxzmf590wk80000gn/T/package-activation-zo08gcee/project/VERSION:1) is `1.3.0`.
- [CHANGELOG.md](/private/var/folders/7w/2jmyflc53t3fhsxzmf590wk80000gn/T/package-activation-zo08gcee/project/CHANGELOG.md:3) retains Unreleased and prior 1.2.0 notes, and accurately records the completed JSON behavior.

No release, commit, tests/build, tag, or publication was performed. The metadata diff remains empty.
