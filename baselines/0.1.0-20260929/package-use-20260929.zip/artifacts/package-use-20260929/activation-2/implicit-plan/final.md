Created [docs/PLAN.md](/private/var/folders/7w/2jmyflc53t3fhsxzmf590wk80000gn/T/package-activation-hf5rt2j5/project/docs/PLAN.md).

It defines:

- The next usable Client A JSON outcome while Client B remains on CSV.
- Dependencies, including the missing byte-producing export boundary and unspecified JSON wire contract.
- Acceptance criteria for compatibility, validation, deployment, and rollback.
- Two meaningful commit boundaries: exporter capability and the separately owned Client A change.

No implementation or repository-policy duplication was added.
