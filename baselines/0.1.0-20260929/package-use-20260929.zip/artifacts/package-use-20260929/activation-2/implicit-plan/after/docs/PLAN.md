# JSON export and Client A enablement plan

This plan delivers the first migration slice from the agreed [export format transition D2](DESIGN.md): JSON becomes available by explicit selection, Client A opts in, and Client B continues to receive the unchanged default CSV. Client B's later migration and removal of CSV are outside this scope.

## Next usable outcome

Client A can consume a deployed JSON export whose `sku` values are strings and whose `quantity` values are integers, including zero. In the same exporter version, callers that do not explicitly select JSON continue down the CSV path and receive byte-for-byte the output they received before the change; Client B therefore requires no change or coordinated deployment.

This outcome is complete only after the exporter capability and Client A's separately owned opt-in are both deployed. Exporter support by itself is a useful prerequisite, but it does not enable Client A.

## Dependencies

1. **Resolve the production export boundary before implementation.** In this checkout, `exporter.py` only parses and validates CSV through `export_rows(text)` and returns Python row dictionaries; it does not emit CSV bytes. The implementing owner must identify the production byte-producing path (or add the missing agreed design detail if this repository is intended to own it) and capture representative current CSV output as the compatibility baseline. Byte compatibility cannot be decided from the present function alone.
2. **Fix the JSON contract at that boundary.** D2 fixes the field types but not the JSON document shape or the public format-selection mechanism. Those details must be recorded with the accepted design before code depends on them. The selector must make CSV the default and require an explicit JSON choice.
3. **Coordinate the separately owned Client A change and deployment.** Client A's parser and deployment configuration are not in this repository. Its owner must provide a change window after the JSON-capable exporter is available. There is no dependency on a Client B change.

## Delivery increments and acceptance

### 1. Exporter supports opt-in JSON without changing CSV

Add the agreed explicit format selection at the production export boundary and implement the agreed JSON representation. Retain the existing invalid-row behavior: a missing/empty `sku` or negative `quantity` is rejected rather than serialized.

Acceptance:

- With no format selection, representative valid inputs produce bytes identical to the captured pre-change CSV fixtures, including ordering, quoting, delimiters, and line endings.
- With JSON explicitly selected, a representative row such as SKU `00123` with quantity `0` serializes the SKU as the JSON string `"00123"` and the quantity as the JSON number `0`; positive integer quantities behave likewise.
- Missing/empty SKUs, negative quantities, and malformed quantities fail through the established validation path for both formats and do not yield a partial export.
- An unsupported explicit format fails clearly rather than silently falling back to CSV.
- Focused tests cover the JSON contract and failure cases, while compatibility fixtures exercise the unchanged default CSV path.

The increment is usable when deployed as dormant capability: existing consumers remain on CSV, while Client A has a stable JSON endpoint/option against which to complete its opt-in.

### 2. Client A explicitly opts in and is enabled

In Client A's owned codebase, update its format flag and parser to request the deployed JSON representation explicitly. Deploy the exporter capability first, then the Client A change. Do not alter Client B's request, parser, or deployment configuration.

Acceptance:

- Client A's contract tests consume the agreed JSON shape and demonstrate preservation of a leading-zero SKU and an integer zero quantity.
- In the target environment, Client A explicitly requests JSON and successfully processes a representative export.
- During and after the Client A rollout, Client B continues to omit JSON selection and receives CSV bytes matching its pre-change contract.
- Rolling Client A back to its prior CSV selection remains possible without rolling back the exporter; no CSV removal or default change is included.

## Meaningful commit boundaries

1. **Exporter commit:** the format selector, JSON serialization, validation coverage, and frozen CSV compatibility fixtures land together. Splitting the selector from either its JSON behavior or its compatibility proof would not produce a safely usable capability.
2. **Client A commit (separate owned repository):** its explicit JSON selection, parser adaptation, and contract tests land together after the exporter contract is available. Environment rollout/configuration is a deployment step, not a source commit.

No Client B commit is expected. Its unchanged behavior is demonstrated by the exporter compatibility acceptance, and its eventual opt-in belongs to a later plan.
