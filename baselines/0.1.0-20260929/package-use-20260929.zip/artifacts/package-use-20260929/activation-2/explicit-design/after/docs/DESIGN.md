# Accepted export design D1

## Source request

> Add optional limit N to return the first N rows; default unlimited. A malformed later row must still fail even when it is beyond the returned prefix. Reject negative or non-integer limits. No streaming or new dependencies are requested.

## Current choice: bounded result after full validation

`export_rows(text, limit=None)` accepts either no limit or a non-negative integer. Omitting the limit preserves the existing unlimited result. Negative values, non-integers, and booleans are rejected with `ValueError` rather than being coerced.

The exporter fully parses and validates all CSV rows in source order before applying the limit and returning the first `limit` rows. This keeps validation a property of the complete input: a caller cannot use a small or zero limit to suppress an invalid stock row. The consequence is that limiting the result does not reduce parsing or validation work and does not provide streaming behavior.

For example, given valid row `A` followed by malformed row `B`, `export_rows(csv_text, limit=1)` fails instead of returning `A`. If both rows are valid, the same call returns only `A`; omitting `limit` returns `A` and `B`.

## Accepted history

CSV rows are fully parsed and validated before being returned in source order.
The caller owns output rendering. Invalid stock rows fail the request.
This decision is accepted; no delivery status is tracked here.
