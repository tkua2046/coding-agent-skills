Updated [docs/DESIGN.md](/private/var/folders/7w/2jmyflc53t3fhsxzmf590wk80000gn/T/package-activation-2ztdbf54/project/docs/DESIGN.md:1) to include:

- The preserved source request and accepted D1 history.
- The `limit=None` API choice and validation rules.
- Full-input validation before prefixing, including its performance consequence.
- Acceptance examples covering valid and malformed later rows.

No implementation files were changed. `git diff --check` passed; tests were not run because this was design-only.
