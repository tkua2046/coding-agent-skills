Explain the difference between a Python list and a tuple in three sentences.
