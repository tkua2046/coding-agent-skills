# Design: atomic rejection for insufficient orders

This amends accepted design D1 for the extension in [REQUEST.md](REQUEST.md). The
original contract remains recorded in [ORIGINAL.md](ORIGINAL.md), and completed D1
delivery remains recorded in [history/completed.md](history/completed.md).

## Decision and behavior

For each order in input order, the reservation engine first compares every requested
quantity with the current batch-local remaining quantity. If every item is available,
it deducts all items and reports `accepted=True`. If any item is insufficient, it
deducts none of that order's items and reports `accepted=False`. Processing then
continues with the next order against the remaining stock left by earlier accepted
orders only.

For example, with stock `{"a": 2, "b": 1}`, an order requesting two `a` and two
`b` is rejected without consuming either SKU. A following order requesting two `a`
is therefore accepted, producing `{"a": 0, "b": 1}`. This distinguishes atomic
rejection from deducting sufficient lines before discovering a shortage.

An order with no items passes the availability check, is accepted, and changes no
stock. Availability is evaluated independently for each order; there is no batch-wide
rollback when a later order fails.

## Boundaries and compatibility

The engine continues to own one copied, in-memory stock dictionary for the batch and
does not mutate `stock`, `orders`, or nested caller values. Both `inventory.reserve`
and `batch.execute` keep their signatures, return shapes, result ordering, and integer
counts. Successful and empty-order behavior is unchanged. The intentional
compatibility change is that an order which would previously drive a count negative
is now rejected atomically and returns `accepted=False`.

The JSON boundary retains its existing validation of input shapes, positive integer
quantities, unique IDs, and known unique SKUs. The engine may continue to rely on
those validated order invariants; this feature adds no validation policy. Persistence,
concurrency, remote coordination, and a general transaction abstraction remain out
of scope.

Because rejected orders make no persistent or external change, processing can safely
continue immediately. A caller retry is simply a new invocation against the stock it
chooses to supply; the utility keeps no state between invocations.
