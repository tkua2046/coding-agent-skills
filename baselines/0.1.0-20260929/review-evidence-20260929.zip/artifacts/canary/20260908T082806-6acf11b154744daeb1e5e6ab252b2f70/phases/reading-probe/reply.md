1. Insufficient orders are now rejected atomically: they consume none of their requested items. Stock left by earlier accepted orders must be preserved, and processing continues with later orders.

2. The engine checks every requested quantity against current batch-local stock before making any deductions. It deducts all items only if every item is available; otherwise, it deducts none. Consequently, rejected orders cannot partially consume stock, and later orders may use that stock.

3. S0 is delivered, and S1 is complete as a working-tree candidate with regression coverage and documentation. The next step is owner review; human acceptance remains pending.