This is already a fresh reviewer context, separate from the author. You are the
assigned independent reviewer; this role does not require spawning another reviewer.
Independently use the design and implementation-plan review operations in
skills/feature-design and skills/implementation-plan to assess docs/REQUEST.md against
the current proposed design and plan. This is one combined document review authorized
for this task. Decide whether implementation can begin.
Write only the review record and necessary evidence. Write reviews/design-current.json
with {"verdict":"ready"|"needs-changes"|"needs-decision","findings":[...]}; this is the
runner interface, not a demand to find issues. Preserve previous reviews separately.
Identify reviewed content, material findings, and next action in the report. Do not
modify the product or claim implementation/runtime/human approval from this review.

The whole requested task has a 600-second usable-delivery target and a 900-second hard stop, including all required worker/reviewer/fix/check/handoff phases. This phase does not reset that allowance. The contractual clock sums actual worker invocation time, including model/tool waits and development reviews/fixes; separate evaluator reader/scorer and harness overhead are excluded and recorded separately. Preserve the supplied skill files and any installed required hook. Budgets are ceilings, not time to consume; preserve substantive requirements.


Use only this fixture and the supplied skills/. Read fixture AGENTS.md if present. This phase is a fresh context. Preserve prior reports. CANARY_PYTHON points to the prepared Python runtime. Do not install packages or use external services.

Workflow worker clock: 184.102s consumed; usable target remaining: 415.898s; hard budget remaining: 715.898s; this invocation cap: 600.000s.
