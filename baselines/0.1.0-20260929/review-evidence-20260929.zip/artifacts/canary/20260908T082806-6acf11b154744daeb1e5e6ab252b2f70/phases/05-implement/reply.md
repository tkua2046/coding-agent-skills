Implemented atomic per-order inventory rejection within the agreed S1 scope.

- [inventory.py](/private/var/folders/7w/2jmyflc53t3fhsxzmf590wk80000gn/T/canary-p4xkxa9q/worker/inventory.py:2) now checks the complete order before deducting stock.
- [tests/test_inventory.py](/private/var/folders/7w/2jmyflc53t3fhsxzmf590wk80000gn/T/canary-p4xkxa9q/worker/tests/test_inventory.py:12) covers atomic rejection, later-order continuation, both APIs, empty orders, input immutability, result order, and integer counts.
- Updated [README.md](/private/var/folders/7w/2jmyflc53t3fhsxzmf590wk80000gn/T/canary-p4xkxa9q/worker/README.md:1), [SPEC.md](/private/var/folders/7w/2jmyflc53t3fhsxzmf590wk80000gn/T/canary-p4xkxa9q/worker/docs/SPEC.md:1), and the reviewer handoff in [PLAN.md](/private/var/folders/7w/2jmyflc53t3fhsxzmf590wk80000gn/T/canary-p4xkxa9q/worker/docs/PLAN.md:42).

Checks passed:

- `"$CANARY_PYTHON" -m unittest discover -s tests -v` — 8 tests passed.
- `.git/hooks/pre-commit` — 8 tests passed.
- `git diff --check` — passed.
- Installed hook remains byte-identical to `hooks/pre-commit` and its tracked source is unchanged.

The prior document review records `ready` with no findings. Independent code review and human review remain explicitly pending. No commit was created.