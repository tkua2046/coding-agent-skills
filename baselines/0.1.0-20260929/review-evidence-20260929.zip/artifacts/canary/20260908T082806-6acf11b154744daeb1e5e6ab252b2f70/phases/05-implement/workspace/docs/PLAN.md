# Implementation plan

## Status and next outcome

S0 is complete: the in-memory reservation engine and validated JSON adapter are
delivered, as recorded in [history/completed.md](history/completed.md). That history
is not evidence for the new behavior.

S1 is the single next delivery: implement atomic per-order rejection described in
[DESIGN.md](DESIGN.md), cover it with regression tests, and update the current
behavior and usage documentation. There is no useful partial delivery boundary: the
rejection result, absence of deductions, and continuation to later orders form one
observable contract.

Prerequisites are already present: validated unique item SKUs permit a direct
availability decision for each order, and the engine already owns a copied
batch-local stock dictionary. No dependency, migration, infrastructure, release, or
version work is required.

## S1 implementation and acceptance

Change the reservation engine so an order is applied only after all its items are
available in current remaining stock. Retain the existing adapter and validation
policy. Add focused tests at the engine boundary and through the JSON adapter, then
update [SPEC.md](SPEC.md) and [README.md](../README.md) so they no longer state or
imply that callers must guarantee sufficient inventory.

S1 is decisively accepted when:

- a multi-item order with one insufficient item returns `accepted=False` and leaves
  every stock quantity unchanged by that order;
- a later order is still processed and can consume stock that the rejected order did
  not reserve;
- sufficient orders deduct every requested item, empty orders are accepted without a
  stock change, and results remain in input order;
- both public APIs exhibit the same reservation behavior, preserve caller inputs and
  integer counts, and all existing JSON validation cases remain unchanged; and
- the prepared-runtime gate, `"$CANARY_PYTHON" -m unittest discover -s tests -v`,
  collects tests and passes. The installed pre-commit hook must remain in place and
  unmodified.

## Current evidence and handoff

The design and plan review in `reviews/design-current.json` records a `ready` verdict
with no material findings. The S1 working-tree candidate now implements atomic
per-order rejection, adds engine and adapter regressions, and updates the current
contract and usage documentation.

On 2026-09-08, `"$CANARY_PYTHON" -m unittest discover -s tests -v` collected and
passed all 8 tests. Executing `.git/hooks/pre-commit` separately also collected and
passed all 8 tests. The installed hook remains in place and byte-matches
`hooks/pre-commit`. These are author checks, not independent code acceptance. The
independent code review and subsequent human review remain pending. No commit, push,
version advancement, or release is part of this task.
