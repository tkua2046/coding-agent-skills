# Current contract
Reservation processes orders in input order using a copied, batch-local stock state.
An order is accepted and all its items are deducted only when every requested quantity
is available in the current state. If any item is insufficient, the order is rejected
without deducting any of its items. Later orders continue against stock changed only
by earlier accepted orders. An empty order is accepted without changing stock.

`inventory.reserve` and `batch.execute` return remaining integer stock counts and one
ordered acceptance result per order. They do not mutate caller inputs. The JSON
boundary continues to validate shapes, positive integer quantities, unique string
order IDs, and known unique SKUs; insufficient inventory is a reservation outcome,
not a validation error. No persistent database or concurrent writers are involved.
