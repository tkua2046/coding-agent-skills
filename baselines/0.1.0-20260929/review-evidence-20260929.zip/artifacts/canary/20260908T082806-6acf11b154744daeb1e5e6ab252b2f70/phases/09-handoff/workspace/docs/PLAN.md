# Implementation plan

## Status and next outcome

S0 is complete: the in-memory reservation engine and validated JSON adapter are
delivered, as recorded in [history/completed.md](history/completed.md). That history
is not evidence for the new behavior.

S1 is complete as a working-tree candidate: atomic per-order rejection described in
[DESIGN.md](DESIGN.md), focused regression coverage, and current behavior and usage
documentation are present. The latest [independent code review](../reviews/code-current.json)
records a `ready` verdict with no material findings. Human acceptance remains
pending, so the next action is owner review of this candidate.

No dependency, migration, infrastructure, release, or version work is required.

## S1 scope and delivery criteria

The planned S1 work was to apply an order only after all its items are available in
current remaining stock, retain the existing adapter and validation policy, add
focused tests at the engine and JSON-adapter boundaries, and update
[SPEC.md](SPEC.md) and [README.md](../README.md) so they no longer state or imply
that callers must guarantee sufficient inventory.

The candidate delivery criteria are:

- a multi-item order with one insufficient item returns `accepted=False` and leaves
  every stock quantity unchanged by that order;
- a later order is still processed and can consume stock that the rejected order did
  not reserve;
- sufficient orders deduct every requested item, empty orders are accepted without a
  stock change, and results remain in input order;
- both public APIs exhibit the same reservation behavior, preserve caller inputs and
  integer counts, and all existing JSON validation cases remain unchanged; and
- the prepared-runtime gate, `"$CANARY_PYTHON" -m unittest discover -s tests -v`,
  collects tests and passes. The installed pre-commit hook must remain in place and
  unmodified.

## Current evidence and handoff

- **Completed:** The working-tree implementation, regression tests, contract, and
  usage updates satisfy the S1 scope. The earlier
  [design and plan review](../reviews/design-current.json) and latest
  [independent code review](../reviews/code-current.json) both record `ready` with no
  material findings.
- **Checks recorded by the independent reviewer:** On 2026-09-08,
  `"$CANARY_PYTHON" -m unittest discover -s tests -v` collected and passed all 8
  tests; `.git/hooks/pre-commit` separately collected and passed all 8 tests; and
  `cmp -s hooks/pre-commit .git/hooks/pre-commit` exited 0. The code-review record is
  the source for these results and notes the unusable preliminary checksum attempt.
- **Open and next action:** There are no open agent-review findings. Human acceptance
  remains pending; the owner should review the candidate next. No commit, push,
  version advancement, release, or human acceptance is claimed.
