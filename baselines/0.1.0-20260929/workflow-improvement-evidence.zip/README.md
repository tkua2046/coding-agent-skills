# Local skill-improvement evidence

The repo/ tree contains current source, pre-change source, exact inputs, all retained worker/scorer attempts and independent reviews. Start at repo/artifacts/workflow-improvement/results.md. Failed and inconclusive records are retained, including the two failed smoke qualifications and manual-only observations.

The prior migration archive is also included verbatim in previous-evidence/. Its run tree is available under repo/ so reused calibration links resolve. Source has not been committed or published by this campaign.

manifest.json lists SHA-256, file type and mode for every payload. Use an extractor that preserves symlinks for repository discovery links, or reconstruct links using the manifest. The separately supplied local skill package contains actual directories and no discovery symlinks.
