"""Repository validation helpers."""
