# Changelog

Significant completed changes. The current version is an unreleased baseline; no release has been published.

## [Unreleased]

### Added

- Case-local review-evidence scoring controls distinguish supported source
  inspection and attributed prior checks from contradicted claims or incomplete
  capture. Runtime skills and the shared scorer prompt are unchanged.

- Priority-based grading for three existing heavy canaries, with concrete P1
  anchors, explicit P0 boundaries, cosmetic-equivalence controls and cumulative
  worker/reviewer/fix time budgets. Readiness qualification, actual skill results
  and incomplete scoring remain separate; no full-release acceptance is implied.

- Independent operation cases across design, planning, code review/repair and
  development setup/release preparation, with fixed review prerequisites and
  concrete output/effort rubrics. Existing integration coverage is retained;
  fixture checks, scorer calibration and actual skill results remain distinct.

- Independent design-review and plan-review smoke cases, with case-scoped scorer calibration and relevant-dependency reuse; incomplete/local evidence cannot authorize another case or release. The old combined smoke is archived unchanged and adds no heavy release case.

- Concrete per-skill output requirements linked to versioned case rubrics, with source-bound known outputs and focused scorer checks that cannot replace full calibration or worker trials.

- Small real LLM operation tests for clarification, artifact responsibilities, review closure, resumption and delivery evidence, using the existing runner and retained originals.
- Shared author/reviewer artifact contracts, adaptable templates and silent after-generation checks, loaded by the relevant operation.
- Goal-to-case coverage for all four skills, with restricted-reader comprehension checks, neutral task-routing probes and real baseline/candidate execution evidence.
- Retained independent global reviews, original failed attempts and versioned measurement corrections. The result index separates skill quality, observed benefit and unresolved release evidence.
- Versioned workflow canary fixtures, evidence-based grading, isolated runner and a release evidence gate, with fast regression controls separate from expensive agent trials.
- Source-preserving research records and reviewed workflow proposals.

### Changed

- Status-only handoff selects a focused operation while explicit resumption checks
  remain execution work. Review final checks distinguish actual inspection,
  executed checks and attributed prior evidence. Quickstart distinguishes real
  portable skill folders from repository discovery links.

- The sufficient-code review fixture now honors its existing unknown-command
  exception contract. A fixture regression and refreshed source copies preserve
  its originals and expected scoring judgments.

- Planning, stage development and workflow setup/delivery now finish the selected
  operation with a readability edit. Templates remain optional; internal code or
  test edits do not require replanning, sufficient reviews stop, and setup reuses
  effective checks while preserving coverage and installed-hook evidence.

- Feature-design operations now resolve substantive decisions in sequence and
  finish with readability in the same task. Templates are optional, local
  amendments preserve accepted scope, and review separates material findings
  from presentation preferences without adding a polishing round.

- Setup completion identifies the command to run and observed results. Shared
  effort acceptance distinguishes incidental local work from material waste;
  scoring checks literal citations against their source files. Original failures
  and prospective rule versions are retained separately from new results.

- Source delivery separates maintained skills/tests from immutable execution archives; prior originals remain retrievable at a published Git revision.
- PR preparation assesses the complete deliverable against its goal and review cost, alongside actual checks.

- Design and specification decisions link to one live delivery record. Plans track observable outcomes and dependencies; verified findings and applicable check results can be reused without duplicate status or self-referential commits.
- Existing-setup inspection and changed-gate verification have distinct scopes. Observe a gate before changing it, retain known failures, and bind before/after claims to their own results. Missing output cannot establish a verified child result.
- Workflow depth follows uncertainty, consequences and affected boundaries. Understood local work can proceed directly when requirements suffice; design notes and reviews serve actual decisions or explicit policy; material unknowns call for bounded investigation.
- Design openings expose current choices and consequences; plan openings identify the next usable delivery consistently with stage order. Prior decisions and completed work remain available.
- Sufficient work can pass review without cosmetic additions; plans and stage records avoid duplicating code/tests or inventing document prerequisites.
- Local feature extensions amend affected design/pending stages; plans focus on delivery decisions without duplicating the implementation/test inventory.
- Review and handoff records expose current open findings and distinguish author fixes from verified closure, retaining prior rounds.
- Normal commits/PRs use fast checks while release readiness requires current heavy behavior evidence.

### Initial library

- Four portable skills covering feature design, implementation planning, staged development and delivery.
- Focused English operation prompts and document templates with separate user, developer and agent audiences.
- An adaptable Python example for Ruff, full-suite tests and branch coverage at commit time.
- Design and justification documents explaining workflow choices and their consequences.
- Repository checks for portable resources, metadata and document links, with a matching CI workflow.
- Independent review findings, original trial inputs/outputs and retained failure/recovery evidence from self-use.
