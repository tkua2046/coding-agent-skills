"""Bounded local worker trials, using the existing runtime and raw-record archive.

This captures behavior for independent rubric review; it is not the production
grader, a new calibration claim, or a release gate. Inputs are frozen per run.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from tools import canary as c
from tools import canary_runtime as rt

HERE = Path(__file__).resolve().parent


def run(case_id: str) -> None:
    contract = json.loads((HERE / "trials-v2.json").read_text())[case_id]
    case_dir = ROOT / "evals/cases" / case_id
    case = c.read_json(case_dir / "case.json")
    assert len(case["phases"]) == 1, "Single-operation driver only"
    directory, report = c.new_record(ROOT, "interview-candidate-worker")
    settings = {"model": "gpt-5.6-sol", "effort": "medium",
                "timeout_seconds": contract["hard_seconds"]}
    selected = c.skill_files(ROOT, case["skills"])
    source_case = c.files(case_dir)
    initial = None
    report.update(case_id=case_id, status="not-established", settings=settings,
                  contract=contract, skills=c.hashes(selected), case=c.hashes(source_case),
                  driver_sha256=c.digest(Path(__file__).read_bytes()),
                  engine=c.engine_identity(ROOT), environment=c.environment(),
                  assessment="Independent review pending; no automated semantic grade")
    c.save(directory / "attempt.json", report)
    c.write_files(directory / "inputs/case", source_case)
    c.write_files(directory / "inputs/skills", selected)
    c.write_files(directory / "inputs/specs", c.files(ROOT / "docs/specs"))
    (directory / "driver.py").write_bytes(Path(__file__).read_bytes())
    (directory / "positive-review-contract.md").write_bytes((HERE / "positive-review-contract.md").read_bytes())
    invocation = "Use the supplied skills as applicable: " + ", ".join(
        f"skills/{name}/SKILL.md" for name in case["skills"]
    ) + ". Read the relevant skill entrypoint and selected operation.\n\n"
    request = invocation + contract["request"] + (
        f"\n\nReach usable delivery within {contract['target_seconds']} seconds; "
        f"hard stop {contract['hard_seconds']} seconds, including checks and final reply. "
        "Use only the supplied fixture and skills/. Read fixture AGENTS.md. "
        "CANARY_PYTHON is the prepared interpreter. No downloads or external services. "
        "No commits in the candidate repository, push, tag or publication. "
        "Scratch fixture baseline commits are permitted only when the task requests those probes.\n"
    )
    (directory / "request.md").write_text(request)
    try:
        with tempfile.TemporaryDirectory(prefix="interview-worker-") as temp:
            workspace = Path(temp).resolve()
            head = c.init_fixture(workspace, {**c.files(case_dir / "fixture"), **selected})
            if case.get("hook"):
                hook = workspace / ".git/hooks/pre-commit"
                hook.write_bytes((workspace / case["hook"]).read_bytes())
                hook.chmod(0o755)
            initial = c.files(workspace)
            c.write_files(directory / "initial", initial)
            c.save(directory / "initial-git.json", c.git_snapshot(workspace, head))
            report["fixture_head"] = head
            isolation = rt.probe(workspace, directory / "positive-review-contract.md")
            c.save(directory / "isolation.json", isolation)
            if not isolation["passed"]:
                raise RuntimeError("Worker isolation unavailable")
            try:
                execution = rt.execute(workspace, request, directory / "reply.md", settings)
                c.save(directory / "execution.json", execution)
            finally:
                c.write_files(directory / "final", c.files(workspace))
                c.save(directory / "git.json", c.git_snapshot(workspace, head))
                hook = workspace / ".git/hooks/pre-commit"
                if hook.is_file():
                    (directory / "installed-hook").write_bytes(hook.read_bytes())
            # Oracles run after the final candidate snapshot and do not become
            # worker-produced evidence or change its recorded candidate.
            checks = c.deterministic(case, case_dir, workspace, initial, head, directory)
            measured = workspace / "artifacts"
            if measured.is_dir():
                c.write_files(directory / "oracle-artifacts", c.files(measured))
            checks.append({"id": "skills-preserved", "status": "pass" if all(
                (workspace / p).is_file() and (workspace / p).read_bytes() == data
                for p, data in selected.items()) else "fail"})
            c.save(directory / "checks.json", checks)
            report.update(completed=execution["completed"],
                          worker_seconds=execution["elapsed_seconds"], checks=checks)
            report["target_exceeded"] = execution["elapsed_seconds"] > contract["target_seconds"]
            report["hard_exceeded"] = execution["elapsed_seconds"] > contract["hard_seconds"]
            report["mechanical_status"] = "pass" if execution["completed"] and all(
                x["status"] == "pass" for x in checks) else "not-established"
            if any(x["status"] == "fail" for x in checks) or report["target_exceeded"]:
                report["status"] = "needs-work"
        assert report["skills"] == c.hashes(c.skill_files(ROOT, case["skills"])), "Skills changed during trial"
        assert report["case"] == c.hashes(c.files(case_dir)), "Case changed during trial"
    except (Exception, KeyboardInterrupt) as exc:
        report["error"] = f"{type(exc).__name__}: {exc}"
        report["interrupted"] = isinstance(exc, KeyboardInterrupt)
    print(c.finish(directory, report), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("case_id")
    run(parser.parse_args().case_id)
