Use the supplied skills as applicable: skills/stage-development/SKILL.md. Read the relevant skill entrypoint and selected operation.

Independently review session.py and its tests against REQUEST.md and write REVIEW.md. You are the separately assigned reviewer; do not edit code or tests. Local checks or read-only experiments are permitted.

Reach usable delivery within 300 seconds; hard stop 600 seconds, including checks and final reply. Use only the supplied fixture and skills/. Read fixture AGENTS.md. CANARY_PYTHON is the prepared interpreter. No downloads or external services. No commits in the candidate repository, push, tag or publication. Scratch fixture baseline commits are permitted only when the task requests those probes.
