import unittest
from session import Session

class SessionTests(unittest.TestCase):
    def test_next(self):
        state = Session()
        state.apply("next")
        self.assertEqual((state.cursor, state.selection), (5, "closed"))

    def test_previous(self):
        state = Session()
        state.apply("previous")
        self.assertEqual((state.cursor, state.selection), (3, "closed"))

    def test_reject_preserves_state(self):
        state = Session()
        with self.assertRaises(ValueError):
            state.apply("bogus")
        self.assertEqual((state.cursor, state.selection), (4, "open"))
