Created [RECHECK.md](/private/var/folders/7w/2jmyflc53t3fhsxzmf590wk80000gn/T/review-closure-ezjwq22c/RECHECK.md).

- R1: reviewer-verified closed.
- R2: reviewer-verified closed.
- Focused suite passed all 3 tests.
- Mutation probes confirmed both tests detect their reported regression.
- No material remaining issue found.
- Original inputs, tests, and `REVIEW.md` were preserved.