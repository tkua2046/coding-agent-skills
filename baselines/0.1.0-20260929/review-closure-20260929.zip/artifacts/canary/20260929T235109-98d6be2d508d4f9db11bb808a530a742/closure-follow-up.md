# Evidence-driven follow-up

The two initial reviews did not distinguish the cases as predicted: both required
the missing central-behavior regressions. The ordinary case therefore failed the
frozen advisory-only expectation. A fresh reviewer, initially given only the
actual request/code/tests/output rather than the expected grade, found blocking
legitimately reasonable though not compelled. The task explicitly asks about test
adequacy. Keep the original failure and this independent ground-truth uncertainty;
do not regrade it as a pass or infer a confirmed skill defect.

The trial severity addition is withdrawn, restoring the exact pre-campaign
stage-development bytes. The positive fixture's exception-contract correction and
explicit-policy regression case are useful input fixes, not measured skill gains.
The planned partial/complete stage smokes are deferred. Instead use two fresh
contexts for a natural follow-up to the actual ordinary review:

1. Author fixes the two concrete test findings, preserving the implementation,
   requirements and original review. Run the relevant existing gate; report the
   repair without claiming independent closure.
2. Independent reviewer rechecks the same R1/R2 against the current tests and
   implementation, retaining original findings. Verify sufficient fixes, keep any
   actual partial fix open, and stop when the requested recheck is sufficient.

Start from the exact reviewed workspace. Existing pre-campaign skill bytes apply.
The workers receive task/role scope, original review and prospective budget, never
the assessment's expected verdict. The pair shares a 300s usable target and 600s
hard cap, including both invocations/checks/final replies. This is a narrow local
test repair, with prepared runtime and no deployment; budgets are prospective.

Before dispatch, assess using current specification anchors: author C1/C2/C4/C5,
reviewer C3/C4/C5, 1–5 with 3 sufficient. The source and original review must remain
unchanged; the tests must materially protect previous movement/selection closure
and rejected-command full-state preservation. Independent controlled mutations
will verify that the delivered tests reject both regressions; no assertion names
or counts are mandated. Close only supported findings; any distinct concrete
material issue takes precedence over the expected outcome. No runtime/human
acceptance claims beyond actual evidence. Preserve all attempts and diagnostics.

This replaces two unstarted stage calls with an author/follow-up review pair,
keeping the campaign at six worker invocations including the unchanged plan pair.
No automatic qualification, A/B conclusion, source commit, push, global install
or release. Further prompt changes require a supported defect and scoped check.
