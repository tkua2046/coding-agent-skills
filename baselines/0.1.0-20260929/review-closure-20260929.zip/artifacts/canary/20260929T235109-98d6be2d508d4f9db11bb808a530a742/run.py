"""Scoped diagnostic, using the maintained runtime and snapshot/check functions."""
import sys
import tempfile
from pathlib import Path

from tools import canary as c
from tools import canary_runtime as rt

ROOT = Path.cwd().resolve()
HERE = ROOT / "artifacts/review-closure-20260929"
ALLOWED = {"plan-review-recheck", "smoke-code-review-ready",
           "smoke-review-partial", "smoke-code-recheck-complete",
           "smoke-code-review-required-tests", "observed-code-review-closure"}


def run(case_id):
    assert case_id in ALLOWED
    frozen = HERE / ("followup-inputs" if case_id == "observed-code-review-closure" else "candidate")
    case_dir = frozen / "evals/cases" / case_id
    case = c.read_json(case_dir / "case.json")
    selected = c.skill_files(frozen, case["skills"])
    assert not case.get("hook")
    assert all(not p.get("skip_if_ready") for p in case["phases"])
    directory, report = c.new_record(ROOT, "review-closure-diagnostic")
    report.update(case_id=case_id, qualification="not-established",
                  settings={"model": "gpt-5.6-sol", "effort": "medium"},
                  environment=c.environment(), worker_seconds=0,
                  target_seconds=300, hard_seconds=600)
    c.save(HERE / f"{case_id}-location.json", {"directory": str(directory)})
    c.save(directory / "attempt.json", report)
    c.write_files(directory / "inputs/case", c.files(case_dir))
    c.write_files(directory / "inputs/bundles", selected)
    c.write_files(directory / "inputs/specs", c.files(frozen / "docs/specs"))
    for name in ("proposal.md", "proposal-review.json", "run.py"):
        (directory / name).write_bytes((HERE / name).read_bytes())
    if case_id == "observed-code-review-closure":
        for name in ("closure-follow-up.md", "fresh-verdict-audit.json"):
            (directory / name).write_bytes((HERE / name).read_bytes())
    try:
        with tempfile.TemporaryDirectory(prefix="review-closure-") as temp:
            workspace = Path(temp).resolve()
            head = c.init_fixture(workspace, {**c.files(case_dir / "fixture"), **selected})
            initial = c.files(workspace)
            c.write_files(directory / "initial", initial)
            c.save(directory / "initial-git.json", c.git_snapshot(workspace, head))
            isolation = rt.probe(workspace, case_dir / "rubric.json")
            c.save(directory / "isolation.json", isolation)
            if not isolation["passed"]:
                raise RuntimeError("Isolation failed; no model call")
            for phase in case["phases"]:
                remaining = 600 - report["worker_seconds"]
                if remaining <= 0:
                    break
                if phase.get("overlay"):
                    c.write_files(workspace, c.files(case_dir / phase["overlay"]))
                out = directory / "phases" / phase["id"]
                out.mkdir(parents=True)
                request = (case_dir / phase["request"]).read_text()
                (out / "request.md").write_text(request)
                prompt = request + "\n\nUse only this fixture and the supplied skills/. Read fixture AGENTS.md. This is a fresh context. Preserve prior reports. CANARY_PYTHON points to the prepared interpreter; no packages or external services.\n"
                prompt += f"\nReview-task clock: {report['worker_seconds']:.3f}s consumed; usable target remaining {max(0, 300-report['worker_seconds']):.3f}s; hard allowance remaining {remaining:.3f}s including checks, report and final response. Complete the requested scope.\n"
                (out / "prompt.md").write_text(prompt)
                settings = {**report["settings"], "timeout_seconds": remaining}
                c.save(out / "settings.json", settings)
                execution = rt.execute(workspace, prompt, out / "reply.md", settings)
                c.save(out / "execution.json", execution)
                report["worker_seconds"] += execution["elapsed_seconds"]
                c.write_files(out / "workspace", c.files(workspace))
                c.save(out / "git.json", c.git_snapshot(workspace, head))
                if not execution["completed"]:
                    break
            checks = c.deterministic(case, case_dir, workspace, initial, head, directory)
            checks.append({"id": "skills-preserved", "status": "pass" if all(
                (workspace / name).is_file() and (workspace / name).read_bytes() == data
                for name, data in selected.items()) else "fail"})
            c.save(directory / "checks.json", checks)
            phases = [c.read_json(p) for p in sorted((directory / "phases").glob("*/execution.json"))]
            completed = len(phases) == len(case["phases"]) and all(p["completed"] for p in phases)
            report.update(completed=completed, target_met=completed and report["worker_seconds"] <= 300,
                          hard_cap_met=completed and report["worker_seconds"] <= 600,
                          checks=checks)
            if any(x["status"] == "fail" for x in checks):
                report["status"] = "fail"
    except (Exception, KeyboardInterrupt) as error:
        report["error"] = f"{type(error).__name__}: {error}"
    finally:
        print(c.finish(directory, report), flush=True)


run(sys.argv[1])
