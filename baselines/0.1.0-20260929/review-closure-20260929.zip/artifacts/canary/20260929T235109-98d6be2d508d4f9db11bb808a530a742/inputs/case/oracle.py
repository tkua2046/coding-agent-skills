"""Independent check: actual repaired tests must reject both concrete regressions."""
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

root = Path.cwd()
source = (root / "session.py").read_text()
probe = """
import json, unittest, sys
r = unittest.TextTestRunner().run(unittest.defaultTestLoader.discover('tests'))
print(json.dumps({'tests':r.testsRun,'failures':len(r.failures),'errors':len(r.errors)}))
sys.exit(not r.wasSuccessful())
"""


def run_variant(label, code, expected_success, count=None):
    with tempfile.TemporaryDirectory(prefix="review-oracle-", dir=root) as temp:
        path = Path(temp)
        (path / "session.py").write_text(code)
        shutil.copytree(root / "tests", path / "tests", ignore=shutil.ignore_patterns("__pycache__"))
        result = subprocess.run([sys.executable, "-B", "-c", probe], cwd=path,
                                capture_output=True, text=True, timeout=20)
        observed = json.loads(result.stdout.strip().splitlines()[-1])
        print(json.dumps({"variant":label,"exit_code":result.returncode,
                          "observed":observed,"stdout":result.stdout,"stderr":result.stderr}))
        assert observed["tests"] >= 2 and observed["errors"] == 0
        if count is not None:
            assert observed["tests"] == count
        assert (result.returncode == 0) == expected_success
        assert (observed["failures"] == 0) == expected_success
        return observed["tests"]


count = run_variant("delivered", source, True)
arithmetic = '1 if command == "next" else -1'
guard = '        if not isinstance(command, str) or command not in {"next", "previous"}:'
assert source.count(arithmetic) == 1 and source.count(guard) == 1
run_variant("previous-wrong-direction", source.replace(arithmetic, "1"), False, count)
run_variant("rejection-mutates-selection", source.replace(guard, '        self.selection = "closed"\n' + guard), False, count)
assert (root / "RECHECK.md").is_file(), "missing requested recheck report"
print("PASS: delivered tests reject both concrete regressions; review semantics require independent inspection")
