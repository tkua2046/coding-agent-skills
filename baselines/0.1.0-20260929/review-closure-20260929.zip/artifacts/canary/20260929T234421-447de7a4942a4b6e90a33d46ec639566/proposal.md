# Review stopping and closure

Outcome: a reviewer catches concrete defects and honors required tests, while
closing verified repairs without escalating every useful regression suggestion.
This addresses C3 and the owner's concern about engineering metrics expanding work.

Proposed product change: replace generic severity wording in stage-development's
review operation with a short decision rule: a blocking test gap needs a concrete
material delivery risk or an applicable unmet requirement. When available evidence
adequately supports the scoped behavior, extra coverage can remain a suggestion.
Passing tests do not excuse an unverified consequential path or mandatory check.
No fixture-specific advice, new artifact, template field, fixed test quota or extra
review phase. Implementation/design/planning operations remain unchanged.

Existing sufficient-code trial failed because a verified correct local invariant
still produced a required test-addition round. That is the observed motivation,
not proof that every missing test is optional. Before editing, independently
review the distinction and the neighboring scenarios below.

Acceptance uses current C3/C4/C5 and B5/B6 1–5 specification anchors (3 sufficient),
with the exact task scope and retained original binary rubrics available as facts.
No absent compulsory next-action sentence can fail a completed review. Explicit
requested report locations and revision identity remain requirements. Meaningful
findings outrank nominal positive labels; do not fix a score by hiding a defect.

Selected worker trials, gpt-5.6-sol / medium, fresh isolated contexts:

- Existing sufficient-code initial review: accepts supported behavior; useful test
  suggestions need not block. Guard the opposite policy boundary with the same
  behavior plus an explicit required-regression policy; missing required tests
  must remain blocking. Preserve the variant and exact policy as regression inputs.
  The policy requires repository tests asserting rejected-command preservation of
  both cursor and selection, and valid previous movement/selection closure, before
  approval. Reviewer scratch probes do not satisfy that durable-test requirement.
- Existing partial code repair: R1 stays open because selection still changes.
- Existing complete code repair: verifies the whole invariant and closes R1.
  Pre-run inspection found this positive fixture still raises TypeError for an
  unhashable unknown command although REQUEST requires ValueError. Correct its
  string guard exactly as the already-correct initial-review fixture; extend the
  existing deterministic fixture-conformance test and refresh linked source copies.
  Preserve old bytes and labels; a real new finding remains valid.
- Existing plan partial→complete recheck: keeps the ordering/compatibility finding
  open in P2, closes against P3 and retains both reports. No plan-skill edit proposed.

One attempt per scenario, no retry for a better score. Each code operation has a
300s usable target and 600s hard cap. The two small static plan rechecks share a
300s target and 600s cap, disclosed before execution. These are prospective
diagnostic constraints, not empirical speed guarantees. Required work is retained.

Use the existing isolation, execution, snapshot and oracle APIs; independently
inspect actual outputs. Automatic case qualification remains unestablished where
current scorer controls are missing; no release gate is bypassed. Stop to diagnose
material failures. Record exact inputs, outputs, settings and all attempts outside
the source tree. Deliver only a justified small skill change, relevant regression
assets, concise results and an updated local portable bundle if validated. No
commit, push, global installation, tag or release.
