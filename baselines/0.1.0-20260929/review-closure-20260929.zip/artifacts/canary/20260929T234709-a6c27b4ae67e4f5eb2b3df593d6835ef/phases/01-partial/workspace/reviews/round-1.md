# P2 closure recheck

## Verdict

**Needs changes. R1 remains open.** The author claim is only partially verified: P2 documents the exporter prerequisite and restores the required JSON, malformed-input, and default-CSV acceptance, but its explicit execution order still enables Client A before exporter JSON support is deployed. The plan therefore cannot safely deliver the accepted rollout.

Open finding IDs: **R1**.

## Finding status

### R1 — open (partial fix)

- **Location and trigger:** `docs/PLAN.md:3,7-10` names Client A as the next outcome and places “Enable A JSON” first; line 10 declares that the table is execution order. Following that order reaches A before the exporter capability on row 2 exists.
- **Consequence:** Client A can opt into a format the exporter cannot yet provide, contrary to `docs/ORIGINAL.md:2`, `docs/DESIGN.md:2`, and the dependency/compatibility finding in `docs/history/R1.md:3`.
- **Verified portion of the author claim:** `docs/PLAN.md:7-8` now states the prerequisite and includes SKU strings, integer quantities including zero, failure before any output for malformed quantities, and byte-identical default CSV for B. Those parts of R1 are addressed in the plan text.
- **Smallest sufficient correction:** Make the exporter JSON option the first pending outcome and Client A JSON the second; update the “Next” statement to the exporter outcome. Retain the existing acceptance for malformed input and B’s byte-identical default CSV, and retain A’s JSON acceptance after the exporter is available.
- **Closure check:** Read the revised `Next` statement and declared execution order together and verify they unambiguously say exporter first, A second, with B remaining on byte-identical default CSV and all current data/error acceptance preserved.

## Next action

Revise P2’s next outcome and execution order as described above, then request a closure recheck of R1. No implementation is needed for this plan correction.

## Reviewed content identity and evidence

This was an independent, static plan recheck at repository `HEAD` `9500d2ca0247850b6790eac6222e4b75e4ae5fdd` (`Fixture baseline`). The reviewed P2 was `docs/PLAN.md`, byte-identical to `docs/history/P2.md` (`cmp` exit 0).

| Content | SHA-256 |
|---|---|
| `docs/PLAN.md` (P2) | `e1598ae9f35e6a08f70f16c75d30a6e39c84245181f0c84dd3d5abcfebf6be86` |
| `docs/history/R1.md` | `0f597771d48af611b33d736063284192a10bfbcb2bf2039d79f9fc4f2f2036b4` |
| `docs/ORIGINAL.md` | `94b28fce3191c772603c34fb5620665530ba7ef8291a6c56bf6992aa57694e60` |
| `docs/DESIGN.md` (accepted D1) | `29747b06a1e95a61949434ec0532d5d430680e2bb8e33d4ffa7bea3e47c3efab` |

Evidence inspected: the full contents of all four files above, plus `docs/history/P1.md` and `docs/history/P2.md` for revision context. The ordering conflict is textual and decisive: the requirement and accepted design say exporter capability must precede A, R1 requires “exporter first, A second,” while P2 declares the opposite row order to be executable. No code, runtime, test, package, or external-service evidence was needed or used; planned checks were not treated as completed checks.
