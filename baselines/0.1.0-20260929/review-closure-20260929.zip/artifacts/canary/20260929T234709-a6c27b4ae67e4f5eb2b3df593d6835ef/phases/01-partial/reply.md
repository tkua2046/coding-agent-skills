Review complete: **Needs changes; R1 remains open.**

P2 documents the prerequisite but still declares A before the exporter in its execution order. The required acceptance coverage is otherwise restored.

Report: [reviews/round-1.md](</private/var/folders/7w/2jmyflc53t3fhsxzmf590wk80000gn/T/review-closure-egz3gjnw/reviews/round-1.md>)

Original documents and history were preserved. No implementation, commits, tags, packages, or external actions were performed.