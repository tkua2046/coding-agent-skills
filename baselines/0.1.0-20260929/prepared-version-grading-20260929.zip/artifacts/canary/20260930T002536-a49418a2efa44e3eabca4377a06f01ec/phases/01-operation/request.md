Use the version/notes preparation operation in skills/dev-workflow. Update only VERSION and CHANGELOG.md according to DEVNOTES.md and actual completed behavior. Report the chosen version and reason. No release execution, commit, tests/build, tag or publication.

Complete this metadata-preparation operation within a 300-second usable target and 600-second hard cap, including tool/model waits and the final response. Do not add another operation to use the allowance.


For this requested metadata-preparation operation: 300-second usable target, 600-second hard cap, including model/tool waits and final response. These timing limits do not expand the operation scope.
