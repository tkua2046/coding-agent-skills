Use the version/notes preparation operation in skills/dev-workflow. Update only VERSION and CHANGELOG.md according to DEVNOTES.md and actual completed behavior. Report the chosen version and reason. No release execution, commit, tests/build, tag or publication.

Complete this metadata-preparation operation within a 300-second usable target and 600-second hard cap, including tool/model waits and the final response. Do not add another operation to use the allowance.


For this requested metadata-preparation operation: 300-second usable target, 600-second hard cap, including model/tool waits and final response. These timing limits do not expand the operation scope.


Use only this fixture and the supplied skills/. Read fixture AGENTS.md if present. This phase is a fresh context. Preserve prior reports. CANARY_PYTHON points to the prepared Python runtime. Do not install packages or use external services.

Workflow worker clock: 0.000s consumed; usable target remaining: 300.000s; hard budget remaining: 600.000s; this invocation cap: 600.000s.
