Chosen version: **1.3.0** — the opt-in JSON format is a backward-compatible public option, requiring a minor bump from 1.2.0.

[VERSION](/private/var/folders/7w/2jmyflc53t3fhsxzmf590wk80000gn/T/canary-o3jovzqz/worker/VERSION) and [CHANGELOG.md](/private/var/folders/7w/2jmyflc53t3fhsxzmf590wk80000gn/T/canary-o3jovzqz/worker/CHANGELOG.md) were already correctly prepared for 1.3.0 dated 2026-09-07, so no second bump or file change was made.

No tests, build, commit, tag, release, or publication was performed.