"""Retain this reviewed campaign and verify a fresh offline restoration."""
import hashlib
import json
from pathlib import Path
import stat
import tempfile
import zipfile

from tools import canary

repo = Path.cwd()
campaign = repo / "artifacts/prepared-version-grading-20260929"
archive = campaign.with_suffix(".zip")
verification_path = campaign.with_name(campaign.name + "-verification.json")
assert not archive.exists() and not verification_path.exists()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


records = json.loads((campaign / "record-index.json").read_text())
changes = json.loads((campaign / "source-delta.json").read_text())
for change in changes:
    assert sha(repo / change["path"]) == change["after_sha256"]
    assert sha(campaign / "current-source" / change["path"]) == change["after_sha256"]
    assert sha(campaign / "before-source" / change["path"]) == change["before_sha256"]
for name, expected in json.loads((campaign / "unchanged-contract-check.json").read_text()).items():
    assert sha(repo / name) == expected
for name in ("tools/canary.py", "tools/canary_runtime.py", "evals/graders/review.md"):
    assert sha(repo / name) == sha(campaign / "supporting-source" / name)
for record in records:
    path = repo / record["path"]
    assert sha(path) == record["sha256"]
    actual = canary.verified_record(path)
    assert actual["status"] == record["status"]
    assert actual["kind"] == record["kind"]
    expected_engine = actual.get("engine", actual.get("identity", {}).get("engine"))
    assert canary.engine_identity(repo) == expected_engine

package = repo / "artifacts/release-version-fix-20260929/coding-agent-skills-local-20260929-r3.zip"
assert sha(package) == "6d8720d5de74df481a4a486ca15bc3cbc83e48cd33f375457776e59e2545f13c"
canonical = canary.skill_files(repo, [p.name for p in (repo / "skills").iterdir() if p.is_dir()])
with zipfile.ZipFile(package) as bundle:
    packaged = {name.split("/.agents/", 1)[1]: bundle.read(name) for name in bundle.namelist() if "/.agents/skills/" in name and not name.endswith("/")}
assert canonical == packaged
case = repo / "evals/cases/smoke-version-prepared"
case_copy = campaign / "supporting-source/evals/cases/smoke-version-prepared"
assert not case_copy.exists()
for name, data in canary.files(case).items():
    target = case_copy / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)

payload = {}
for path in campaign.rglob("*"):
    assert not path.is_symlink()
    if path.is_file():
        payload[str(path.relative_to(repo))] = path
for record in records:
    for path in (repo / record["path"]).parent.rglob("*"):
        assert not path.is_symlink()
        if path.is_file():
            payload[str(path.relative_to(repo))] = path
payload[str(package.relative_to(repo))] = package
manifest = {name: sha(path) for name, path in sorted(payload.items())}
with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED) as zipped:
    for name, path in sorted(payload.items()):
        zipped.write(path, name)
    zipped.writestr("manifest.json", json.dumps(manifest, indent=2) + "\n")

with tempfile.TemporaryDirectory(prefix="verify-prepared-version-") as tmp:
    restored = Path(tmp).resolve()
    with zipfile.ZipFile(archive) as zipped:
        assert zipped.testzip() is None
        assert len(zipped.namelist()) == len(set(zipped.namelist()))
        for entry in zipped.infolist():
            assert not Path(entry.filename).is_absolute()
            assert ".." not in Path(entry.filename).parts
            assert not stat.S_ISLNK(entry.external_attr >> 16)
        zipped.extractall(restored)
    for name, expected in manifest.items():
        assert sha(restored / name) == expected, name
    for record in records:
        path = restored / record["path"]
        assert sha(path) == record["sha256"]
        actual = canary.verified_record(path)
        for field in ("source_report", "calibration_ref"):
            if field in actual:
                reference = path.parent.parent / actual[field]["path"]
                assert sha(reference) == actual[field]["sha256"]
                canary.verified_record(reference)

verification = {
    "archive": str(archive.relative_to(repo)),
    "sha256": sha(archive),
    "bytes": archive.stat().st_size,
    "payload_files": len(manifest),
    "crc_ok": True,
    "all_restored_hashes_match": True,
    "three_restored_records_verified": True,
    "restored_report_dependencies_resolve": True,
    "original_worker_report_unchanged": True,
    "seven_current_source_files_match_delta": True,
    "case_rubric_grader_engine_unchanged": True,
    "r3_package_and_all_canonical_skills_unchanged": True,
}
archive.with_suffix(".zip.sha256").write_text(verification["sha256"] + "  " + archive.name + "\n")
verification_path.write_text(json.dumps(verification, indent=2) + "\n")
print(json.dumps(verification, indent=2))
