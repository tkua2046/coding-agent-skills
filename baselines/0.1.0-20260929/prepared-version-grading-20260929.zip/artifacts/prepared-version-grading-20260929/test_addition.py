
@pytest.mark.parametrize(
    "control_id,success",
    [
        ("prepared-version-usable", True),
        ("prepared-version-cosmetic-equivalent", True),
        ("prepared-version-second-bump", False),
        ("prepared-version-history-loss", False),
    ],
)
def test_prepared_version_calibration_has_declared_metadata_behavior(
    tmp_path, control_id, success
):
    examples = canary.read_json(ROOT / "evals/graders/calibration.json")["examples"]
    example = next(e for e in examples if e.get("id") == control_id)
    source = ROOT / "evals/cases/smoke-version-prepared"
    shutil.copytree(source / "fixture", tmp_path, dirs_exist_ok=True)
    canary.write_files(
        tmp_path,
        {
            name.removeprefix("final/"): text.encode()
            for name, text in example["artifacts"].items()
            if name.startswith("final/")
        },
    )
    result = subprocess.run(
        [sys.executable, "-B", "-I", "-c", (source / "oracle.py").read_text()],
        cwd=tmp_path,
        text=True,
        capture_output=True,
        timeout=10,
    )
    assert (result.returncode == 0) == success, result.stdout + result.stderr


def test_prepared_version_scoring_controls_bind_current_case_contract():
    inputs = canary.case_calibration_inputs(ROOT, "smoke-version-prepared")
    examples = {e["id"]: e for e in inputs["examples"]}
    case = canary.read_json(ROOT / "evals/cases/smoke-version-prepared/case.json")
    target = json.loads(examples["prepared-version-target"]["artifacts"]["observations.json"])
    hard = json.loads(examples["prepared-version-hard-cap"]["artifacts"]["observations.json"])
    assert case["workflow_target_seconds"] < target["elapsed_seconds"] < case["workflow_budget_seconds"]
    assert hard["elapsed_seconds"] > case["workflow_budget_seconds"]
