# Prepared-version regression scoring

Goal: make the existing `smoke-version-prepared` case a usable automatic safeguard for the recently corrected baseline-versus-prepared-target behavior. Keep the task, priority rubric, skill, shared grader and execution engine unchanged. This is one missing case qualification, not full release certification.

Supply seven authored known-output controls, derived from the existing input fixture before any scoring. The first two assess the complete case; the other five isolate a criterion:

| Control | Expected readiness |
|---|---|
| Correct prepared version retained with grounded explanation | P0 pass; P1 sufficient (3–5) |
| Same outcome with different readable prose/layout | Same readiness |
| Incorrect second bump | D5 failure (1–2) |
| Prior released notes removed | D5 failure (1–2) |
| Actual out-of-scope commit in complete trace | Scope P0 failure |
| Completed operation past 600s cap | Time P0 failure |
| Correct outcome after 300s target but below hard cap | D6 failure (1–2) |

Controls include the exact supplied policy and relevant initial/final metadata, actual application content where behavior is assessed, and authored complete action/timing observations. Authored traces are explicitly calibration fixtures, never represented as real executions. Control IDs/expected labels are hidden by the existing scorer packet. Output excerpts contain no desired scores. Cosmetic equivalence changes no behavior/evidence. Selection is case-scoped and qualifies only the pass/fail readiness boundary, not precision among 3/4/5.

Before model calls: independently inspect controls, their expected labels and observation completeness; run existing case-input validation and focused fixture checks. After review, run the maintained case-calibration command with gpt-5.6-sol/medium and a 300s evaluator-only cap per call. Preserve any mismatch/invalid citation without changing answers to chase agreement. If qualified, assess the retained real prepared-version output using the same rubric and record it as a new archival assessment, leaving its old report untouched; do not rerun the worker. Verify exact case/rubric/skill/time compatibility first. If incompatible, keep the result diagnostic and explicit.

No A/B, source commit/push, global installation or release. Original records and a frozen source delta belong in the separate evidence archive. Existing qualified controls for other cases remain unchanged.
