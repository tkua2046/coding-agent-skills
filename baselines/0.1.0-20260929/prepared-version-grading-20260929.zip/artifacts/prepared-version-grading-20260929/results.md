# Prepared-version scoring safeguard

The existing prepared-version regression now has a reusable, case-scoped readiness qualification. Skills, the task, its rubric, shared scorer and execution engine are unchanged. This improves regression protection; it is not another skill implementation or full release certification.

| Check | Result |
|---|---|
| Correct prepared target | Pass |
| Equivalent readable format | Pass |
| Incorrect second bump | Rejected |
| Removed historical release notes | Rejected |
| Unauthorized commit | Rejected |
| 601s completion against 600s hard cap | Rejected by P0 |
| 301s completion against 300s usable target | Rejected by P1, distinct from the hard cap |
| Separate assessment of archived real output | Pass; old worker report unchanged |

Seven scorer controls matched **7/7**, with valid literal citations. They qualify readiness (P1 1–2 versus 3–5), not meaningful discrimination among 3, 4 and 5. In particular, high raw grades on sufficient positive examples do not establish exceptional quality or improvement.

The controls used **gpt-5.6-sol / medium**, 300s per evaluator call, totaling **492.365s**. The archived-output assessment used the same settings and took **184.035s**. There were **eight scorer calls, zero new skill-worker calls**. Evaluation overhead is separate from the old worker's **61.510s**. No causal speed or repeatability claim.

## What changed and why it is useful

Seven reviewed known-output examples were added to the existing calibration data, without changing earlier examples or expected labels. Usable/cosmetic controls cover the full case; the five negative examples isolate one criterion each. The authored observer facts are explicitly fictional calibration inputs, not real executions.

Five new deterministic checks apply the existing metadata oracle to both correct and defective outputs and bind the time contrasts to the actual case budgets. They protect against fixture drift; they do not substitute for the LLM scorer.

The maintained runner accepts this current case-specific qualification. Future skill-only edits can reuse it while the case inputs, rubric, scorer, engine, environment and scoring settings remain applicable. It cannot authorize another case or release. To refresh deliberately:

```sh
.venv/bin/python -m tools.canary calibrate --case smoke-version-prepared --model gpt-5.6-sol --effort medium --timeout 300
```

The new archive assessment reuses exact raw worker evidence, not an author's retelling. Its request, rubric, runtime skill and engine match the current case. The case changed from v1 to v2 only because the oracle now tolerates harmless trailing blank lines. This distinction is recorded: the original report remains inconclusive, and the new assessment is not a fresh current-case worker result or release record.

## Inspect the evidence

- [Proposal](proposal.md) and [original independent review](proposal-review-original.json).
- [Frozen proposed controls](proposed-controls.json), [selected runner inputs](selected-inputs.json) and [observed judgments/times](calibration-outcomes.json).
- [Verified qualification](qualification-verified.json), [compatibility comparison](replay-compatibility.json) and [raw record index](record-index.json).
- [Actual calibration](../canary/20260930T005750-e7c230056bff48b090452ca5dfe92a27/report.json).
- [Separate archival assessment](../canary/20260930T010615-f07c368a589b4d6b85118d3f88b633f4/report.json).
- [Original real-worker result](../canary/20260930T002536-a49418a2efa44e3eabca4377a06f01ec/report.json), retained unchanged with its complete record.
- [Independent outcome audit](outcome-review-original.json), including citation and score-precision limits.

The scorer packet excludes earlier numeric grades, manual reviews and desired verdicts. Case-controlled input and artifact hashes are retained. Raw judgments and transcripts survive; no criterion, expected answer or prompt was revised after observing the scores.

## Verification and remaining limits

The full pre-commit gate passed **390 tests, 94% tool coverage, 137.16s**; the earlier focused run passed **29 checks**. Documentation-only completion then passed scoped static checks. Those numbers describe tooling/fixture validation, not 390 skill behavior tests.

The r3 skill bundle is unchanged. Other cases' incomplete qualification, upper-score precision, whole-workflow timing and complete release acceptance remain outside this case-specific result. No source commit/push, global installation or release was performed.

Independent audit found all readiness conclusions correct, but the archival scope row's citations prove only unchanged files/Git state. They do not independently exclude tests, builds or publication. The preserved complete worker trace provides that support. Treat this as a citation-completeness limit, not a false readiness verdict, and do not claim fully qualified citation quality.
