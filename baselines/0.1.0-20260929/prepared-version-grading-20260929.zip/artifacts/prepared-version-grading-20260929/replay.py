"""Reassess one retained prepared-version result after current case qualification."""
import json,sys,tempfile
from pathlib import Path
from tools import canary
root=Path.cwd();campaign=root/'artifacts/prepared-version-grading-20260929'
old=root/'artifacts/canary/20260930T002536-a49418a2efa44e3eabca4377a06f01ec'
settings={'model':'gpt-5.6-sol','effort':'medium','timeout_seconds':300}
qualification=Path(sys.argv[1]).resolve()
info=canary.check_calibration(root,qualification,settings,canary.environment(),case_id='smoke-version-prepared')
canary.verified_record(old/'report.json')
compatibility=canary.read_json(campaign/'replay-compatibility.json')
assert compatibility['same_rubric'] and compatibility['same_request'] and compatibility['same_runtime_skill']
rubric=canary.read_json(root/'evals/cases/smoke-version-prepared/rubric.json')
assert rubric==canary.read_json(old/'inputs/case/rubric.json')
directory,report=canary.new_record(root,'archived-prepared-version-assessment')
report.update(settings=settings,environment=canary.environment(),engine=canary.engine_identity(root),grader=canary.case_grading_identity(root),case_id='smoke-version-prepared',source_report={'path':str(old.relative_to(directory.parent)/'report.json'),'sha256':canary.digest((old/'report.json').read_bytes())},calibration_ref={'path':str(qualification.relative_to(directory.parent)),'sha256':info['sha256']},interpretation='New assessment of archived output. Original worker case v1, current case v2 differs only in harmless trailing-blank-line oracle handling. No fresh worker or release acceptance.')
canary.save(directory/'attempt.json',report);canary.save(directory/'rubric.json',rubric)
(directory/'grader-prompt.md').write_text((root/'evals/graders/review.md').read_text())
canary.save(directory/'compatibility.json',compatibility)
try:
 with tempfile.TemporaryDirectory(prefix='prepared-replay-') as temp:
  packet=Path(temp).resolve()/'packet';packet.mkdir()
  canary.write_files(packet/'artifacts',canary.files(old/'phases'))
  canary.write_files(packet/'initial',canary.files(old/'initial'))
  case=canary.read_json(old/'inputs/case/case.json')
  canary.write_files(packet/'requests',{p['id']+'.md':(old/'inputs/case'/p['request']).read_bytes() for p in case['phases']})
  packet_hashes=canary.hashes(canary.files(packet))
  assert packet_hashes==canary.read_json(campaign/'planned-replay-input-sha256.json')
  canary.save(directory/'packet-input-sha256.json',packet_hashes)
  isolation=canary.runtime.probe(packet,root/'evals/cases/smoke-version-prepared/rubric.json');canary.save(directory/'isolation.json',isolation)
  if not isolation['passed']:raise RuntimeError('Scorer isolation failed')
  execution,grade,status=canary.grade_packet(root,packet,directory/'grade-reply.json',rubric,settings)
  canary.save(directory/'grade.json',grade);canary.require_completed(execution)
  report.update(status=status,elapsed_seconds=execution['elapsed_seconds'])
except (Exception,KeyboardInterrupt) as exc:report['error']=f'{type(exc).__name__}: {exc}'
result=canary.finish(directory,report)
print(json.dumps({'report':str(result),'status':report['status'],'error':report.get('error')}))
