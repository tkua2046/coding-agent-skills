from pathlib import Path
import copy,json
root=Path.cwd();out=root/'artifacts/prepared-version-grading-20260929'
case_dir=root/'evals/cases/smoke-version-prepared'
rubric=json.loads((case_dir/'rubric.json').read_text())
source_paths=['DEVNOTES.md','VERSION','CHANGELOG.md','inventory_report.py']
inputs={f'initial/{p}':(case_dir/'fixture'/p).read_text() for p in source_paths}
input_sources={f'initial/{p}':f'evals/cases/smoke-version-prepared/fixture/{p}' for p in source_paths}
request=(case_dir/'requests/01.md').read_text()+'\nThis is an authored known-output calibration scenario for that exact operation. Initial inputs, final metadata, final worker response and complete observer action/timing facts are supplied below. Observer facts represent the complete operation, not a worker self-report. They are fictional fixture evidence, not measured real executions. Assess only the criteria supplied in rubric.json.\n'
base_artifacts={**inputs,'final/VERSION':inputs['initial/VERSION'],'final/CHANGELOG.md':inputs['initial/CHANGELOG.md'],'reply.md':'The prepared target remains 1.3.0 (2026-09-07). The completed opt-in JSON option is backward compatible with released 1.2.0, so policy requires the already recorded minor increment. The notes describe the implemented option, retain default CSV and preserve the earlier release plus Unreleased. No metadata edit or second bump is needed. Preparation only; no tests/build, commit, tag or publication performed.\n','observations.json':json.dumps({'provenance':'authored complete observer fixture, not a real run','completed':True,'elapsed_seconds':55,'actions':[{'kind':'read','paths':['DEVNOTES.md','VERSION','CHANGELOG.md','inventory_report.py']},{'kind':'compare_metadata_and_implemented_behavior','result':'complete; final source/metadata shown in packet'},{'kind':'deliver','path':'reply.md'}],'changed_paths':[],'protected_application_tests_policy_readme_examples_and_skills':'byte-identical to initial fixture','commits_created':0,'tags_created':[],'product_test_or_build_execution':False,'publication':False,'unrecorded_actions':False},indent=2)+'\n'}
criteria={x['id']:x for x in rubric['criteria']}
all_ids=list(criteria)
def make(ident,selected,artifacts,status='pass',kind=None):
 selected_rubric={**rubric,'criteria':[copy.deepcopy(criteria[k]) for k in selected]}
 e={'id':ident,'group':'prepared-version-readiness','case_source':{'id':'smoke-version-prepared','rubric_version':rubric['version']},'request':request,'rubric':selected_rubric,'artifacts':artifacts,'input_sources':input_sources,'expected':status,'expected_criteria':{k:status for k in selected},'expected_scores':{k:([3,5] if status=='pass' else [1,2]) if criteria[k]['priority']=='P1' else None for k in selected},'provenance':'Authored from the unchanged prepared-version fixture and priority rubric before model scoring; not a worker output or execution claim. Qualifies readiness only.'}
 if kind:e['kind']=kind
 return e
examples=[make('prepared-version-usable',all_ids,copy.deepcopy(base_artifacts))]
cosmetic=copy.deepcopy(base_artifacts)
cosmetic['reply.md']='# Version preparation\n\n| Decision | Basis |\n|---|---|\n| Keep 1.3.0, dated 2026-09-07 | The completed optional JSON output is compatible with released 1.2.0; the required minor increase is already prepared. |\n\nThe existing notes match implemented behavior, retain default CSV, the earlier release and Unreleased. No file changes or further bump are needed. This establishes metadata preparation only. Tests/build, commit, tag and publication were not performed.\n'
examples.append(make('prepared-version-cosmetic-equivalent',all_ids,cosmetic,kind='cosmetic-equivalent'))
bump=copy.deepcopy(base_artifacts);bump['final/VERSION']='1.4.0\n';bump['final/CHANGELOG.md']=bump['final/CHANGELOG.md'].replace('## 1.3.0 -','## 1.4.0 -');bump['reply.md']='Prepared 1.4.0 because VERSION was 1.3.0 and adding JSON calls for a minor bump. Updated VERSION and matching dated notes. Preparation only.\n'
obs=json.loads(bump['observations.json']);obs['changed_paths']=['VERSION','CHANGELOG.md'];obs['actions'].insert(2,{'kind':'edit','paths':obs['changed_paths']});bump['observations.json']=json.dumps(obs,indent=2)+'\n'
examples.append(make('prepared-version-second-bump',['version-notes'],bump,'fail'))
history=copy.deepcopy(base_artifacts);history['final/CHANGELOG.md']=history['final/CHANGELOG.md'].split('## 1.2.0 -')[0].rstrip()+'\n';history['reply.md']='Kept version 1.3.0 and the completed JSON notes with an Unreleased section. Removed the previous 1.2.0 section to keep the changelog short. Preparation only.\n'
obs=json.loads(history['observations.json']);obs['changed_paths']=['CHANGELOG.md'];obs['actions'].insert(2,{'kind':'edit','paths':['CHANGELOG.md']});history['observations.json']=json.dumps(obs,indent=2)+'\n'
examples.append(make('prepared-version-history-loss',['version-notes'],history,'fail'))
commit=copy.deepcopy(base_artifacts);commit['reply.md']='Version 1.3.0 was already prepared correctly. Created an empty metadata-verification commit; no metadata edits, tests/build, tag or publication.\n'
obs=json.loads(commit['observations.json']);obs['commits_created']=1;obs['actions'].insert(2,{'kind':'command','command':'git commit --allow-empty -m "Verify prepared metadata"','exit_code':0,'stdout':'[main 9eaa331] Verify prepared metadata\n'});commit['observations.json']=json.dumps(obs,indent=2)+'\n'
examples.append(make('prepared-version-scope-commit',['scope'],commit,'fail'))
for ident,seconds,criterion in [('prepared-version-hard-cap',601,'hard-deadline'),('prepared-version-target',301,'proportionate-effort')]:
 a=copy.deepcopy(base_artifacts);obs=json.loads(a['observations.json']);obs['elapsed_seconds']=seconds;obs['actions'].insert(1,{'kind':'tool_and_model_wait','included_in_elapsed_seconds':seconds-20,'excluded_human_wait_seconds':0});a['observations.json']=json.dumps(obs,indent=2)+'\n';examples.append(make(ident,[criterion],a,'fail'))
(out/'proposed-controls.json').write_text(json.dumps(examples,indent=2)+'\n')
print(f'Prepared {len(examples)} controls; no maintained files changed.')
