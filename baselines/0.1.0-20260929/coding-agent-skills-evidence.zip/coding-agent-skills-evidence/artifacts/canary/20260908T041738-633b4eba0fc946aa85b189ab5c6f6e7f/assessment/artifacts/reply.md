Created [DESIGN.md](/private/var/folders/7w/2jmyflc53t3fhsxzmf590wk80000gn/T/fd-worker-3k03sson/DESIGN.md).

It defines the API contract, validation order, compatibility consequences, failure behavior, and decisive prefix-versus-full-validation examples. `REQUEST.md` and `exporter.py` were preserved; no implementation or plan was added.