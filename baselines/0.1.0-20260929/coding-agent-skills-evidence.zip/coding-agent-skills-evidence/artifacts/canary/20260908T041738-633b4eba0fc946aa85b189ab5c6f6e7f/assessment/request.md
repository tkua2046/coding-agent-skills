Use skills/feature-design to draft DESIGN.md for REQUEST.md against exporter.py. No prior design exists. Explain the behavior, choice, consequence and decisive examples so a developer can act. Design only; preserve inputs. Do not implement or create an implementation plan.


This is one bounded local operation with supplied prerequisites. Reach a usable final response within 300 seconds; hard limit 600 seconds, including the final readability edit. Preserve the original operation scope; no implementation/commit/tag/publication unless that original request expressly includes it.

Use only this fixture and supplied skills/. Read fixture AGENTS.md. CANARY_PYTHON is the prepared interpreter. No downloads/external services.
