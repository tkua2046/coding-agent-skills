# Limited row export

## Decision

Change the callable contract to `export_rows(text, limit=None)`. Omitting `limit`, or passing `None`, returns all rows exactly as today. A non-negative integer returns at most that many rows from the start of the CSV, in input order. The argument may be passed positionally or by keyword.

The limit applies only to the returned result. The exporter must still consume and validate every row before returning, including rows after the requested prefix. Only after the complete input has passed the existing stock-row validation is the result restricted to the first `limit` rows. This keeps validation as a guarantee about the supplied CSV rather than only about the rows the caller asks to receive.

`limit` is valid when it is `None` or a non-negative integer. Booleans are not accepted as integers for this API. Reject other values, such as `"2"`, `2.0`, and `True`, with `TypeError`; reject a negative integer with `ValueError`. Validate the argument before processing the CSV so an invalid call has a deterministic argument error regardless of the CSV contents.

## Consequences and compatibility

- Existing `export_rows(text)` callers retain the same list result, ordering, full-input validation, and row dictionaries.
- `limit=0` returns an empty list only after the entire input validates. A limit larger than the row count returns all rows.
- A limited call still has work and memory proportional to the complete input. It is not an early-stop or streaming interface, which is necessary to detect invalid later rows and preserves the existing list return type.
- Row parsing and validation behavior is otherwise unchanged. In particular, a missing SKU or negative quantity continues to raise `ValueError("invalid stock row")`; errors already produced while interpreting malformed quantity data are not redefined by this feature.
- The function has no persistent or external effects. Any argument or row error returns no partial result, and the caller may retry with corrected arguments or CSV text.

## Decisive examples

Given valid input:

```csv
sku,quantity
A,3
B,0
C,8
```

`export_rows(text, limit=2)` returns the dictionaries for `A` and `B`; `export_rows(text)`, `export_rows(text, limit=None)`, and `export_rows(text, limit=10)` return all three. `export_rows(text, limit=0)` returns `[]`, after validating all three rows.

The later-row failure rule is decisive for this input:

```csv
sku,quantity
A,3
B,-1
```

`export_rows(text, limit=1)` raises `ValueError("invalid stock row")`; it must not return the otherwise valid `A` prefix. The same failure occurs with `limit=0`, demonstrating that a limit does not reduce validation scope.

Calling with `limit=-1` raises `ValueError` before CSV processing. Calling with `limit="1"`, `limit=1.0`, or `limit=True` raises `TypeError` before CSV processing.

## Source

This decision implements the requirements in `REQUEST.md` against the current behavior in `exporter.py`. No streaming behavior or dependency changes are introduced.
