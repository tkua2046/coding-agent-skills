def render(value):
    return value.upper()
