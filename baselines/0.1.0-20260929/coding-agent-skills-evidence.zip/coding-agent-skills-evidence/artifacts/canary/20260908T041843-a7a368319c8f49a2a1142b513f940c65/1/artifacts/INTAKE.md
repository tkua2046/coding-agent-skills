Both promises will hold for every Unicode string: keep exactly value.upper() and preserve string length. No unresolved question. Next implement.
