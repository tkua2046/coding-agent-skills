"""Revalidate unchanged captured grades under the reviewed null-metadata citation rule; no model calls."""
import importlib.util
import json
from pathlib import Path
import sys
module_path=Path(__file__).with_name('pilot-v2.py').resolve()
spec=importlib.util.spec_from_file_location('fd_v2',module_path)
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
for supplied in sys.argv[1:]:
    source=Path(supplied).resolve(); old=m.c.verified_record(source)
    case_id=old['case_id']; directory,report=m.base_record('feature-design-numeric-controls',case_id)
    report.update(revalidation_only=True, model_calls=0, prior={'path':str(source),'sha256':m.c.digest(source.read_bytes())}, controls_sha256=old['controls_sha256'])
    (directory/'revalidation-driver.py').write_bytes(Path(__file__).read_bytes())
    try:
        assert old['kind']=='feature-design-numeric-controls' and 'self_test' not in old
        assert {k:v for k,v in old['binding'].items() if k!='driver'}=={k:v for k,v in report['binding'].items() if k!='driver'}
        controls=m.c.read_json(source.parent/'inputs.json'); m.c.save(directory/'inputs.json',controls)
        outcomes=[]
        for i,e in enumerate(controls['examples']):
            packet=source.parent/str(i)
            execution=m.c.read_json(packet/'execution.json'); assert execution['completed']
            assert m.c.read_json(packet/'rubric.json')==m.rubric(case_id)
            grade=json.loads(execution['reply']); assert grade==m.c.read_json(packet/'reply.json')
            assessment=m.validate(grade,m.rubric(case_id),packet)
            scores={x['id']:x['score'] for x in grade['criteria']}
            ranges=e['control_metadata']['expected_score_ranges']; assert ranges and set(ranges)<=set(scores)
            matched=all(scores[k] is not None and v['min']<=scores[k]<=v['max'] for k,v in ranges.items())
            outcome={'id':e['id'],'matched':matched,'scores':scores,'assessment':assessment,'original_grade_sha256':m.c.digest((packet/'reply.json').read_bytes())}
            outcomes.append(outcome); m.c.save(directory/str(i)/'revalidation.json',outcome)
        report.update(outcomes=outcomes,status='ready' if all(x['matched'] for x in outcomes) else 'not-established')
        m.c.verified_record(source)
        assert m.c.digest(source.read_bytes())==report['prior']['sha256']
    except (Exception,KeyboardInterrupt) as error:
        report.update(status='not-established',error=f'{type(error).__name__}: {error}')
    print(m.c.finish(directory,report),flush=True)
