# Review of Ordering Worksheet D1

## Verdict

**Changes required.** The proposed filter-before-validation path cannot satisfy the request's all-or-nothing validation contract. D1 also omits an explicit requirement to document the new flag. The default path and the proposed reuse of the atomic writer are otherwise consistent with the request.

Review mode: independent static review of `DESIGN.md` against `REQUEST.md`, `inventory.py`, and the supplied QA/configuration files. No product files were changed and no runtime checks were performed.

## Blocking finding: omitted rows bypass whole-file validation

**Location:** `DESIGN.md`, lines 3–7, especially “discard stocked rows before checking labels, row shape and duplicate SKUs” and the duplicate-SKU example.

**Trigger:** `--needs-order` is used and a row with `quantity > reorder_at` has a missing `sku` or `name`, a bad column count, or a SKU duplicated elsewhere in the file.

**Consequence:** D1 would accept input that the contract says must fail. `REQUEST.md` lines 11–15 require validation of the entire input, including rows excluded from the worksheet, and specifically prohibit ignoring an in-stock duplicate. The current loader also establishes this behavior by validating row shape and required values and tracking duplicate normalized SKUs across the full file (`inventory.py` lines 20–42). Filtering earlier would weaken that invariant and could replace the destination with an apparently valid partial worksheet instead of returning the existing error status while preserving its previous bytes.

For example, with a pre-existing destination and this input:

```csv
sku,name,quantity,reorder_at
X,Stocked,10,2
X,Needed,1,2
```

D1 says only the second row participates in duplicate checks, so the export succeeds. The required behavior is an error because normalized SKU `X` occurs twice; the destination must remain byte-for-byte unchanged. A stocked row such as `Y,,10,2` or `Y,Stocked,10,2,extra` must likewise fail even though it would not be exported.

**Required correction:** Validate and normalize the complete input first, using the existing whole-file validation semantics. Only after validation succeeds should the flag path select normalized rows where `quantity <= reorder_at`, preserving their source order and row shape, and pass that result to the existing atomic writer. Any validation or write failure must retain the current error exit behavior and preserve the previous destination bytes. Remove or reverse D1's duplicate example: both `X` rows must participate in duplicate detection regardless of whether either would be selected.

**Verification boundary:** Cover an excluded row with each class of error named by the request (duplicate SKU, missing required field, malformed number, and bad row shape), including the duplicate example above, and verify error status plus unchanged destination bytes. Also cover equality as selected, greater-than as omitted, mixed rows retaining source order, header-only/no-match input producing `[]`, and an unchanged no-flag export.

## Non-blocking completeness finding: required user documentation is absent

**Location:** `DESIGN.md`, lines 1–7.

**Trigger:** The feature is implemented from D1 as written.

**Consequence:** The implementation can omit the request's explicit requirement that both CLI help and the README explain `--needs-order` (`REQUEST.md` line 20). Merely naming the flag in the design does not retain those two user-facing deliverables.

**Correction:** Add that the CLI option's help text and README describe the flag as optional, state the inclusive `quantity <= reorder_at` rule, and make clear that omitting it preserves the complete export. This does not require broader documentation or a new interface.
