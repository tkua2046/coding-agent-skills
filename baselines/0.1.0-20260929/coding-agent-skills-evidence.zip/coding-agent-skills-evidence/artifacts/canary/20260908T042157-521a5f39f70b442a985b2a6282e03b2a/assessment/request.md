Use skills/feature-design to independently review DESIGN.md against REQUEST.md and the supplied application. Write REVIEW.md with the verdict, consequential findings, examples and minimal corrections. Static review only; preserve all supplied inputs. No implementation or second artifact review.


This is one bounded local operation with supplied prerequisites. Reach a usable final response within 300 seconds; hard limit 600 seconds, including the final readability edit. Preserve the original operation scope; no implementation/commit/tag/publication unless that original request expressly includes it.

Use only this fixture and supplied skills/. Read fixture AGENTS.md. CANARY_PYTHON is the prepared interpreter. No downloads/external services.
