# Export limit design
Add optional limit N and return as soon as N rows have been read; default unlimited.
This minimizes work on large files. For A,1 / B,-1 and N=1, return A without parsing B.
N=0 returns [] immediately; negative/non-integer limits raise ValueError.
Next: implement this local change. This is proposed behavior, not executed code.
