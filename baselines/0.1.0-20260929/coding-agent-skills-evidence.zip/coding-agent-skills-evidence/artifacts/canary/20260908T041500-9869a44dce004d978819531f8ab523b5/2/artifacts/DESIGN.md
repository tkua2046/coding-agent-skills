# Export limit

## Choice

Add optional limit N, default unlimited. Validate every row before returning the first N in source order; retain the current in-memory loader. This keeps malformed rows outside the returned prefix visible as errors. Next: implement this bounded API change when requested; this document is a proposal, not an executed feature.

## Behavior and rationale

Reject negative and non-integer limits. N=0 returns [] only after full validation. For sku,quantity rows A,1 / B,-1 with N=1, raise ValueError instead of returning A. For valid A,1 / B,2, N=1 returns A; omitted limit returns both in source order. Validation before slicing uses the existing materialized rows; the local files do not justify streaming or additional dependencies. Caller rendering stays unchanged.
