# Oral-history transcript viewer

An editor uses exported TSV cues to locate audio passages. Times are milliseconds;
text is displayed as supplied. The loader preserves file order and checks timing.

Show a transcript: `python transcript.py examples/interview.tsv`

Find a literal phrase and show one neighboring cue on each side:

`python transcript.py examples/interview.tsv --find "river path" --context 1`

Search is Unicode case-insensitive, treats punctuation literally, and does not match
across cue boundaries. Omit `--context` to show only matching cues. A search with no
matches succeeds without printing anything.

Run checks: `python -m unittest discover -s tests -v`

`Cue(start_ms, end_ms, text)`, `load_cues(path)`, `find_cues(cues, phrase, *,
context=0)` and `render_cues(cues)` are available to local scripts. The loader and
rendering interfaces remain compatible.
