import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from transcript import Cue, find_cues, load_cues, render_cues, timestamp


class TranscriptTests(unittest.TestCase):
    def test_load_preserves_order_and_text(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parents[1]) as tmp:
            path = Path(tmp) / "cues.tsv"
            path.write_text("start_ms\tend_ms\ttext\n0\t1500\t Hello! \n1000\t2000\tAgain\n")
            self.assertEqual(load_cues(path), [Cue(0, 1500, " Hello! "), Cue(1000, 2000, "Again")])

    def test_rejects_backward_interval(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parents[1]) as tmp:
            path = Path(tmp) / "bad.tsv"
            path.write_text("start_ms\tend_ms\ttext\n200\t100\tbad\n")
            with self.assertRaises(ValueError):
                load_cues(path)

    def test_rendering(self):
        self.assertEqual(timestamp(3723004), "01:02:03.004")
        self.assertEqual(render_cues([Cue(0, 1500, "Hello")]), "00:00:00.000 --> 00:00:01.500 Hello")
        self.assertEqual(render_cues([]), "")

    def test_find_is_unicode_case_insensitive_and_literal(self):
        cues = [
            Cue(0, 100, "Die Straße, here"),
            Cue(100, 200, "STRASSE here"),
            Cue(200, 300, "Straße here"),
        ]
        self.assertEqual(find_cues(cues, "strasse,"), [cues[0]])

    def test_find_does_not_span_cues(self):
        cues = [Cue(0, 100, "literal"), Cue(100, 200, "phrase")]
        self.assertEqual(find_cues(cues, "literal phrase"), [])

    def test_find_merges_context_windows_in_source_order(self):
        cues = [Cue(i * 100, (i + 1) * 100, text) for i, text in enumerate(
            ["before", "repeat", "middle", "REPEAT", "after"]
        )]
        original = list(cues)
        result = find_cues(cues, "repeat", context=1)
        self.assertEqual(result, cues)
        self.assertEqual(cues, original)
        self.assertIs(result[1], cues[1])
        self.assertIs(result[3], cues[3])

    def test_find_preserves_supplied_phrase_whitespace(self):
        cues = [Cue(0, 100, "word"), Cue(100, 200, " word ")]
        self.assertEqual(find_cues(cues, " word "), [cues[1]])

    def test_find_rejects_invalid_arguments_even_without_cues(self):
        for phrase in ("", " \t\n", None):
            with self.subTest(phrase=phrase):
                with self.assertRaises(ValueError):
                    find_cues([], phrase)
        for context in (-1, 1.5, True):
            with self.subTest(context=context):
                with self.assertRaises(ValueError):
                    find_cues([], "valid", context=context)


class TranscriptCommandTests(unittest.TestCase):
    def run_command(self, contents, *arguments):
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parents[1]) as tmp:
            path = Path(tmp) / "cues.tsv"
            path.write_text(contents, encoding="utf-8")
            return subprocess.run(
                [sys.executable, "transcript.py", str(path), *arguments],
                cwd=Path(__file__).resolve().parents[1],
                text=True,
                capture_output=True,
                check=False,
            )

    def test_find_with_context_uses_existing_rendering(self):
        result = self.run_command(
            "start_ms\tend_ms\ttext\n0\t1000\tFirst\n1000\t2000\tNeedle\n2000\t3000\tLast\n",
            "--find", "needle", "--context", "1",
        )
        self.assertEqual(result.returncode, 0)
        self.assertEqual(
            result.stdout,
            "00:00:00.000 --> 00:00:01.000 First\n"
            "00:00:01.000 --> 00:00:02.000 Needle\n"
            "00:00:02.000 --> 00:00:03.000 Last\n",
        )
        self.assertEqual(result.stderr, "")

    def test_find_without_matches_has_empty_stdout(self):
        result = self.run_command(
            "start_ms\tend_ms\ttext\n0\t1000\tHaystack\n", "--find", "needle"
        )
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "")
        self.assertEqual(result.stderr, "")

    def test_default_command_is_unchanged(self):
        result = self.run_command("start_ms\tend_ms\ttext\n0\t1000\tFull transcript\n")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(
            result.stdout,
            "00:00:00.000 --> 00:00:01.000 Full transcript\n",
        )

    def test_search_errors_are_clean(self):
        cases = [
            (("--context", "1"), "--context requires --find"),
            (("--find", "needle", "--context", "-1"), "nonnegative integer"),
            (("--find", "   "), "non-whitespace text"),
        ]
        contents = "start_ms\tend_ms\ttext\n0\t1000\tMust not print\n"
        for arguments, message in cases:
            with self.subTest(arguments=arguments):
                result = self.run_command(contents, *arguments)
                self.assertNotEqual(result.returncode, 0)
                self.assertEqual(result.stdout, "")
                self.assertIn(message, result.stderr)
                self.assertNotIn("Traceback", result.stderr)


if __name__ == "__main__":
    unittest.main()
