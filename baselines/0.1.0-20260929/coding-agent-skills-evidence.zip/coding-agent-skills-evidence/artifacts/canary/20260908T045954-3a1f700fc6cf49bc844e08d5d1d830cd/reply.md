Implemented literal phrase search with neighboring-cue context.

- Added `find_cues()` with Unicode `casefold`, literal matching, argument validation, ordered deduplicated context, and no input mutation in [transcript.py](/private/var/folders/7w/2jmyflc53t3fhsxzmf590wk80000gn/T/interview-worker-zapgx_if/transcript.py:50).
- Added `--find PHRASE` and `--context N` CLI options with clean errors.
- Added API and CLI regression coverage in [test_transcript.py](/private/var/folders/7w/2jmyflc53t3fhsxzmf590wk80000gn/T/interview-worker-zapgx_if/tests/test_transcript.py).
- Added a working fixture-based example to [README.md](/private/var/folders/7w/2jmyflc53t3fhsxzmf590wk80000gn/T/interview-worker-zapgx_if/README.md:8):

```sh
python transcript.py examples/interview.tsv --find "river path" --context 1
```

Validation:

- 12 tests passed with `CANARY_PYTHON -m unittest discover -s tests -v`
- Documented command executed successfully
- `git diff --check` passed
- No packages, commits, or external services used

No known remaining functional limitations.