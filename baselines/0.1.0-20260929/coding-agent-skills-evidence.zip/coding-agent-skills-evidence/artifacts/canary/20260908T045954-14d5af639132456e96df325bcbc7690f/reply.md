Fixed the local commit gate in [tools/check.py](/private/var/folders/7w/2jmyflc53t3fhsxzmf590wk80000gn/T/interview-worker-ld50w1to/tools/check.py:20):

- Failed tests now return exit 1.
- Zero-test discovery now returns exit 1.
- Passing suite returns exit 0.

Verified:

- Installed pre-commit hook passed all 5 tests.
- Documentation-only commits were blocked for failing and empty suites.
- Scratch probes were removed.
- Only `tools/check.py` is modified.
- No candidate commit was created.