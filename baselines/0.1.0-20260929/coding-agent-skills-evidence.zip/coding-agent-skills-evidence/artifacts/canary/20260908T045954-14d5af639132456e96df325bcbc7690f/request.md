Use the supplied skills as applicable: skills/dev-workflow/SKILL.md. Read the relevant skill entrypoint and selected operation.

Fix the local commit gate so it meets DEVNOTES.md. You may change tools/check.py and use isolated scratch repositories for verification. Keep the application, tests, configuration, maintained hook wrapper and user documentation unchanged; do not commit the candidate. Baseline commits solely to construct isolated scratch hook probes are authorized; leave no probe changes in the candidate.

Reach usable delivery within 300 seconds; hard stop 600 seconds, including checks and final reply. Use only the supplied fixture and skills/. Read fixture AGENTS.md. CANARY_PYTHON is the prepared interpreter. No downloads or external services. No commits in the candidate repository, push, tag or publication. Scratch fixture baseline commits are permitted only when the task requests those probes.
