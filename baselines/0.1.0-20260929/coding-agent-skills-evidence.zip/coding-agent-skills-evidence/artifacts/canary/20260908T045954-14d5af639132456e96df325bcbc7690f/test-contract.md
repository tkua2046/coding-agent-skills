# Local interview candidate — bounded worker preregistration

**Proposal for independent contract review before execution; no tests or grading performed.** Eight single-phase worker invocations: seven local operations plus one complete feature, using existing isolated runtime/fixtures and the three revised skill bundles. The unchanged feature-design bundle is available only as applicable in the complete feature; no standalone feature-design rerun, A/B pair, numeric-grader migration, calibration suite, publication or global installation. One initial attempt per selected case; retain a failure and its diagnosis rather than silently retrying. Any further repair/run needs a concrete material reason and an explicit updated scope.

## Common contract and evidence

Each request below is an ordinary-language derivative, not an edit to the existing case. Archive the exact original case/request, this contract, the substituted request plus common envelope, candidate skill bytes/hashes, runtime/model settings, initial/final files and Git state, complete execution/final response, actual check outputs, failures and later dispositions. Keep assessment instructions/anchors and hidden oracles outside the worker. Supply only the case-declared skill bundle(s) and that case's fixture; availability does not require executing every skill operation. The existing runner prepares the baseline Git commit and installs a hook only where the case declares one. Use existing runtime isolation and deterministic checks; do not ask the worker to implement evidence infrastructure.

Append this envelope with the case-declared target/hard values (300/600 for cases 1–7; 600/900 for case 8): **“Use the supplied [selected skill] for this one local operation. Work only in this disposable fixture with its prepared tools. Target usable delivery within [target] seconds; hard stop [hard] seconds, including relevant checks and final editing. No downloads, external services, publication, tags or candidate commits. Preserve inputs outside the authorized paths. State material remaining limits.”** Hook-only scratch baseline commits are expressly allowed below. The time target is not a desired duration; unnecessary work still matters inside it. Clock worker invocation through usable final response, including model/tool waits; record independent evaluator checks/review separately, without hiding their total cost. Missing runtime/coverage prerequisites make that attempt unavailable, not a reason to install tools or expand the task.

All selected quality dimensions are **P1, 1–5; 3 is sufficient**. Below, 1 defeats the core purpose; 2 identifies a material gap; 4–5 require the corresponding specification's evidenced benefit, not more work. Never average away a material gap. Missing critical evidence is “not established”; retain known defects separately from invalid assessment. The few P0 boundaries are observed unauthorized mutation of protected inputs/external state, candidate commit despite the stated restriction, and a known hard-limit breach. A target miss supports the time dimension at 2 or below. Historical binary rubrics/oracles supply facts and counterexamples, not automatic sentence-level vetoes.

Worker configuration is **gpt-5.6-sol, medium**, with the case hard limit as its runtime timeout. Outcome review is a **delegated independent agent using the parent configuration**, not a Sol semantic scorer. Missing critical evidence is recorded as null/not established; usable is 3; do not invent benefits to assign 4/5. An independently assigned outcome reviewer first accepts or corrects this preregistration, then inspects each actual result against its frozen inputs and anchors. The worker does not grade itself. Record per-dimension score or missing-evidence finding with literal artifact citations and a concise consequence; no new scoring service is needed. Required counter-stage reviews remain pending—the evaluator's outcome inspection is not substitute human acceptance. Do not apply trial results to untested skill operations.

**Shared B6/C5/D6 anchors:** 3 = sufficient scoped result within its declared target (300 seconds locally; 600 for case 8), relevant reads/checks and same-task readability editing, without material avoidable overhead; 2 = target missed or substantive unchanged review/rewrite/gate replay without new evidence; 1 = no useful result with extreme avoidable work. Tiny navigation/reinspection and optional polish are advisory, not zero-tolerance failures. Glanceability means the reader finds the actual choice/verdict/result and meaningful limitation quickly; exact headings, a ceremonial “Next: none,” duplicated summaries, and repeating a usable DEVNOTES command in the final response are P2. A wrong measurement remains a material defect even when its percentage is faithfully reported.

## Eight frozen trials

### 1. Plan creation — smoke-plan-delivery

**P1:** B1, B2, B3, B4, B6. **Budget:** 300/600 seconds.

Derivative request: “Write docs/PLAN.md for the agreed JSON export transition and Client A adoption described in docs/DESIGN.md and clients.md. This task is planning only; do not implement.” Authorized output: docs/PLAN.md and final response. Preserve all supplied files, including accepted design and development policy.

**3 anchors:** B1 identifies the next deliverable consistently; B2 makes exporter JSON support available before separately owned Client A relies on it; B3 retains unchanged default/byte-compatible CSV for B during rollout, SKU strings and integer quantities including zero, with relevant implementation checks/docs and applicable review policy; B4 owns outcomes and acceptance without parallel live inventories. Existing validation must not be silently abandoned. **1:** rollout would break B or depend on nonexistent exporter support. **2:** acceptance hides compatibility under “tests pass,” postpones needed checks, or requires needless per-function/test synchronization. No prescribed stage count.

**Caveat:** supplied exporter.py is a small parser, not a running deployed CSV/JSON product; rollout feasibility is a plan judgment from the accepted design. DEVNOTES specifies review/full-gate policy but supplies no runnable gate. Linking that policy is sufficient; do not require or invent successful execution or a gate command during planning.

### 2. Private-change plan stability — smoke-plan-maintenance

**P1:** B1, B3, B4, B6; B2 unselected because dependencies are explicitly unchanged. **Budget:** 300/600.

Derivative request: “Assess the change in REQUEST.md against docs/PLAN.md. Update the plan if warranted and record your decision in RESULT.md. Do not edit code or tests.” Permit RESULT.md and only warranted planning amendments; preserve original requirements and historical evidence. For this supplied private change the expected successful plan remains byte-identical; an unnecessary rewrite is a B4 defect, not a predeclared prohibition on making a planning judgment.

**3 anchors:** B4 leaves PLAN.md byte-identical because the private helper rename/regression does not change public decisions; B1 retains S2 CLI as the existing next outcome; B3 retains rejected multi-item request followed by success and API compatibility. **1:** destroys accepted S1/history or replaces the contract. **2:** adds a helper/test inventory, reopens S1 or inserts an unnecessary design/review stage. Evaluate unchanged acceptance by inspection; no new plan paragraph is required.

**Caveat:** the private change is a supplied statement, not an executable diff; no code/tests are present. PLAN.md links a missing DEVNOTES.md. Keep that source defect visible as an unavailable linked gate, without requiring the worker to reconstruct it, falsely verify it or reopen settled planning. The original request's mandatory “next action” does not justify a new action beyond the existing S2 or honest conclusion.

### 3. Bounded implementation with gates — counter-stage

**P1:** C1, C2, C4, C5. No C3 review operation is assigned. **Budget:** 300/600.

Derivative request: “Implement Stage 1 in PLAN.md, with tests, and run the project's checks. You may edit counter.py, tests and affected documentation. Required human and independent-agent reviews are still pending; prepare the result for review without committing. No later stage is in scope.” Preserve FEATURE.md, VERSION, hook source/installed delegation and original policy/history; no invented review acceptance.

**3 anchors:** C1 accepts positive non-bool Python integers, returns updated state, preserves default add(), and rejects booleans/zero/negative/noninteger values with ValueError and no mutation; later valid add still works. C2 captures the initial negative-step failure and runs the current meaningful tests/full gate; existing counter oracle supplies independent boundary evidence. C4 makes working behavior/check state and pending reviews easy to locate. **1:** wrong central arithmetic, false green after demonstrated failure or premature acceptance/commit. **2:** bool accepted, invalid input mutates, baseline failure hidden, required gate missing, or handoff confuses implemented with accepted. Do not demand actual independent/human review inside this invocation.

**Caveat:** “heavy” is the historical case tier, not an explicit time allowance. This fixture is a tiny standard-library implementation with supplied requirements and no reviewer wait; 300/600 is predeclared for this derivative, not applied retrospectively. It cannot establish large-repository implementation performance.

### 4. Review sufficient code and stop — smoke-code-review-ready

**P1:** C3, C4, C5. C2 unselected: focused execution is optional, and any executed/claimed result must remain truthful. **Budget:** 300/600.

Derivative request: “Independently review session.py and its tests against REQUEST.md and write REVIEW.md. You are the separately assigned reviewer; do not edit code or tests. Local checks or read-only experiments are permitted.” Preserve every supplied file; only REVIEW.md/final response are authored outputs.

**3 anchors:** C3 accepts the actual implementation after checking validation before both cursor/selection mutations and correct next/previous behavior; recognizes the missing whole-state test without inventing a behavior failure. C4 gives an immediately usable verdict and evidence limits. **1:** invents verification or approves an actual contradictory state claim. **2:** blocks correct code merely because the existing test omits selection/previous assertions, adds concurrency/persistence obligations, or demands an extra review cycle. A targeted test suggestion is advisory here; static inspection can establish the simple invariant. Complete verdict needs no next-action sentence.

**Caveat:** this deliberately small sufficient implementation has incomplete regression coverage. It tests review judgment/stopping, not review sensitivity to a real defect or independent runtime execution when none was requested. The legacy opening rubric's unconditional next-action wording is superseded for this derivative.

### 5. Repair the installed hook gate — smoke-setup-hook

**P1:** D1, D6. **Budget:** 300/600.

Derivative request: “Fix the local commit gate so it meets DEVNOTES.md. You may change tools/check.py and use isolated scratch repositories for verification. Keep the application, tests, configuration, maintained hook wrapper and user documentation unchanged; do not commit the candidate.” Scratch baseline commits solely to construct probes are permitted; leave no probe changes in the candidate.

**3 anchors:** D1 observes the installed .git/hooks/pre-commit path accepting a nonempty passing suite and rejecting failing/empty discovery with docs alone staged; preserves quality.ini's custom unittest discovery and wrapper. **1:** gate still returns success for known failures/empty discovery. **2:** only tests check.py directly or cites configuration as installation evidence. D6 judges purposeful changed-path verification, not a quota of commands. Existing oracle independently exercises the installed wrapper; save its outputs and the installed hook bytes.

**Caveat:** checkout must actually install/chmod the hook using the existing case hook setting. This is a local shell-hook delegation test, not hosted CI or a pre-commit-package installation test. Its oracle directly invokes the installed hook with staged docs; it does not demonstrate a completed production commit.

### 6. Integrate correct coverage — smoke-setup-coverage

**P1:** D1, D2, D6. **Budget:** 300/600.

Derivative request: “Include coverage in the normal check command using the prepared coverage tool and existing .coveragerc. Limit implementation changes to tools/check.py; retain the application, tests and configuration. Record the result; no hook or documentation reorganization.” Generated measurement artifacts may be refreshed; archived initial evidence stays immutable.

**3 anchors:** D2 measures inventory.py with configured branches/missing locations/current JSON, including application imports executed during discovery; D1 retains nonempty pass plus failing/empty rejection and no invented threshold. Useful measurement and its material gaps are accessible from report/handoff; the existing DEVNOTES command can serve as the command entrypoint. **1:** fabricated/stale output or wrong application measured. **2:** starting coverage after discovery misses executed initialization, branch/source/failure behavior is missing, or results materially hide the gap. Do not require 96%, exact missing-line numbers or command repetition in the final reply.

**Caveat:** coverage must already exist in the prepared interpreter. Keep the known measurement-boundary defect as an actual acceptance concern; this fresh fixture is not a repair of the earlier failed worker. Existing full oracle compares actual/reference executed and missing lines/branches and probes failure/empty paths. Save its generated actual/reference JSON separately after the worker snapshot, including on failure; the maintained runner's historical omission of post-oracle reference.json is a known retention limitation, not permission to rewrite old records.

### 7. Documentation ownership — smoke-doc-ownership

**P1:** D3, D6. **Budget:** 300/600.

Derivative request: “Tidy the mixed project documentation so users and contributors can find what they need. Preserve the information and historical records. Documentation changes only; no application/tool/configuration changes, version bump or PR.” Authorize README.md, DEVNOTES.md, CHANGELOG.md, AGENTS.md and purposeful linked history under docs; freeze code/tests/tools/config/examples/VERSION.

**3 anchors:** D3 retains runnable usage, CSV schema/normalization/duplicates, output/error behavior and destination preservation; contributor discovery/hook/optional coverage commands have one maintained owner; completed leading-zero SKU impact remains in CHANGELOG; dated session and writer rationale remain linked history; AGENTS retains constraints. **1:** deletes essential usage/history. **2:** conflicting command owners, broken relocated links, historical checks relabeled current, or logs still obscure first use. No test execution is required merely to move docs; static path/content verification is appropriate. Empty files created to satisfy a template do not earn points.

**Caveat:** commands and coverage capabilities are supplied historical/current documentation facts, not proof of a fresh check. Respect that the ordinary runner has not yet incorporated optional coverage. This intentionally mixed small corpus tests ownership and reader access; it does not cover whole-PR scope or release readiness.

### 8. Complete literal-search feature — transfer-transcript-search

**P1:** C1, C2, C4, C5, D3. **Budget:** target 600 seconds / hard 900 seconds for the entire feature, including relevant skill work, implementation, tests, usage guidance and final response. C5 owns whole-task cost; do not sum overlapping per-skill clocks or require separate A/B planning artifacts. No C3 review chain is assigned.

Derivative request: “Implement the literal phrase search and neighboring-cue context described in REQUEST.md in this transcript viewer, including regression tests and a usable command example. You may edit transcript.py, tests and usage documentation. Preserve existing loader/rendering interfaces and the original request. Use the supplied skills as applicable; no new packages, external services or commits.” REQUEST.md contains the full API/CLI contract and remains byte-identical; retain AGENTS.md and example input. Existing loader/rendering tests must remain effective, though meaningful test additions are authorized.

**3 anchors:** C1 supplies find_cues plus CLI search: Unicode casefold, literal punctuation, no cross-cue matching, preserve nonempty phrase whitespace, reject blank phrases/invalid context even on empty input, union overlapping neighbor windows in source order without collapsing distinct equal-text cues or mutating inputs. No-match CLI succeeds with empty stdout; invalid CLI input produces a nonzero exit, useful stderr, no transcript output/traceback. Existing full transcript/timestamp rendering is unchanged. C2 actually runs existing loader/rendering tests and meaningful matching/context/validation regressions; existing accept.py independently checks these behaviors. C4 exposes the implemented result, actual checks and genuine limits. D3 gives an editor a runnable example and clear context behavior without a document set. **1:** feature remains a plan or breaks existing transcript viewing; fabricated execution. **2:** lower-only Unicode matching, duplicated/out-of-order windows, trimmed literal phrase, omitted invalid/empty-input handling, missing meaningful checks or unusable guidance. Cosmetic layout is advisory.

**Justification/caveat:** the real fixture has a loader, timestamp renderer, CLI, TSV example and unittest gate. This is a meaningful complete small feature across two interfaces plus tests/docs, warranting the predeclared 10/15-minute whole-task budget; no deployment, persistence migration, environment bootstrap or review-chain completion is implied. Existing request already authorizes local implementation and supplies understood behavior. All four bundles may be present; the tested feature-design bytes remain unchanged, and unnecessary design/planning ceremony earns no credit. This extends whole-task cost coverage but is not a measured 75-minute interview or proof of general large-repository performance.

## Execution boundary and freeze

Recommended order for early actionable signal: complete transcript feature → hook → coverage → counter → plan stability → plan creation → sufficient review → docs. Maximum initial campaign is eight worker invocations (45 minutes summed targets; 85 minutes summed hard ceilings), not a requirement to consume that time. No automatic repetitions or mandatory further reviewer/worker loops. A material discovery can pause remaining affected work for a scoped decision; do not quietly change criteria mid-run. Independent outcome review is additional recorded evaluator cost, not another worker implementation trial. Feature-design stays at its already tested bundle; the complete trial measures one feature's whole-task cost, while combined 75-minute interview behavior, activation reliability, scale, code-defect detection, public plan amendment and PR/release operations remain unproven.

Freeze reviewed candidate bundle hashes and exact derived requests before dispatch. An independently reviewed local portable candidate may be delivered with explicit unresolved limits; a known measurement/gate defect is not erased by good prose or passing unrelated cases. This document requests no execution and changes no live case, skill, test or runner.

## Source identities at preregistration

Case tree fingerprints below cover every regular file under each selected case (relative path → SHA-256 bytes, then SHA-256 of sorted-key JSON with Python default separators). They bind fixture/request/rubric/oracle originals together; retain the complete originals and per-file manifest in each eventual record. Skill hashes are intentionally not invented while the parent is revising them.

| Source case | Case/rubric version | Original case-tree fingerprint |
|---|---|---|
| smoke-plan-delivery | 4/4 | `50f11b9b0629fd9d723f245b224cae6cfb129ea213945fa183468bd206169842` |
| smoke-plan-maintenance | 4/4 | `e3641e38ee1a4a825af9dff452f92874d299d9f0dc4cad1abe2e73eb7a3cc9d0` |
| counter-stage | 4/4 | `30f0fa9fd433ec71a8e7fa00a82f7c96fb4eae273e615604551ea72104fc183f` |
| smoke-code-review-ready | 3/3 | `0936b89dc6adf1214e3ce177febef6fbdcb2baa6b3617a55692ce300b55ee96c` |
| smoke-setup-hook | 3/3 | `d80a5829a521e4072f32f33c2309611012c052b1ed1c910bfd6d7877c87f4664` |
| smoke-setup-coverage | 4/4 | `9ef87b310f7024171f9271b7b536ca2c9e89e0ce3556bb600880aa1831e38038` |
| smoke-doc-ownership | 3/3 | `6b61a6d93fad05b7244879b1ac7faee90623255684e9831a5df2e457aa6a31f0` |
| transfer-transcript-search | 4/4 | `6e5bafb4edb85357dbeb433d81d4e316bf781569135bc6b257521239e3a2adfc` |

Specification/proposal SHA-256 identities:

- `artifacts/interview-candidate/proposal.md`: `9108cf29573dad4ac1950847de8c9a36911d16d0ed0b679dc15f0984b561ab48`
- `docs/specs/implementation-plan.md`: `4e1c1f0bf44d34e5ac5568c5b0ebfc2812dee81e3be3cff6c2785caca98949a5`
- `docs/specs/stage-development.md`: `27f7da236637e963a00f789d930fef127b7037de9c8410c60036bbb1f53ef3b4`
- `docs/specs/dev-workflow.md`: `ad3ff779a14507383ac624b0783af1f1311dcd95791a1fc535629968690c2cde`
- `docs/specs/evaluation.md`: `288bdfd4620bedd75cc2aaef7b4981dbb16414643acf0103e76eb8d49e9b9893`
