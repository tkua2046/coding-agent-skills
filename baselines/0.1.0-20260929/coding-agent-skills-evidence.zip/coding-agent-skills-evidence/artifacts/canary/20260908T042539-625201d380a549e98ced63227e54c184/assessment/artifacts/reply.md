Revised [docs/DESIGN.md](/private/var/folders/7w/2jmyflc53t3fhsxzmf590wk80000gn/T/fd-worker-rzmycehy/docs/DESIGN.md:1) using the feature-design draft operation.

It now documents:

- `limit=None` and valid limit semantics.
- Full validation before prefixing.
- Compatibility, failure/retry behavior, and performance consequence.
- A distinguishing acceptance example.
- The accepted D1 history verbatim and a link to the unchanged source request.

Only `docs/DESIGN.md` changed; no implementation or tests were performed.