# Export design

Source request: [REQUEST.md](../REQUEST.md)

## Current choice: optional prefix limit

`export_rows` accepts `limit=None` as a new optional argument. `None` preserves
the current unlimited result; otherwise, the value must be a Python integer
greater than or equal to zero (booleans do not count as integers). Any other
value raises `ValueError` and returns no rows.

The exporter continues to parse and validate the entire CSV before applying
the limit to the validated list. It then returns at most the first `limit`
rows in source order. This makes the limit a presentation-size constraint,
not a way to skip validation: an invalid row anywhere in the source still
fails the request, including when it falls beyond the requested prefix.

This choice preserves the existing return type, ordering, rendering ownership,
and behavior for callers that omit the new argument. It also preserves the
all-or-nothing result: no partial output or persistent state exists after a
failure, and a caller may retry after correcting the CSV or limit. The
consequence is that a small limit does not reduce parsing time or memory use;
streaming is outside this change.

### Acceptance example

For a CSV containing valid rows `A` and `B` followed by an invalid row, calling
`export_rows(csv_text, limit=2)` raises `ValueError` rather than returning
`A` and `B`. Once every row is valid, the same call returns exactly `A` and
`B`. A limit of `0` likewise validates every row before returning an empty
list. Negative, boolean, and non-integer limits raise `ValueError`.

## Accepted history: D1

CSV rows are fully parsed and validated before being returned in source order.
The caller owns output rendering. Invalid stock rows fail the request.
This decision is accepted; no delivery status is tracked here.
