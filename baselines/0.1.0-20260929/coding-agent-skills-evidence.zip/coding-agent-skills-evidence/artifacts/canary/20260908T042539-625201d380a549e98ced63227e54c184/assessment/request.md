Use the draft operation in skills/feature-design to revise docs/DESIGN.md for REQUEST.md. Inspect the existing exporter. This is design only; preserve the accepted decision/history and source request, and give an implementer the current choice, consequence and acceptance example. Use the existing note rather than introducing a document suite.


This is one bounded local operation with supplied prerequisites. Reach a usable final response within 300 seconds; hard limit 600 seconds, including the final readability edit. Preserve the original operation scope; no implementation/commit/tag/publication unless that original request expressly includes it.

Use only this fixture and supplied skills/. Read fixture AGENTS.md. CANARY_PYTHON is the prepared interpreter. No downloads/external services.
