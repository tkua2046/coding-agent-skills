# Limit decision D2
Return at most N rows, while retaining whole-file validation. Select after validation because stopping at N would hide a malformed tail. For N=1, valid A then invalid B must error and preserve prior output, not return A. Default still returns all rows. Next: implement selection after existing validation; checks remain proposed.

## Limit contract
N is optional and must be a nonnegative integer; N=0 returns no rows after validating the whole file. Negative or non-integer N fails before output changes. Source order and existing parse/error behavior stay unchanged.

## Accepted baseline
Original D1 is retained in history/D1.md.

The complete accepted source is retained verbatim in history/original-D1.md; history/D1.md is an earlier summary, not a replacement for that source.
