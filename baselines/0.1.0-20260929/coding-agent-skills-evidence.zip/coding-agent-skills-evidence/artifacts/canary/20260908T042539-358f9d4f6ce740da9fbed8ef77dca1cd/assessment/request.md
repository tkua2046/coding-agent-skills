Use the intake operation in skills/feature-design. Inspect the small existing library and REQUEST.md; write INTAKE.md identifying the next consequential decisions with examples, and any justified defaults. Do not implement or draft a full design. You may inspect behavior locally. The note should let the owner answer real unresolved questions without repeating decisions already supplied.


This is one bounded local operation with supplied prerequisites. Reach a usable final response within 300 seconds; hard limit 600 seconds, including the final readability edit. Preserve the original operation scope; no implementation/commit/tag/publication unless that original request expressly includes it.

Use only this fixture and supplied skills/. Read fixture AGENTS.md. CANARY_PYTHON is the prepared interpreter. No downloads/external services.
