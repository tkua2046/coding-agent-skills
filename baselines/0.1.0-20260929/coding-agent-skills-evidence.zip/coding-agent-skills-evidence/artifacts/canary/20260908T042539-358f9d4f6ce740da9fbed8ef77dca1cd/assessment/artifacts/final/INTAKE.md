# Intake: Unicode-safe labels and per-call prefixes

## Decision needed

The two release requirements cannot both hold for every existing call. Today, `label("ß")` returns `"SS"`; preserving that exact output continues the expansion, while stopping the expansion necessarily changes the output. The same conflict occurs with `"ﬃ"` (`"FFI"`) and `"ǰ"` (`"J\u030c"`).

The owner needs to choose which promise takes precedence:

1. **Make non-expansion a narrow compatibility exception (suggested).** Preserve existing output except when the input is one Unicode code point whose uppercase form contains multiple code points. For example, `label("a")` remains `"A"`, while `label("ß")` must no longer be `"SS"`.
2. **Keep exact output compatibility.** `label("ß")` remains `"SS"`. This does not satisfy the stated non-expansion requirement for existing callers, so that requirement would need to be revised (for example, to an opt-in behavior).

If non-expansion takes precedence, one further output choice is required:

- **Preserve the original character when uppercasing expands (suggested default):** `"ß" → "ß"`, `"ﬃ" → "ﬃ"`, and `"ǰ" → "ǰ"`. This works uniformly, guarantees one code point remains one code point, and does not invent a casing rule absent from the runtime's normal `upper()` result.
- **Prefer a single-code-point capital where one can be selected:** for example, `"ß" → "ẞ"`. This better preserves the uppercase intent in some cases, but it needs a defined mapping source and a fallback for characters such as `"ﬃ"` that have no equivalent single-code-point uppercase result. Which mapping and fallback should apply?

## Settled contract

- Existing callers' results and exceptions remain compatible, subject only to the Unicode-expansion exception if the owner selects it. This combines the compatibility requirement in `REQUEST.md` with the existing contract recorded in `README.md`.
- Prefixes are optional per call and default to the empty string. The existing function already accepts `prefix` internally; the requested change makes that capability part of the supported contract rather than requiring a second prefix mechanism.
- A prefix is prepended verbatim and is not part of the casing or non-expansion check. For example, the ordinary case is `label("ok", "ID: ") → "ID: OK"`; under the suggested non-expansion behavior, `label("ß", "ID: ") → "ID: ß"`.

## Justified defaults

- Interpret “one-character Unicode input” as a Python string containing one Unicode code point (`len(value) == 1`). This directly covers every observed expansion above. Treating a user-perceived grapheme cluster made of several code points as “one character” would require a broader segmentation contract not present in the request or library.
- Keep the existing positional-or-keyword calling form, `label(value, prefix="")`, rather than making `prefix` keyword-only. The current signature already permits both forms, and narrowing it could break internal callers when the parameter becomes public.
- Do not add coercion, normalization, or eager type validation. Prefix strings remain unchanged, and existing exception behavior remains intact; for example, a non-string `value` currently fails when `.upper()` is unavailable, and `prefix=None` currently raises `TypeError` during concatenation.

## Evidence boundary

The fixture contains only `labels.py` and its one-line contract in `README.md`; there are no tests or downstream callers to further disambiguate intent. Behavior above was reproduced with the supplied `CANARY_PYTHON`. No implementation approach is selected here.
