Created [INTAKE.md](/private/var/folders/7w/2jmyflc53t3fhsxzmf590wk80000gn/T/fd-worker-fb2z0wfl/INTAKE.md).

It identifies:

- The unavoidable compatibility/non-expansion conflict.
- The conditional choice for characters such as `ß`.
- Suggested, justified defaults for Unicode interpretation and prefix behavior.
- Settled requirements that do not need reconfirmation.

No implementation, commit, or full design was produced.