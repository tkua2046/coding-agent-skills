# Local skill evidence

Start with artifacts/interview-candidate/results.md. Its eight-case table distinguishes useful results, unmet criteria and evaluator mismatches. Twelve new worker attempts and the prior feature-design runs with their linked control dependencies are retained.

Raw records preserve original requests, code, outputs, settings, paths and judgments; do not treat historical paths or scores as current verification. Source-snapshot contains current material for inspection; exact per-run inputs remain inside each record. Reproduction uses the repository and its prepared runtime, not an automatic command in this archive. The separate small ZIP contains only usable skills and their entry/validation notes. Neither archive is a release or remote publication.
