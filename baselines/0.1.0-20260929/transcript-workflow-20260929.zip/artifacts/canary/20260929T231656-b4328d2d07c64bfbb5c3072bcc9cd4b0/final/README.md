# Oral-history transcript viewer

An editor uses exported TSV cues to locate audio passages. Times are milliseconds;
text is displayed as supplied. The loader preserves file order and checks timing.

Show a transcript: `python transcript.py examples/interview.tsv`

Find a literal phrase: `python transcript.py examples/interview.tsv --find "river path"`

Include up to two neighboring cues on each side of every match:
`python transcript.py examples/interview.tsv --find "river path" --context 2`

Search is Unicode case-insensitive, but punctuation and whitespace are literal. Each
cue is searched separately, so a phrase cannot span two cues. Overlapping context
is printed once in transcript order. A search with no matches prints nothing and
still succeeds.

Run checks: `python -m unittest discover -s tests -v`

`Cue(start_ms, end_ms, text)`, `load_cues(path)`, `find_cues(cues, phrase,
context=0)` and `render_cues(cues)` are available to local scripts. `context` is a
keyword-only nonnegative integer.
