Our oral-history editor uses this local transcript viewer to locate passages before editing audio. Please add literal phrase search with neighboring cues to the existing implementation, including regression tests and enough usage guidance for the editor to use it.

Add `find_cues(cues, phrase, *, context=0)`, returning the matching cues plus up to `context` adjacent cues on each side. Search each cue independently using Unicode case-insensitive substring matching (`casefold`); punctuation is literal, and phrases do not span cues. Reject an empty or whitespace-only phrase. Otherwise preserve the phrase as supplied. Context must be a nonnegative integer, excluding booleans; invalid arguments raise `ValueError`, even with an empty transcript.

Return each selected cue once, in original source order, even when context windows overlap. Repeated text in different cues remains distinct. Do not modify the input cues. No matches means an empty result.

Expose this as `python transcript.py FILE --find PHRASE [--context N]`. Preserve the existing full-transcript command and timestamp rendering. Search with no matches succeeds with empty stdout. A nonzero context without `--find`, a negative context, or an invalid phrase must produce a nonzero exit and an understandable error on stderr, without a traceback or transcript output.

The existing loader and output format meet our needs; this is a local feature with understood behavior. Keep using standard-library Python and the existing test command. Work only in this supplied project; no packages, network, commits, or publishing. Complete the implementation and checks, then explain the result and any remaining limitation in your handoff.
