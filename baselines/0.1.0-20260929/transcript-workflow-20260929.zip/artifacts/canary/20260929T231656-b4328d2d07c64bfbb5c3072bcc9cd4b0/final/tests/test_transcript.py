import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from transcript import Cue, find_cues, load_cues, render_cues, timestamp


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SCRIPT = PROJECT_ROOT / "transcript.py"


class TranscriptTests(unittest.TestCase):
    def test_load_preserves_order_and_text(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parents[1]) as tmp:
            path = Path(tmp) / "cues.tsv"
            path.write_text("start_ms\tend_ms\ttext\n0\t1500\t Hello! \n1000\t2000\tAgain\n")
            self.assertEqual(load_cues(path), [Cue(0, 1500, " Hello! "), Cue(1000, 2000, "Again")])

    def test_rejects_backward_interval(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parents[1]) as tmp:
            path = Path(tmp) / "bad.tsv"
            path.write_text("start_ms\tend_ms\ttext\n200\t100\tbad\n")
            with self.assertRaises(ValueError):
                load_cues(path)

    def test_rendering(self):
        self.assertEqual(timestamp(3723004), "01:02:03.004")
        self.assertEqual(render_cues([Cue(0, 1500, "Hello")]), "00:00:00.000 --> 00:00:01.500 Hello")
        self.assertEqual(render_cues([]), "")

    def test_find_is_unicode_case_insensitive_and_keeps_distinct_cues(self):
        cues = [
            Cue(0, 100, "Die Straße"),
            Cue(100, 200, "unrelated"),
            Cue(200, 300, "STRASSE again"),
        ]

        result = find_cues(cues, "strasse")

        self.assertEqual(result, [cues[0], cues[2]])
        self.assertIs(result[0], cues[0])
        self.assertIs(result[1], cues[2])

    def test_find_includes_overlapping_context_once_in_source_order(self):
        cues = [Cue(index * 100, (index + 1) * 100, text) for index, text in enumerate(
            ["before", "needle", "between", "needle", "after", "outside"]
        )]
        original = list(cues)

        result = find_cues(cues, "needle", context=1)

        self.assertEqual(result, cues[:5])
        self.assertEqual(cues, original)

    def test_find_treats_punctuation_and_supplied_whitespace_literally(self):
        cues = [Cue(0, 100, "word, next"), Cue(100, 200, "word next")]

        self.assertEqual(find_cues(cues, "word,"), [cues[0]])
        self.assertEqual(find_cues(cues, " word "), [])

    def test_find_does_not_match_across_cues(self):
        cues = [Cue(0, 100, "river"), Cue(100, 200, "path")]

        self.assertEqual(find_cues(cues, "river path"), [])

    def test_find_rejects_invalid_arguments_even_without_cues(self):
        for phrase in ("", " \t\n", None):
            with self.subTest(phrase=phrase), self.assertRaises(ValueError):
                find_cues([], phrase)
        for context in (-1, 1.5, True):
            with self.subTest(context=context), self.assertRaises(ValueError):
                find_cues([], "valid", context=context)


class TranscriptCliTests(unittest.TestCase):
    def run_cli(self, *arguments):
        return subprocess.run(
            [sys.executable, str(SCRIPT), *map(str, arguments)],
            cwd=PROJECT_ROOT,
            text=True,
            capture_output=True,
            check=False,
        )

    def test_default_command_still_prints_the_full_transcript(self):
        result = self.run_cli("examples/interview.tsv")

        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stderr, "")
        self.assertEqual(result.stdout.count("\n"), 5)
        self.assertIn("00:00:00.000 --> 00:00:01.800 We started", result.stdout)
        self.assertIn("00:00:08.400 --> 00:00:09.900 That is when", result.stdout)

    def test_find_with_context_uses_existing_rendering(self):
        result = self.run_cli("examples/interview.tsv", "--find", "RIVER PATH", "--context", "1")

        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stderr, "")
        self.assertEqual(
            result.stdout,
            "00:00:00.000 --> 00:00:01.800 We started at the old station.\n"
            "00:00:02.000 --> 00:00:04.200 The river path was closed that winter.\n"
            "00:00:04.500 --> 00:00:06.100 So we walked across the bridge.\n"
            "00:00:06.400 --> 00:00:08.100 The river path reopened in spring.\n"
            "00:00:08.400 --> 00:00:09.900 That is when the interviews began.\n",
        )

    def test_find_with_no_matches_succeeds_silently(self):
        result = self.run_cli("examples/interview.tsv", "--find", "not present")

        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "")
        self.assertEqual(result.stderr, "")

    def test_invalid_search_options_fail_cleanly(self):
        cases = [
            (("examples/interview.tsv", "--context", "1"), "--context requires --find"),
            (("examples/interview.tsv", "--find", "river", "--context", "-1"), "nonnegative integer"),
            (("examples/interview.tsv", "--find", "   "), "non-whitespace text"),
        ]
        for arguments, message in cases:
            with self.subTest(arguments=arguments):
                result = self.run_cli(*arguments)
                self.assertNotEqual(result.returncode, 0)
                self.assertEqual(result.stdout, "")
                self.assertIn(message, result.stderr)
                self.assertNotIn("Traceback", result.stderr)


if __name__ == "__main__":
    unittest.main()
