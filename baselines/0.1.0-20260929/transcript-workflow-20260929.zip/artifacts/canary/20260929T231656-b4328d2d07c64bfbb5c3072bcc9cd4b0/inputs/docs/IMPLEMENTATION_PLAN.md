# Implementation plan

Current outcome: bounded-delivery rubric v7 and eight clear scorer controls are validated within their diagnostic scope. A fresh independent audit found the old review's presumed hard-failure label was not sufficiently grounded; preserve its provenance limitation and both interpretations without forcing a grade change. The completed presentation diagnostic did not establish a grading benefit and was not adopted. Both independent reviewers now retain the old provenance issue as advisory. Skills, shared scorer and engine are unchanged; [validation](VALIDATION.md) owns exact outcomes and limits.

Next outcome: assess the existing single-context transcript-search task for an efficiency probe with independently grounded acceptance and a declared budget. The older inventory task's required phases cannot simply be removed; its 861.105s still fails the 600s target. Investigate duplicate gate coverage and repeated status without assuming recoverable seconds or requiring extra ceremony. Change a skill only after a generalizable cause and corresponding test are established. Full release qualification remains separate.

## Earlier outcomes (retained history)

| Outcome | Acceptance | State |
|---|---|---|
| Reviewable source delivery with retrievable originals | Historical evidence pinned remotely; fresh checks work without it; new runs outside source diff | Complete; both archives published and verified, fresh export passes |
| Proportionate skills and focused verification | Direct work needs no invented document prerequisite; explicit reviews and consequential safeguards remain effective | Implemented and independently reviewed; scoped outcomes and timeout recorded in validation |
| Whole-deliverable acceptance | Review actual task outputs, effort, complete PR scope and clean-checkout usage; state failures and limits | Independent package and behavioral reviews complete; final commit checks are recorded on the draft PR |
| Evaluation contract acceptance | Actual criteria trace to skill goals; coherent positive/negative controls expose required failures; independent review concerns resolved and scoring outcomes retained | Definitions reviewed; the earlier batch accepted 36/37 controls, with one rejected citation; those results retain their old engine/input bindings |
| Scoped regression feedback | Independent review operations; same-case calibration reuse, relevant invalidation and no release promotion | Complete and independently reviewed; 277 fast checks passed, then 21 affected checks passed after the evidence-wording correction. No LLM result claimed |
| Independent operation coverage | Fixed prerequisites and concrete rubrics across all four skills; real fixture/oracle controls, reviewed scoring contrasts and bounded live probes | 19 definitions and four real probes completed; independent reviews and 290 fast checks recorded. Two contextual output-rule corrections have focused scoring regressions; remaining defects and current calibration limits are in validation |
| Close observed failures at task scale | Useful setup handoff and verified measurement repair; literal scoring evidence; incidental overhead distinguished from material repeat work across skills | Design and repair reruns passed under their recorded rules. Coverage still has a real measurement defect. Further worker repairs/regrading paused for the priority contract; original failures stay retained |
| Prioritize task outcomes in requirements and grading | Per-operation core dimensions with concrete 1–5 anchors; few unequivocal vetoes; readability as the last task step, optional polish cannot block sufficient work | Four cards/shared rules reviewed; inspection-versus-repair finding fixed and reviewer-verified. Fast gate passed; executable case/grader and skill-prompt migration remain pending. No new model trials |
| Revise and exercise feature-design | Sequential operation prompts; final same-task readability; original sources, meaningful decisions and review closure preserved; scoped real-worker evidence | Complete for this scoped pilot. Four operations usable within their targets; proposal/bundle and actual outcomes independently reviewed with no material open finding. Numeric diagnostics and fast gate recorded; remaining validation limits explicit |

Design: [decisions and consequences](DESIGN.md). Checks: [developer operations](../DEVNOTES.md). Results and originals: [validation](VALIDATION.md), [evidence index](EVIDENCE.md).

## Decisions made during execution

The independent plan review required durable archive retrieval, an offline fixture for the test that depended on archived output, retention of newer-failure selection, reconciliation of mandatory workflow defaults, and aggregate PR review. Those requirements shaped the outcomes above.

Actual trials supported two generic intake corrections: leave consequential precedence with the owner, and put the conclusion/next action/evidence limit first. Their original failures remain recorded. An ordinary implementation bug in the ZIP task used the existing review–fix–recheck path rather than another skill rule. The final intake timeout remains a limitation; repeating a run merely to obtain green would not resolve it.

The selected checks cover contrasting operations, an uncertain existing-code task and two independently authored complete tasks. Only affected operations were rerun after intake changes. Full calibrated release testing remains separate; no tag or release is authorized by these draft results.

At each completed outcome, assess whether further work resolves a material user problem. More reports or more green counts are not outcomes. The [previous plan and original reviews](https://github.com/tkua2046/coding-agent-skills/blob/a24b140ddda594bec61ae42ac272d3225892cfb5/docs/IMPLEMENTATION_PLAN.md) remain in the archive.
