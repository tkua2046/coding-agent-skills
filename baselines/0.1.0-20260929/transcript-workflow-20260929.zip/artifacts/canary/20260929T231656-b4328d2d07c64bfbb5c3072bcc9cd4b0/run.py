"""One diagnostic using existing runtime; not a calibrated canary/release run."""
import json
import sys
import tempfile
from pathlib import Path

from tools import canary as c
from tools import canary_runtime as runtime

ROOT = Path.cwd().resolve()
CAMPAIGN = ROOT / "artifacts/transcript-workflow-20260929"
CASE_DIR = ROOT / "evals/cases/transfer-transcript-search"
SETTINGS = {"model": "gpt-5.6-sol", "effort": "medium", "timeout_seconds": 600}


def prepare():
    case = c.read_json(CASE_DIR / "case.json")
    selected = c.skill_files(ROOT, case["skills"])
    sources = {
        **{f"case/{p}": b for p, b in c.files(CASE_DIR).items()},
        **selected,
        **{p: (ROOT / p).read_bytes() for p in (
            "tools/canary.py", "tools/canary_runtime.py", "AGENTS.md",
            "DEVNOTES.md", "requirements-dev.txt", "pyproject.toml",
            "docs/VALIDATION.md", "docs/IMPLEMENTATION_PLAN.md",
            "docs/EVIDENCE.md", "CHANGELOG.md",
        )},
    }
    c.write_files(CAMPAIGN / "frozen", sources)
    c.save(CAMPAIGN / "inputs-sha256.json", c.hashes(sources))
    try:
        controls = c.case_calibration_inputs(ROOT, case["id"])
        calibration = {"controls_defined": len(controls["examples"]), "qualified": False}
    except ValueError as error:
        calibration = {"qualified": False, "reason": str(error)}
    contract = {
        "kind": "single-context-workflow-diagnostic",
        "case_id": case["id"],
        "settings": SETTINGS,
        "usable_target_seconds": 300,
        "hard_timeout_seconds": 600,
        "budget_basis": "Prospective usability target for a bounded local change to a small known CLI with explicit semantics and existing tests. This is a requested diagnostic constraint, not a measured baseline or universal difficulty threshold.",
        "clock": "Complete worker invocation through final handoff, including worker reads, plans, checks and documentation. Excludes evaluator preparation, oracle/check replay and independent review.",
        "acceptance": [
            "Unmodified evaluator-only accept.py passes; preserve interfaces and source request.",
            "Original three tests pass against final code; final unittest gate passes; inspect worker-added expectations against the request.",
            "Working CLI example and accurate matching/context explanation; handoff accurately states actual checks and remaining work.",
            "Inspect complete trace for task completion, justified workflow choices, substantive repeat work and unsupported claims. No mandatory document set or review loop.",
            "No worker commits, tags, packages, network, or publishing; supplied skills unchanged.",
            "Report target and hard-timeout outcomes separately from functional acceptance; preserve failures and partial outputs.",
        ],
        "qualification": calibration,
        "limits": "One timed variant, independent manual assessment, no calibrated automatic score or release qualification, no causal speed comparison and no guarantee of repeatability. Skill changes require a demonstrated generalizable defect, not a desire to change a score.",
    }
    c.save(CAMPAIGN / "contract.json", contract)
    prompt = (CAMPAIGN / "frozen/case/requests/01.md").read_text()
    prompt += "\n\nUse only this fixture and the supplied skills/. Read fixture AGENTS.md if present. This is a fresh context. CANARY_PYTHON points to the prepared Python runtime. Do not install packages or use external services.\n"
    prompt += "\nTask budget: aim to deliver the usable result and final handoff within 300 seconds; the complete invocation has a hard cap of 600 seconds. Honor the full requirements. Choose the necessary workflow yourself.\n"
    (CAMPAIGN / "prompt.md").write_text(prompt)
    print(json.dumps({"prepared": str(CAMPAIGN), "qualification": calibration}))


def run():
    frozen = CAMPAIGN / "frozen"
    assert c.hashes(c.files(frozen)) == c.read_json(CAMPAIGN / "inputs-sha256.json")
    case = c.read_json(frozen / "case/case.json")
    contract = c.read_json(CAMPAIGN / "contract.json")
    directory, report = c.new_record(ROOT, "workflow-diagnostic")
    c.save(CAMPAIGN / "run-location.json", {"directory": str(directory)})
    report.update(case_id=case["id"], settings={"worker": SETTINGS}, environment=c.environment(), qualification="not-established")
    c.write_files(directory / "inputs", c.files(frozen))
    for name in ("contract.json", "prompt.md", "inputs-sha256.json", "independent-contract-review.json", "run.py"):
        (directory / name).write_bytes((CAMPAIGN / name).read_bytes())
    try:
        with tempfile.TemporaryDirectory(prefix="transcript-workflow-") as temp:
            workspace = Path(temp).resolve() / "worker"
            workspace.mkdir()
            selected = {f"skills/{p}": b for p, b in c.files(frozen / "skills").items()}
            initial = {**c.files(frozen / "case/fixture"), **selected}
            head = c.init_fixture(workspace, initial)
            c.write_files(directory / "initial", initial)
            c.save(directory / "initial-git.json", c.git_snapshot(workspace, head))
            isolation = runtime.probe(workspace, frozen / "case/rubric.json")
            c.save(directory / "isolation.json", isolation)
            if not isolation["passed"]:
                raise RuntimeError("Isolation failed; no model executed")
            gate = [sys.executable, "-B", "-m", "unittest", "discover", "-s", "tests", "-v"]
            baseline = runtime.capture(runtime.sandbox_command(workspace, gate), workspace, 30)
            c.save(directory / "baseline-tests.json", baseline)
            if baseline["exit_code"] != 0:
                raise RuntimeError("Baseline gate failed; no model executed")
            result = runtime.execute(workspace, (CAMPAIGN / "prompt.md").read_text(), directory / "reply.md", SETTINGS)
            c.save(directory / "execution.json", result)
            c.write_files(directory / "final", c.files(workspace))
            c.save(directory / "final-git.json", c.git_snapshot(workspace, head))
            checks = c.deterministic(case, frozen / "case", workspace, initial, head)
            checks.append({"id": "skills-preserved", "status": "pass" if all((workspace / p).read_bytes() == b for p, b in selected.items()) else "fail"})
            c.save(directory / "deterministic.json", checks)
            c.save(directory / "final-tests.json", runtime.capture(runtime.sandbox_command(workspace, gate), workspace, 30))
            # Run the original assertions against final code independently of author test edits.
            original = initial["tests/test_transcript.py"].decode()
            source = "import types, unittest, pathlib, sys\nm=types.ModuleType('original_tests')\nm.__file__=str(pathlib.Path('tests/test_transcript.py').resolve())\nexec(compile(" + repr(original) + ",m.__file__,'exec'),m.__dict__)\nr=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(m))\nassert r.testsRun == 3\nsys.exit(not r.wasSuccessful())\n"
            c.save(directory / "original-tests-final.json", runtime.capture(runtime.sandbox_command(workspace, [sys.executable, "-B", "-c", source]), workspace, 30))
            report.update(worker_completed=result["completed"], worker_seconds=result["elapsed_seconds"], within_target=result["completed"] and result["elapsed_seconds"] <= contract["usable_target_seconds"], within_hard_budget=result["completed"] and result["elapsed_seconds"] <= contract["hard_timeout_seconds"], deterministic=checks)
    except (Exception, KeyboardInterrupt) as error:
        report["error"] = f"{type(error).__name__}: {error}"
    finally:
        report["status"] = "inconclusive"  # Manual diagnostic, never a qualified pass.
        c.finish(directory, report)
        print(json.dumps({"run": str(directory), "report": report}, indent=2))


if sys.argv[1] == "prepare":
    prepare()
elif sys.argv[1] == "run":
    run()
