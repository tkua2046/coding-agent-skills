Implemented literal phrase search with neighboring cue context.

- Added `find_cues()` with Unicode `casefold()` matching, argument validation, ordered de-duplication, and no input mutation in [transcript.py](/private/var/folders/7w/2jmyflc53t3fhsxzmf590wk80000gn/T/transcript-workflow-d9yuj9x8/worker/transcript.py:43).
- Added `--find PHRASE [--context N]` while preserving default transcript output and timestamp rendering.
- Added API and CLI regression coverage in [tests/test_transcript.py](/private/var/folders/7w/2jmyflc53t3fhsxzmf590wk80000gn/T/transcript-workflow-d9yuj9x8/worker/tests/test_transcript.py:32).
- Added editor usage examples and search semantics to [README.md](/private/var/folders/7w/2jmyflc53t3fhsxzmf590wk80000gn/T/transcript-workflow-d9yuj9x8/worker/README.md:6).

Validation: all 12 unittest tests pass; `git diff --check` passes.

The intentional limitation is that search remains literal and cue-local: punctuation and supplied whitespace matter, and phrases cannot span adjacent cues.