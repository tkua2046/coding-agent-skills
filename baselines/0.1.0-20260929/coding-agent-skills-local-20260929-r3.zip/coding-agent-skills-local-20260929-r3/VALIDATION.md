# Local candidate validation - 29 September 2026

For supervised local use. This is not full-suite certification or a hosted release.

Only the release-selection paragraph changed since r2. It distinguishes a released
baseline from an already prepared target and preserves past release notes.

| Real gpt-5.6-sol / medium task | Time | Outcome |
|---|---:|---|
| Required feature design/reviews/implementation/handoff | 613.811s | Working/readable result; 600s target missed |
| Original local release | 259.248s | Wrong version and rewritten history; failed |
| Corrected version preparation | 53.229s | Correct target and preserved history |
| Corrected already-prepared metadata | 61.510s | No second bump or changes |
| Corrected local release and retries | 251.396s | Correct version/tag/artifact and preserved retry identities |

Independent inspection scored each corrected metadata, release and retry operation
D5=4/5 and D6=3/5 (3 is sufficient). These are scoped manual judgments; automatic
scorer qualification and broader reliability are not established. No causal speed
claim follows from these single trials. Publication was an offline simulation.

The feature workflow also retained a failed byte-preservation check whose task
wording was ambiguous. Prospective instructions now identify the immutable source;
the original result is unchanged. Its separate restricted reader recovered the
behavior, design choice and human-review status. Its timing limit remains open.

The tooling gate passed 383 tests at 94% tooling coverage. A subsequent oracle-only
fairness correction passed six affected controls and static validation. These checks
do not substitute for real skill performance. Actual VSCode discovery and human
acceptance remain unverified. No global installation or publication was performed.

Full raw inputs, outputs, failed attempts and independent reviews are supplied
separately in workflow-release-20260929.zip. Previous archives remain unchanged.
