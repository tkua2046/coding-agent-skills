# Local workflow skills

Start with [QUICKSTART.md](QUICKSTART.md). Copy the four actual folders in `.agents/skills/` into the project where you will work, preserving their contents and any existing skills.

Choose only the operation the task needs. Give the agent the original requirements, relevant existing work and time remaining. Keep your own judgment and requested review gates.

[Validation](VALIDATION.md) states what was tested and what remains uncertain. This is a local unreleased candidate; no global installation or publication is included.
