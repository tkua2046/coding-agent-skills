# Workflow/release evidence - 29 September 2026

Start at artifacts/release-version-fix-20260929/results.md and results.json.
They separate five raw worker records, manual judgments, failed outcomes and limits.
Raw records retain complete available CLI events, inputs, snapshots, settings and
checks. Diagnostic report status remains inconclusive when no automatic scorer ran;
manual judgments never rewrite it. Original failed records are included unchanged.

Source changes for this iteration are in task.patch and source-delta.json; the
checkout already had substantial prior edits. Runtime scope is one release-selection
paragraph. The focused prepared-state case, future request clarification and oracle
fairness correction are separate from runtime changes. Current source and originals
are retained; original content, including incorrect outcomes, is not replaced by a
summary. Independent reviews and their qualifications are included verbatim.

Extract this archive into separate storage to inspect it. MANIFEST.json records
every payload SHA-256. The adjacent verification record checks CRC, extraction,
all payload hashes and each restored raw report's internal evidence hashes. Saved
Git snapshots are observations, not complete Git repository bundles. Old absolute
worker links refer to disposed temporary fixtures; use archived phase workspaces.

The r3 ZIP inside artifacts/release-version-fix-20260929 contains39 real skill files
and local-use guides. Its separate verification covers exact current skill bytes,
portable links, manifests and extraction; it does not prove VSCode discovery.
No real repository push, global install, hosted release or full certification is
part of this work. The full feature workflow still misses its600s target.
