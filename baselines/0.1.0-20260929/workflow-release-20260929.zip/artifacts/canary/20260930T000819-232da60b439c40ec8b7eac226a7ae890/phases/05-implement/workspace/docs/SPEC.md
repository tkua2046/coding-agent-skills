# Current contract
See ORIGINAL.md for the original accepted behavior. Reservation uses batch-local
state and returns remaining stock and ordered outcomes. Before deducting an order,
the engine checks every requested item against the current remaining stock. It
accepts and deducts the order only if every item is available; otherwise it rejects
the order without changing stock and continues with the next order. Empty orders are
accepted without changing stock. No persistent database or concurrent writers.
