Implemented atomic per-order reservation rejection.

- Preflights all items before deducting stock.
- Rejected orders leave stock unchanged; later orders continue normally.
- Added 8 tests covering atomic rejection, continuation, exact zero, empty orders/batches, both APIs, immutability, and validation.
- Updated README, specification, design status, and implementation handoff.
- Preserved the approved design review and installed hook unchanged.

Checks passed:

- `"$CANARY_PYTHON" -m unittest discover -s tests -v` — 8 tests
- `"$CANARY_PYTHON" hooks/pre-commit` — 8 tests
- Hook comparison — identical
- `git diff --check` — passed

Current state is recorded in [docs/PLAN.md](/private/var/folders/7w/2jmyflc53t3fhsxzmf590wk80000gn/T/canary-xt9fwluv/worker/docs/PLAN.md:83). Independent code review and human review remain pending. No commit was created.