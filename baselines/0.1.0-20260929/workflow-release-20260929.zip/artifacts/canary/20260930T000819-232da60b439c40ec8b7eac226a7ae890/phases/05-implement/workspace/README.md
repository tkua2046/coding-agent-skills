# Batch inventory reservation
Call `batch.execute({"a": 4}, '[{"id":"o1","items":[["a",2]]}]')` to obtain
remaining inventory and an ordered acceptance result for each order. The Python API
is `inventory.reserve(stock, orders)`. Each order is accepted and deducted only when
all of its requested quantities are available. An insufficient order is rejected
without changing inventory, and later orders continue against the remaining stock.
Empty orders are accepted without changing stock, and caller input is preserved.
JSON validation rejects unknown/duplicate SKUs and nonpositive/noninteger quantities
before execution. See DEVNOTES.md for checks.
