import unittest
from inventory import reserve
from batch import execute


class InventoryTests(unittest.TestCase):
    def test_rejection_is_atomic_and_later_orders_continue(self):
        stock = {"a": 4, "b": 2}
        orders = [
            {"id": "o1", "items": [["a", 2], ["b", 3]]},
            {"id": "o2", "items": [["a", 3]]},
        ]

        result = reserve(stock, orders)

        self.assertEqual(
            result,
            (
                {"a": 1, "b": 2},
                [
                    {"order_id": "o1", "accepted": False},
                    {"order_id": "o2", "accepted": True},
                ],
            ),
        )
        self.assertEqual(stock, {"a": 4, "b": 2})
        self.assertEqual(
            orders,
            [
                {"id": "o1", "items": [["a", 2], ["b", 3]]},
                {"id": "o2", "items": [["a", 3]]},
            ],
        )

    def test_success_exact_stock_and_input_preservation(self):
        stock = {"a": 4, "b": 2}
        orders = [{"id": "o1", "items": [["a", 4], ["b", 1]]}]

        result = reserve(stock, orders)

        self.assertEqual(
            result,
            (
                {"a": 0, "b": 1},
                [{"order_id": "o1", "accepted": True}],
            ),
        )
        self.assertEqual(stock, {"a": 4, "b": 2})
        self.assertEqual(
            orders,
            [{"id": "o1", "items": [["a", 4], ["b", 1]]}],
        )
        self.assertIs(type(result[0]["a"]), int)

    def test_no_orders_preserves_stock(self):
        self.assertEqual(reserve({"a": 2}, []), ({"a": 2}, []))

    def test_empty_order_is_accepted_without_mutation(self):
        self.assertEqual(
            reserve({"a": 2}, [{"id": "empty", "items": []}]),
            (
                {"a": 2},
                [{"order_id": "empty", "accepted": True}],
            ),
        )

    def test_adapter(self):
        text = '[{"id":"o1","items":[["a",5]]},{"id":"o2","items":[["a",1]]}]'
        self.assertEqual(
            execute({"a": 4}, text),
            (
                {"a": 3},
                [
                    {"order_id": "o1", "accepted": False},
                    {"order_id": "o2", "accepted": True},
                ],
            ),
        )

    def test_unknown_sku(self):
        with self.assertRaises(ValueError):
            execute({"a": 4}, '[{"id":"o","items":[["missing",1]]}]')

    def test_duplicate_sku(self):
        with self.assertRaises(ValueError):
            execute({"a": 4}, '[{"id":"o","items":[["a",1],["a",2]]}]')

    def test_bad_quantity(self):
        with self.assertRaises(ValueError):
            execute({"a": 4}, '[{"id":"o","items":[["a",true]]}]')
