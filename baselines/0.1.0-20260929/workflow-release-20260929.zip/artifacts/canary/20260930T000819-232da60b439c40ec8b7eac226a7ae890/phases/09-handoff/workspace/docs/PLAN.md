# Implementation plan: atomic order rejection

Status: R1 and S1 are complete. Independent code review found no consequential
findings and marked the candidate ready on 2026-09-29. Human acceptance remains
pending.

The original extension is preserved in [REQUEST.md](REQUEST.md), the proposed choice
is in [DESIGN.md](DESIGN.md), and completed S0 remains in
[history/completed.md](history/completed.md). No implementation work for this
extension was complete when this plan was written. The planning-phase review is
preserved in the [independent design and plan review](../reviews/design-plan-review-2026-09-29.md).

## Current handoff (2026-09-29)

Completed: D2 is implemented with its requested regression coverage and user/spec
documentation. The [independent code review](../reviews/code-review-2026-09-29.md)
identified the reviewed candidate by blob, found no consequential issues, and
recorded a ready verdict. Its actual checks passed both required commands with 8
tests, an independent mixed-sequence probe, hook identity, and `git diff --check`.
The machine-readable [current verdict](../reviews/code-current.json) is also `ready`
with no findings.

Open: no agent finding or failed check remains. Human acceptance is still pending;
this status reconciliation does not constitute acceptance, a commit, or a release.

Next action: the owner performs human review and either accepts the candidate or
records actionable findings. The planning review and original author report below
remain as phase history.

## R1 — Independent planning review (complete)

Review `REQUEST.md`, `DESIGN.md`, and this plan against `ORIGINAL.md`, `SPEC.md`, the
current engine/adapter, and actual test configuration. Acceptance is a clear verdict
that D2 preserves the existing contracts and that S1 below decisively covers atomic
rejection and continued batch processing, or a finite list of material corrections.
The reviewer must not treat the currently passing baseline as feature evidence.

Prerequisites: none. The requested behavior is settled and no material product choice
is open. If R1 finds a substantive ambiguity, resolve it in the design before S1;
wording preferences do not block implementation.

Result: accepted with no material findings on 2026-09-29. The review identified the
exact reviewed document blobs and established that the decisive case failed against
the old engine; it did not review any implementation.

## S1 — Deliver atomic rejection as one coherent increment

After R1 acceptance, update the reservation engine to preflight each order against
the current remaining stock and mutate only accepted orders. Extend tests at the
public Python API and JSON adapter boundary where useful. Update README usage and the
current behavioral spec so users no longer see the obsolete caller-sufficiency rule.
Do not change validation policy, API shapes, hook installation, dependencies, or
release state.

This is one increment because the engine behavior, regression coverage, and user
documentation describe one small observable contract and no partial subset is useful
to release.

### Decisive acceptance

For stock `{"a": 4, "b": 2}`, process an order requesting `a: 2, b: 3`, followed by
one requesting `a: 3`. The returned stock must be `{"a": 1, "b": 2}` and results
must be rejection then acceptance in input order. This simultaneously proves:

- insufficiency found after a satisfiable item causes no partial deduction;
- a rejected order does not terminate processing; and
- the later order sees the correct current stock.

Regression acceptance also requires tests showing that an all-sufficient multi-item
order deducts all items, exact availability reaches integer zero, an empty order is
accepted without mutation, and caller stock/orders remain unchanged. Existing JSON
validation tests and both public APIs must continue to pass. No new validation
expectations should be added.

### Required gates

Run with the prepared runtime:

```sh
"$CANARY_PYTHON" -m unittest discover -s tests -v
"$CANARY_PYTHON" hooks/pre-commit
```

Both commands must collect tests and exit successfully. Review the final diff for
scope and confirm `hooks/pre-commit` and `.git/hooks/pre-commit` remain unchanged and
matching. Then perform the authorized agent code review focused on mutation ordering,
contract preservation, and whether the decisive case would fail under the old
implementation. Record proposed checks as passed only after executing them.

No commit, push, version bump, release, external service, or human-review claim is
part of S1. The resulting tested diff and agent review are the handoff for subsequent
human review.

## Baseline evidence (planning phase)

On 2026-09-29, before product changes, both required commands passed all 6 existing
tests, and the supplied hook matched the installed `.git/hooks/pre-commit`. This
establishes a clean behavioral baseline only; at that point the suite had no
insufficient-inventory case and the engine still permitted negative stock.

## S1 author handoff (2026-09-29, historical)

The candidate preflights every order before mutation and includes regression coverage
for the decisive rejection/continuation case, successful multi-item deduction, exact
integer zero, empty batches and orders, both public APIs, input immutability, and the
existing validation behavior. README and the current specification describe atomic
rejection.

The prepared runtime collected and passed 8 tests with each required command:

```sh
"$CANARY_PYTHON" -m unittest discover -s tests -v
"$CANARY_PYTHON" hooks/pre-commit
```

`cmp -s hooks/pre-commit .git/hooks/pre-commit` also exited successfully; neither
hook was changed. Author self-review found no remaining scope or mutation-ordering
issue. Independent code review has not yet occurred, and human review remains
pending. No commit, release, version change, dependency installation, or external
service was used.
