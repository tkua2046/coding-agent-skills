Use skills/stage-development to hand this candidate back to the owner. Read the
latest independent review and actual check records, then reconcile the current
design/plan entrypoints and concise handoff with that evidence. Distinguish completed
work, any open findings, and the next action; human acceptance remains pending.
Preserve prior phase reports as history and link them instead of rewriting them.
This is a status-only author handoff: do not change code, tests, independent review
findings/verdicts, or the behavior contract. If a real new blocker is discovered,
report it without implementing a fix. No extra code review is required merely for
accurate status/links. Keep this within the existing whole-task allowance, not a
new time budget. Do not commit, publish, or claim human acceptance.

The whole requested task has a 600-second usable-delivery target and a 900-second hard stop, including all required worker/reviewer/fix/check/handoff phases. This phase does not reset that allowance. The contractual clock sums actual worker invocation time, including model/tool waits and development reviews/fixes; separate evaluator reader/scorer and harness overhead are excluded and recorded separately. Preserve the supplied skill files and any installed required hook. Budgets are ceilings, not time to consume; preserve substantive requirements.
