Prepared the planning handoff without changing implementation code:

- [REQUEST.md](/private/var/folders/7w/2jmyflc53t3fhsxzmf590wk80000gn/T/canary-xt9fwluv/worker/docs/REQUEST.md:1) preserves the original requirements and records verified repository facts.
- [DESIGN.md](/private/var/folders/7w/2jmyflc53t3fhsxzmf590wk80000gn/T/canary-xt9fwluv/worker/docs/DESIGN.md:1) specifies atomic per-order prechecking, compatibility, failure behavior, and a decisive example.
- [PLAN.md](/private/var/folders/7w/2jmyflc53t3fhsxzmf590wk80000gn/T/canary-xt9fwluv/worker/docs/PLAN.md:1) identifies independent review as the next outcome, followed by one coherent implementation increment and explicit acceptance gates.

Baseline verification:

- All 6 existing tests pass with `CANARY_PYTHON`.
- The supplied hook passes and matches the installed `.git/hooks/pre-commit`.
- `git diff --check` passes.
- Existing history, skill files, hook, and product code remain unchanged.