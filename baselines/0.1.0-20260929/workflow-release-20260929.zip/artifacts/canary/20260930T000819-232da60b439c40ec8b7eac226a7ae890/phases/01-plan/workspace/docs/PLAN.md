# Implementation plan: atomic order rejection

Status: planning complete; independent review is the next undelivered outcome.

The original extension is preserved in [REQUEST.md](REQUEST.md), the proposed choice
is in [DESIGN.md](DESIGN.md), and completed S0 remains in
[history/completed.md](history/completed.md). No implementation work for this
extension is complete yet.

## R1 — Independent planning review (next)

Review `REQUEST.md`, `DESIGN.md`, and this plan against `ORIGINAL.md`, `SPEC.md`, the
current engine/adapter, and actual test configuration. Acceptance is a clear verdict
that D2 preserves the existing contracts and that S1 below decisively covers atomic
rejection and continued batch processing, or a finite list of material corrections.
The reviewer must not treat the currently passing baseline as feature evidence.

Prerequisites: none. The requested behavior is settled and no material product choice
is open. If R1 finds a substantive ambiguity, resolve it in the design before S1;
wording preferences do not block implementation.

## S1 — Deliver atomic rejection as one coherent increment

After R1 acceptance, update the reservation engine to preflight each order against
the current remaining stock and mutate only accepted orders. Extend tests at the
public Python API and JSON adapter boundary where useful. Update README usage and the
current behavioral spec so users no longer see the obsolete caller-sufficiency rule.
Do not change validation policy, API shapes, hook installation, dependencies, or
release state.

This is one increment because the engine behavior, regression coverage, and user
documentation describe one small observable contract and no partial subset is useful
to release.

### Decisive acceptance

For stock `{"a": 4, "b": 2}`, process an order requesting `a: 2, b: 3`, followed by
one requesting `a: 3`. The returned stock must be `{"a": 1, "b": 2}` and results
must be rejection then acceptance in input order. This simultaneously proves:

- insufficiency found after a satisfiable item causes no partial deduction;
- a rejected order does not terminate processing; and
- the later order sees the correct current stock.

Regression acceptance also requires tests showing that an all-sufficient multi-item
order deducts all items, exact availability reaches integer zero, an empty order is
accepted without mutation, and caller stock/orders remain unchanged. Existing JSON
validation tests and both public APIs must continue to pass. No new validation
expectations should be added.

### Required gates

Run with the prepared runtime:

```sh
"$CANARY_PYTHON" -m unittest discover -s tests -v
"$CANARY_PYTHON" hooks/pre-commit
```

Both commands must collect tests and exit successfully. Review the final diff for
scope and confirm `hooks/pre-commit` and `.git/hooks/pre-commit` remain unchanged and
matching. Then perform the authorized agent code review focused on mutation ordering,
contract preservation, and whether the decisive case would fail under the old
implementation. Record proposed checks as passed only after executing them.

No commit, push, version bump, release, external service, or human-review claim is
part of S1. The resulting tested diff and agent review are the handoff for subsequent
human review.

## Baseline evidence (planning phase)

On 2026-09-29, before product changes, both required commands passed all 6 existing
tests, and the supplied hook matched the installed `.git/hooks/pre-commit`. This
establishes a clean behavioral baseline only; the suite currently has no insufficient
inventory case and the engine still permits negative stock.
