# Reservation rejection extension

## Requested outcome

Extend the existing in-memory reservation utility so that each order is atomic with
respect to available stock. The current accepted behavior remains documented in
[ORIGINAL.md](ORIGINAL.md), and completed work remains recorded in
[history/completed.md](history/completed.md). The proposed decision is in
[DESIGN.md](DESIGN.md); the review and implementation handoff is in
[PLAN.md](PLAN.md).

This phase is planning only. An independent reviewer is next, followed by an
implementer after the planning artifacts are accepted. No product code has been
changed for this request.

## Original extension request (preserved)

Some callers now submit orders that exceed available inventory. Make reservation
reject such an order as a whole: if any requested item is insufficient, return
`accepted=False` for that order and leave all stock quantities unchanged by it.
Continue with later orders against the current remaining stock. Successful orders
still deduct all their items and return `accepted=True`. Preserve both current APIs,
JSON validation, result order, input immutability and integer counts. An empty order
is accepted without changing stock. Input shapes, positive quantities and known unique
SKUs are already validated; do not add new validation policies.

This is a single-process in-memory utility. Persistence, concurrency, a transaction
framework and remote infrastructure are outside this feature. We need the feature
ready for human review within 15 minutes of agent execution, including necessary
document/code reviews. Agent-only review is authorized while working; human review
happens afterward. No commit, push, version advancement or release is requested.

## Repository facts relevant to implementation

- `inventory.reserve(stock, orders)` copies `stock` once, processes orders in input
  order, and currently deducts every item immediately. It can therefore partially
  deduct an order and make counts negative when an item is insufficient.
- `batch.execute(stock, text)` preserves the JSON boundary by calling
  `command_codec.decode` before `inventory.reserve`.
- The adapter already enforces the stated shape, unique IDs, unique known SKUs, and
  positive integer quantities. Those policies are not part of this change.
- The supplied and installed pre-commit hooks match. At planning time, all 6 existing
  tests pass through both the prepared Python runtime and the hook. This is baseline
  evidence only; it does not demonstrate the requested rejection behavior.

## Required completion state

The implementation is complete only when the order that contains an insufficient
item has no stock effect, its result is rejected in its original position, and later
orders are still evaluated against stock left by earlier accepted orders. Existing
successful, empty-order, validation, API, ordering, integer-count, and input
immutability behavior must remain intact. The decisive scenario and checks are in
[PLAN.md](PLAN.md).
