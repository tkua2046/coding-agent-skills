# Design: atomic rejection per order

Status: proposed for independent review; not yet implemented.

This note extends accepted design D1 in [SPEC.md](SPEC.md). It does not alter D1's
JSON validation boundary or the completed S0 behavior recorded in
[history/completed.md](history/completed.md).

## Decision D2

`inventory.reserve` will test every item in an order against the current batch-local
`remaining` stock before deducting any item in that order.

- If every requested quantity is available, deduct all items and append
  `{"order_id": id, "accepted": True}`.
- If any requested quantity exceeds the corresponding remaining quantity, deduct
  nothing from that order and append
  `{"order_id": id, "accepted": False}`.
- Continue in input order, so every later order sees changes from earlier accepted
  orders and no changes from earlier rejected orders.
- An order with no items passes the all-items check, is accepted, and changes no
  stock.

The sufficiency check belongs in the reservation engine because availability changes
while the batch is processed. The existing adapter remains responsible for input
shape and value validation; adding validation to the engine or changing adapter
errors would expand the contract unnecessarily.

A precheck is preferable to deducting and rolling back. It prevents a rejected order
from ever creating partial batch-local state and needs no transaction abstraction or
recovery path. Processing is single-process and in-memory, so there is no externally
visible intermediate state.

## Decisive example

Given stock `{"a": 4, "b": 2}` and these orders in sequence:

1. `o1` requests `a: 2` and `b: 3`.
2. `o2` requests `a: 3`.

`o1` is rejected because `b` is insufficient. Its otherwise-satisfiable request for
`a` is not deducted. `o2` is then accepted, producing remaining stock
`{"a": 1, "b": 2}` and ordered results:

```python
[
    {"order_id": "o1", "accepted": False},
    {"order_id": "o2", "accepted": True},
]
```

This example distinguishes atomic rejection from the current line-by-line mutation,
and also proves that rejection does not stop the batch.

## Compatibility and failure behavior

Both public entrypoints and their return shapes remain unchanged:
`inventory.reserve(stock, orders)` and `batch.execute(stock, text)`. The engine still
copies the supplied stock and does not mutate the stock, orders, or nested item lists.
Accepted orders retain integer subtraction and may reduce stock exactly to zero.
Result count and order continue to match processed input orders.

For valid inputs, insufficient stock is a normal rejected result, not an exception.
Because the entire order is checked before mutation, rejection and a retry in a later
call begin from stock unaffected by that order. Existing JSON parse and validation
failures remain adapter errors raised before the engine runs. Behavior for bypassing
the adapter with invalid engine inputs remains outside the accepted contract.

Persistence, concurrency, remote coordination, transaction frameworks, new
validation, and release/version changes remain out of scope.
