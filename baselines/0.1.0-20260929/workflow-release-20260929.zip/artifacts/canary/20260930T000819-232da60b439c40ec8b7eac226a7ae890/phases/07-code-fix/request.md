Use skills/stage-development to verify and address current code review findings,
recheck affected behavior and the installed gate, and preserve earlier evidence.
The author must not change the independent review verdict to ready. Leave a concise
handoff for recheck. Do not commit, publish, or fabricate human acceptance.

The whole requested task has a 600-second usable-delivery target and a 900-second hard stop, including all required worker/reviewer/fix/check/handoff phases. This phase does not reset that allowance. The contractual clock sums actual worker invocation time, including model/tool waits and development reviews/fixes; separate evaluator reader/scorer and harness overhead are excluded and recorded separately. Preserve the supplied skill files and any installed required hook. Budgets are ceilings, not time to consume; preserve substantive requirements.
