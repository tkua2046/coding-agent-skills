This is already a fresh reviewer context, separate from the author. You are the
assigned independent reviewer; this role does not require spawning another reviewer.
Independently recheck the corrected implementation and affected invariants using
skills/stage-development's review operation. Read the current findings and actual
changed code/tests.
Write only review/evidence files. Write reviews/code-current.json with
{"verdict":"ready"|"needs-changes"|"needs-decision","findings":[...]}. Identify the
reviewed content, consequential findings and actual checks. Preserve previous reports.
Do not modify code or tests. Human acceptance remains pending; no commit is requested.

The whole requested task has a 600-second usable-delivery target and a 900-second hard stop, including all required worker/reviewer/fix/check/handoff phases. This phase does not reset that allowance. The contractual clock sums actual worker invocation time, including model/tool waits and development reviews/fixes; separate evaluator reader/scorer and harness overhead are excluded and recorded separately. Preserve the supplied skill files and any installed required hook. Budgets are ceilings, not time to consume; preserve substantive requirements.
