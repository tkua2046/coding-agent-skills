

Prospective diagnostic timing contract (applies to this two-phase run only):
Deliver the local release and retry inspection within 600 seconds of cumulative
worker execution; hard stop 900 seconds. Include model/tool waits, required
checks, artifact execution, both phases and readable reports. Evaluator and
harness overhead is recorded separately. Preserve all required work and scope.
