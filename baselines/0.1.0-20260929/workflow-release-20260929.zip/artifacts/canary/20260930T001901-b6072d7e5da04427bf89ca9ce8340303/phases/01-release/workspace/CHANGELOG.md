# Changelog

## Unreleased

## 1.2.0 - 2026-09-07

- Add opt-in JSON inventory summaries, preserving SKU strings and integer quantities including zero. Default CSV output remains compatible.

- Reject invalid inventory rows before producing any report.
