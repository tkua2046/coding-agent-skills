Local release `1.2.0` completed successfully.

- Commit: `910da7552f55b0833baf21dcd5865b4bca628ad2`
- Annotated tag: `v1.2.0`
- Artifact: `dist/inventory-report-1.2.0.pyz`
- SHA-256: `1c3b4ebabeb9f79198b8b3f070768a480dbe97fc1e4ebfc50ee95301a28c68e2`
- Tests: 3 passed
- Artifact CSV and JSON modes passed
- Invalid input exited `2` with empty stdout
- Offline local publication simulation completed
- Matching retry required no action; conflicting and uncertain retries were safely withheld
- No network, push, install, or hosted publication occurred
- Tracked worktree is clean

Full evidence and remaining scope: [reports/release.md](</private/var/folders/7w/2jmyflc53t3fhsxzmf590wk80000gn/T/canary-olc4c4q1/worker/reports/release.md>)