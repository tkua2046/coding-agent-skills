Use skills/dev-workflow to execute the local release described in DEVNOTES.md. Prepare the policy-selected version and notes dated 2026-09-07; review the final diff, make the coherent local release commit, run required checks on that candidate, tag it, build from the tag and validate the actual distributable including its failure behavior. Inspect and complete only the supplied offline publication simulation after artifact acceptance. Write reports/release.md with the result, identities, observed evidence and remaining scope. All these local actions are authorized. No installs, network, pushes or actual hosted publication. Reuse supplied commands; do not change application/tests/tools or implement audit tooling.


Prospective diagnostic timing contract (applies to this two-phase run only):
Deliver the local release and retry inspection within 600 seconds of cumulative
worker execution; hard stop 900 seconds. Include model/tool waits, required
checks, artifact execution, both phases and readable reports. Evaluator and
harness overhead is recorded separately. Preserve all required work and scope.


Use only this fixture and the supplied skills/. Read fixture AGENTS.md if present. This phase is a fresh context. Preserve prior reports. CANARY_PYTHON points to the prepared Python runtime. Do not install packages or use external services.

Workflow worker clock: 0.000s consumed; usable target remaining: 600.000s; hard budget remaining: 900.000s; this invocation cap: 600.000s.
