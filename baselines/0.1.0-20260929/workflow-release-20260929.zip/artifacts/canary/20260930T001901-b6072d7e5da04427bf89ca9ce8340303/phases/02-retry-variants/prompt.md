Retain reports/release.md. Run the supplied `python3 tools/publication.py seed-retries` once to create separate matching, conflicting and uncertain service namespaces for the released candidate. This setup is explicitly authorized; it seeds new tag names, not replacement releases. Inspect all three using the adapter and actual Git refs/artifact. Decide whether each is complete or blocked and what action remains; write reports/retries.md with evidence for each. Preserve every seeded tag and observation. Do not duplicate a completed publication, retry an uncertain/conflicting response, change the candidate, or perform any network action. No new release/commit/version is requested. Use skills/dev-workflow; the supplied adapter and existing Git/trace capture suffice.


Prospective diagnostic timing contract (applies to this two-phase run only):
Deliver the local release and retry inspection within 600 seconds of cumulative
worker execution; hard stop 900 seconds. Include model/tool waits, required
checks, artifact execution, both phases and readable reports. Evaluator and
harness overhead is recorded separately. Preserve all required work and scope.


Use only this fixture and the supplied skills/. Read fixture AGENTS.md if present. This phase is a fresh context. Preserve prior reports. CANARY_PYTHON points to the prepared Python runtime. Do not install packages or use external services.

Workflow worker clock: 151.719s consumed; usable target remaining: 448.281s; hard budget remaining: 748.281s; this invocation cap: 600.000s.
