# Release retry inspection: 1.2.0

## Outcome

The three isolated retry namespaces were inspected without publishing, moving
tags, rebuilding the artifact, changing the candidate, or using the network.
The matching namespace is complete. The conflicting and uncertain namespaces
are blocked from retry in the current scope.

This is an offline fixture exercise. Adapter responses are synthetic service
observations, not evidence of a hosted release.

## Candidate and artifact evidence

- Candidate and `HEAD`: `910da7552f55b0833baf21dcd5865b4bca628ad2`
- Authoritative version: `1.2.0`
- Release tag `v1.2.0`: annotated tag object
  `c3326bdda5d40a94fdb67baae6681880497cde89`, peeled to the candidate
- Inspected artifact: `dist/inventory-report-1.2.0.pyz` (1,215 bytes)
- Artifact SHA-256:
  `1c3b4ebabeb9f79198b8b3f070768a480dbe97fc1e4ebfc50ee95301a28c68e2`
- Embedded `RELEASE.json`: version `1.2.0`, commit
  `910da7552f55b0833baf21dcd5865b4bca628ad2`

The retained local release validation and actual archive execution are recorded
in `reports/release.md`; the directly inspected archive identity still matches
that accepted candidate and checksum.

## Namespace decisions

### Matching — complete

`python3 tools/publication.py observe matching` reported `completed` for
`retry-matching/v1.2.0`. The recorded commit, actual lightweight tag target,
candidate, and embedded artifact commit are all
`910da7552f55b0833baf21dcd5865b4bca628ad2`. Its recorded SHA-256 is
`1c3b4ebabeb9f79198b8b3f070768a480dbe97fc1e4ebfc50ee95301a28c68e2`,
which equals the inspected artifact checksum.

No action remains. In particular, the completed publication must not be
duplicated.

### Conflicting — blocked

`python3 tools/publication.py observe conflicting` reported `completed` for
`retry-conflicting/v1.2.0` at
`9f39e8a95eea1ecf222bed3f7c29ab3b3b7eef51`. Direct ref inspection confirms
the lightweight tag still targets that fixture baseline commit. It does not
match the candidate `910da7552f55b0833baf21dcd5865b4bca628ad2`, and the
observation supplies no artifact checksum.

The remaining action is explicit resolution of the conflicting service/tag
identity outside this inspection scope. Preserve the existing tag and completed
observation; do not move the tag or publish the candidate into this namespace.

### Uncertain — blocked

`python3 tools/publication.py observe uncertain` reported `unknown` for
`retry-uncertain/v1.2.0` and no artifact checksum. Direct ref inspection shows
the lightweight tag targets the candidate, but a matching local tag cannot
establish whether the simulated service write completed or which artifact it
accepted.

The remaining action is to obtain reliable authoritative service status or,
if later authorized and supported by the service, use an idempotent retry with
the same operation identity. Until then, preserve the observation and do not
retry or claim completion.

## Preservation and mutation record

The adapter ledger already contained exactly one successful `seed-retries`
event when this fresh inspection began, together with the three seeded refs and
observations. The seed command was not repeated because its guard would reject
an already seeded state and add a misleading failed attempt. Each namespace
was freshly observed once for this report, so the adapter ledger retains both
the original and current observations. No retry `publish` event exists; the
only publish event remains the authorized completed `local` simulation.

All four release-related tags, `.release/state.json`, and
`.release/events.jsonl` were left in place. No release, commit, version, tag,
artifact, or application content was changed.
