# Priority-canary evidence archive

Start at repo/artifacts/priority-canary-migration/results.md (brief) or results.json
(all run identities/settings). This archive preserves all ten raw calibration and
worker run directories from the selected migration, including failed/incomplete
attempts; reviewed proposals, original expectations, source snapshots, current
maintained source, gate logs and independent reviews are included. The unchanged
small local skill bundle is included for the recorded byte comparison.

Original case/engine/control files are under before/ and scoring-round-1/source/.
Later documentation-original reconstruction is explicitly labeled in
before-late-docs/provenance.json; it is not presented as a pre-edit capture.

manifest.json binds every payload by SHA-256, including symlink targets and mode.
The adjacent outer .sha256 file binds this ZIP. A symlink-aware unzip preserves
repo/.agents discovery links. Python ZipFile.extractall does not restore symlinks.
Raw records preserve their original absolute environment paths; they are historical
observations, not an assurance of portability or a current full release gate.

Excluded: .git history, virtual environments, interpreter caches and OS metadata.
Raw run JSON, replies, produced workspaces, originals and failures are retained.
Source is the local uncommitted candidate; no commit/push or release was performed.
