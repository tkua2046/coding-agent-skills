# Current contract
Unbounded grid, integer coordinates, clockwise headings 0 through 3. F advances;
L/R turn in place. Unknown commands raise ValueError. No persistence or pathfinding.
Occupied forward targets report False, preserve the pose at that command, and stop
the batch. Return outcomes through that failed command only; commands after it are
not attempted. Unknown commands therefore raise ValueError only if reached before
the batch stops.
