# Plan
Complete: basic translation and turns, accepted as D1. Existing navigation tests
cover turns and movement. No pending stages before this feature request.

Complete: occupied cells with preserved pose and batch continuation (D2).

Next undelivered outcome: change navigation batches to stop at the first blocked
forward move, as accepted in D3. The confirmed contract is the prerequisite; no
adapter work should proceed against D2 continuation semantics. Acceptance: FRF
from (0,0,0) with (0,1) occupied returns (0,0,0) and [False], and commands after
the failure have no effects or outcomes. RFF from (0,0,0) with (1,0) occupied
returns (0,0,1) and [True, False], retaining the successful turn before the block.
A reached unknown command still raises ValueError, while an unknown command after
a block is not attempted. Existing successful movement, turning,
negative-coordinate blocking, and occupied-input behavior remain compatible. Run
the navigator suite before review.

Pending after that outcome: expose batch outcomes in the text adapter using D3's
truncated outcome list. Add the adapter integration acceptance when the adapter's
interface is defined; no adapter implementation is part of the current stage.
