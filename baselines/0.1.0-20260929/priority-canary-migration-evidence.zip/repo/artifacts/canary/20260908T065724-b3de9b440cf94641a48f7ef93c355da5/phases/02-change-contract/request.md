The fixture user has now confirmed a public behavior change: a blocked forward
move stops the command batch immediately. Return the unchanged pose and the
outcomes through that failed command; omit outcomes for commands not attempted.
The confirmation is preserved in docs/STOP_REQUEST.md. Use skills/feature-design
and skills/implementation-plan to revise the affected current contract, design,
acceptance and pending work. This phase is planning only: implementation follows
later. Preserve prior requests and completed-stage history. No commits or
external actions.

This phase has a 300-second usable-delivery target and a 600-second hard stop, including relevant checks and final editing. Both phases together have a 600-second target and a 1200-second hard stop. The contractual clock sums actual worker invocation time, including model/tool waits and development reviews/fixes; separate evaluator reader/scorer and harness overhead are excluded and recorded separately. Preserve the supplied skill files and any installed required hook. Budgets are ceilings, not time to consume; preserve substantive requirements.
