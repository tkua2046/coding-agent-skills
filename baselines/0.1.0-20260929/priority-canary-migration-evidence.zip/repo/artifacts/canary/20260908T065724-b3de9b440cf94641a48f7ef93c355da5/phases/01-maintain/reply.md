Renamed private `_target` to `_next_pose` in [navigator.py](/private/var/folders/7w/2jmyflc53t3fhsxzmf590wk80000gn/T/canary-r8mf72vh/worker/navigator.py:4).

Added the west-facing blocked move regression at a negative coordinate in [test_navigator.py](/private/var/folders/7w/2jmyflc53t3fhsxzmf590wk80000gn/T/canary-r8mf72vh/worker/tests/test_navigator.py:23).

Checks:

- New regression: passed
- Full suite: 5/5 passed
- `git diff --check`: passed
- Old `_target` references: none

No records changed, no commit was created, and the pending adapter stage was not advanced.