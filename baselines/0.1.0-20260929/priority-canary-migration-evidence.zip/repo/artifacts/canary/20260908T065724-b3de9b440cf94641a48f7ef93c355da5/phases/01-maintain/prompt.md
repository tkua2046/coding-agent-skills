Use skills/stage-development for this bounded maintenance task. Rename the
private _target helper to _next_pose and add a regression test for a blocked
forward move while facing west at a negative coordinate. Public behavior must
stay the same. Run the relevant checks and update only records whose owned facts
changed. Do not commit or advance the pending adapter stage. No external actions.

This phase has a 300-second usable-delivery target and a 600-second hard stop, including relevant checks and final editing. Both phases together have a 600-second target and a 1200-second hard stop. The contractual clock sums actual worker invocation time, including model/tool waits and development reviews/fixes; separate evaluator reader/scorer and harness overhead are excluded and recorded separately. Preserve the supplied skill files and any installed required hook. Budgets are ceilings, not time to consume; preserve substantive requirements.


Use only this fixture and the supplied skills/. Read fixture AGENTS.md if present. This phase is a fresh context. Preserve prior reports. CANARY_PYTHON points to the prepared Python runtime. Do not install packages or use external services.

Workflow worker clock: 0.000s consumed; usable target remaining: 600.000s; hard budget remaining: 1200.000s; this invocation cap: 600.000s.
