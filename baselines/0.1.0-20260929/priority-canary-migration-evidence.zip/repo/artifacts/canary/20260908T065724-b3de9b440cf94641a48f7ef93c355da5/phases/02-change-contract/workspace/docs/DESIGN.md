# Accepted design D1
Keep state local to each run; no global session. A caller supplies pose and commands.
A direction lookup supports translation; turns only affect heading. Unbounded
coordinates avoid imposing a board size. Unknown commands are programmer errors.

Accepted D2: use a set for occupied coordinates; check before assigning pose.
A blocked F emits False and continues. For FRF with (0,1) occupied, finish at
(1,0,1) with [False, True, True].

Accepted D3 supersedes only D2's continue-after-block choice: process commands in
order and return immediately after a blocked F appends False. The pose remains the
one established by commands before the failed move, and no outcome is created for
later commands. This makes the outcomes an exact record of attempted commands and
prevents turns or moves after the failure from changing the returned pose. For FRF
with (0,1) occupied, finish at (0,0,0) with [False]. An unknown command after that
blocked F is not reached; an unknown command reached before a block still raises
ValueError. Callers that relied on D2's continuation must submit a new batch if
they want to proceed from the returned pose.
