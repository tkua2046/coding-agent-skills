Updated the planning artifacts:

- [SPEC.md](/private/var/folders/7w/2jmyflc53t3fhsxzmf590wk80000gn/T/canary-r8mf72vh/worker/docs/SPEC.md) — fail-fast batch contract and reached-command semantics.
- [DESIGN.md](/private/var/folders/7w/2jmyflc53t3fhsxzmf590wk80000gn/T/canary-r8mf72vh/worker/docs/DESIGN.md) — D3 supersedes D2 continuation while preserving D2 history.
- [PLAN.md](/private/var/folders/7w/2jmyflc53t3fhsxzmf590wk80000gn/T/canary-r8mf72vh/worker/docs/PLAN.md) — next implementation outcome, decisive acceptance examples, compatibility, and deferred adapter work.

Checks:

- `git diff --check`: passed.
- Existing suite: 5 tests passed. It still tests D2 continuation, so this is baseline evidence—not D3 acceptance.

No implementation, commits, external actions, history edits, skill changes, or hook changes were made.