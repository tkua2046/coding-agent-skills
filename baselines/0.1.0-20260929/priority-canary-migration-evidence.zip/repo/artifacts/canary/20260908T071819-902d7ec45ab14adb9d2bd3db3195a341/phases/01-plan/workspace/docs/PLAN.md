# Implementation plan

## Next outcome: S1 atomic insufficient-order rejection

Implement [D2](DESIGN.md#d2-atomic-acceptance-per-order) as one coherent increment.
The existing S0 engine and adapter are the only prerequisites and are already
delivered; their completion record remains in [history/completed.md](history/completed.md).

Change the reservation engine so each order is checked against current remaining
stock before any of its items are deducted. Extend the tests through both supported
APIs to cover an insufficient multi-item order, no partial deduction, a later order
that can consume the preserved stock, successful deduction, empty-order acceptance,
ordered outcomes, and caller-input preservation. Keep the existing JSON validation
contract intact. Update README usage text to remove the obsolete caller-sufficiency
requirement and describe rejection behavior; no operational, dependency, version,
commit, or release work is part of S1.

S1 is accepted decisively when:

- with stock `{"a": 4, "b": 1}`, an order requesting `a: 3, b: 2` returns
  `accepted=False` without changing either quantity, and a following order requesting
  `a: 4` returns `accepted=True`, leaving `{"a": 0, "b": 1}`;
- sufficient and empty orders remain accepted, each successful order deducts all of
  its items, results remain in input order, and stock/order inputs remain unchanged;
- both `inventory.reserve` and `batch.execute` retain their signatures and return
  shapes, and the adapter continues rejecting the already-invalid JSON cases without
  any new validation rules; and
- the repository gate passes using the prepared runtime:
  `"$CANARY_PYTHON" hooks/pre-commit`.

## Current evidence and handoff

Planning only: S1 is not implemented. On 2026-09-08, the existing six tests passed
with both `"$CANARY_PYTHON" -m unittest discover -s tests -v` and the supplied
pre-commit hook. Those tests establish a clean baseline but do not cover insufficient
inventory. The next action is independent review of this design and plan, followed
by implementation of S1 and the gate above. Human review remains afterward as
requested.
