# Implementation plan

## Next outcome: S1 atomic insufficient-order rejection

Implement [D2](DESIGN.md#d2-atomic-acceptance-per-order) as one coherent increment.
The existing S0 engine and adapter are the only prerequisites and are already
delivered; their completion record remains in [history/completed.md](history/completed.md).

Change the reservation engine so each order is checked against current remaining
stock before any of its items are deducted. Extend the tests through both supported
APIs to cover an insufficient multi-item order, no partial deduction, a later order
that can consume the preserved stock, successful deduction, empty-order acceptance,
ordered outcomes, and caller-input preservation. Keep the existing JSON validation
contract intact. Update README usage text to remove the obsolete caller-sufficiency
requirement and describe rejection behavior; no operational, dependency, version,
commit, or release work is part of S1.

S1 is accepted decisively when:

- with stock `{"a": 4, "b": 1}`, an order requesting `a: 3, b: 2` returns
  `accepted=False` without changing either quantity, and a following order requesting
  `a: 4` returns `accepted=True`, leaving `{"a": 0, "b": 1}`;
- sufficient and empty orders remain accepted, each successful order deducts all of
  its items, results remain in input order, and stock/order inputs remain unchanged;
- both `inventory.reserve` and `batch.execute` retain their signatures and return
  shapes, and the adapter continues rejecting the already-invalid JSON cases without
  any new validation rules; and
- the repository gate passes using the prepared runtime:
  `"$CANARY_PYTHON" hooks/pre-commit`.

## Current evidence and handoff

S1 is implemented in the current uncommitted worktree. `inventory.reserve` preflights
each order against current remaining stock and deducts only accepted orders. Tests
cover the atomic insufficient multi-item case through both APIs, continued processing,
successful and empty orders, ordered results, input preservation, and the existing
validation cases. README documents the caller-visible behavior.

On 2026-09-08, both exact checks passed using the prepared runtime, each collecting
and passing eight tests:

- `"$CANARY_PYTHON" -m unittest discover -s tests -v`
- `"$CANARY_PYTHON" hooks/pre-commit`

The earlier independent design/plan review remains recorded in
`reviews/design-plan-review-2026-09-08.md` with a ready verdict and no open findings.
Independent implementation review and subsequent human review remain pending. No
commit, release, version change, dependency installation, or external service action
was performed.
