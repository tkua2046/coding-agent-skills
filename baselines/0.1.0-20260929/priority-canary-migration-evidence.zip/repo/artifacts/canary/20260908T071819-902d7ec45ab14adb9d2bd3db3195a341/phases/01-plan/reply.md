Prepared the implementation handoff:

- [docs/DESIGN.md](/private/var/folders/7w/2jmyflc53t3fhsxzmf590wk80000gn/T/canary-w4lnck74/worker/docs/DESIGN.md) defines atomic per-order rejection, compatibility, state behavior, and a decisive example.
- [docs/PLAN.md](/private/var/folders/7w/2jmyflc53t3fhsxzmf590wk80000gn/T/canary-w4lnck74/worker/docs/PLAN.md) defines the single S1 increment, acceptance criteria, documentation impact, gate, and reviewer/implementer handoff.

The original request, completed S0 history, supplied skills, and hook were preserved. No implementation changes were made.

Baseline verification: all 6 existing tests pass through `"$CANARY_PYTHON" hooks/pre-commit`. The plan explicitly notes that insufficient-inventory behavior is not yet covered or implemented.