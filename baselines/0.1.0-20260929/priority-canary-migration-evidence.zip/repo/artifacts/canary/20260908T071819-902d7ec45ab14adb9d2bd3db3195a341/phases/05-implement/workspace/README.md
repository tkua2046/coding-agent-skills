# Batch inventory reservation
Call `batch.execute({"a": 4}, '[{"id":"o1","items":[["a",2]]}]')` to obtain
remaining inventory and an ordered acceptance result for each order. The Python API
is `inventory.reserve(stock, orders)`. Each order is accepted and deducted only when
all its items are available; otherwise it is rejected without changing stock, and
later orders continue against the remaining inventory. Empty orders are accepted.
Caller input is preserved. JSON validation rejects unknown/duplicate SKUs and
nonpositive/noninteger quantities before execution. See DEVNOTES.md for checks.
