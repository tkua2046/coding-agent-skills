Review recorded with verdict `ready`; implementation can begin.

- [Review record](/private/var/folders/7w/2jmyflc53t3fhsxzmf590wk80000gn/T/canary-w4lnck74/worker/reviews/design-plan-review-2026-09-08.md)
- [Runner interface](/private/var/folders/7w/2jmyflc53t3fhsxzmf590wk80000gn/T/canary-w4lnck74/worker/reviews/design-current.json)