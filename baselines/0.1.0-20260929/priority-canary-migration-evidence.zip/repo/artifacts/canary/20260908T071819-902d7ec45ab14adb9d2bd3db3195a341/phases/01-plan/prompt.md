Use skills/feature-design and skills/implementation-plan to prepare docs/REQUEST.md
for implementation in this existing project. Choose documentation and review depth
appropriate to the task. Preserve the original requirements and completed work.
Keep docs/DESIGN.md and docs/PLAN.md as the entrypoints (one can link to a combined
note if useful). Establish behavior, decisions, next outcome and decisive acceptance.
Inspect the existing implementation and baseline checks. This phase plans only;
an independent reviewer and then an implementer follow. Budget is the 15-minute
whole-task allowance in the original request, not a target to consume.

The whole requested task has a 600-second usable-delivery target and a 900-second hard stop, including all required worker/reviewer/fix/check/handoff phases. This phase does not reset that allowance. The contractual clock sums actual worker invocation time, including model/tool waits and development reviews/fixes; separate evaluator reader/scorer and harness overhead are excluded and recorded separately. Preserve the supplied skill files and any installed required hook. Budgets are ceilings, not time to consume; preserve substantive requirements.


Use only this fixture and the supplied skills/. Read fixture AGENTS.md if present. This phase is a fresh context. Preserve prior reports. CANARY_PYTHON points to the prepared Python runtime. Do not install packages or use external services.

Workflow worker clock: 0.000s consumed; usable target remaining: 600.000s; hard budget remaining: 900.000s; this invocation cap: 600.000s.
