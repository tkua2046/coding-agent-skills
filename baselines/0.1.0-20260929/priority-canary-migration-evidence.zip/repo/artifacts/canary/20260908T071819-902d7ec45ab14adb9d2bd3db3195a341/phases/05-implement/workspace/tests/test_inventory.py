import unittest
from inventory import reserve
from batch import execute

class InventoryTests(unittest.TestCase):
    def test_success_and_input_preservation(self):
        stock = {"a": 4, "b": 2}
        orders = [{"id": "o1", "items": [["a", 2], ["b", 1]]}]
        self.assertEqual(
            reserve(stock, orders),
            ({"a": 2, "b": 1}, [{"order_id": "o1", "accepted": True}]),
        )
        self.assertEqual(stock, {"a": 4, "b": 2})
        self.assertEqual(orders, [{"id": "o1", "items": [["a", 2], ["b", 1]]}])

    def test_insufficient_order_is_atomic_and_later_orders_continue(self):
        stock = {"a": 4, "b": 1}
        orders = [
            {"id": "rejected", "items": [["a", 3], ["b", 2]]},
            {"id": "accepted", "items": [["a", 4]]},
            {"id": "empty", "items": []},
        ]
        expected_orders = [
            {"id": "rejected", "items": [["a", 3], ["b", 2]]},
            {"id": "accepted", "items": [["a", 4]]},
            {"id": "empty", "items": []},
        ]
        self.assertEqual(
            reserve(stock, orders),
            (
                {"a": 0, "b": 1},
                [
                    {"order_id": "rejected", "accepted": False},
                    {"order_id": "accepted", "accepted": True},
                    {"order_id": "empty", "accepted": True},
                ],
            ),
        )
        self.assertEqual(stock, {"a": 4, "b": 1})
        self.assertEqual(orders, expected_orders)

    def test_empty(self):
        self.assertEqual(reserve({"a": 2}, []), ({"a": 2}, []))

    def test_adapter(self):
        self.assertEqual(
            execute({"a": 4}, '[{"id":"o","items":[["a",1]]}]'),
            ({"a": 3}, [{"order_id": "o", "accepted": True}]),
        )

    def test_adapter_rejects_whole_insufficient_order(self):
        stock = {"a": 4, "b": 1}
        text = (
            '[{"id":"o1","items":[["a",3],["b",2]]},'
            '{"id":"o2","items":[["a",4]]},{"id":"o3","items":[]}]'
        )
        self.assertEqual(
            execute(stock, text),
            (
                {"a": 0, "b": 1},
                [
                    {"order_id": "o1", "accepted": False},
                    {"order_id": "o2", "accepted": True},
                    {"order_id": "o3", "accepted": True},
                ],
            ),
        )
        self.assertEqual(stock, {"a": 4, "b": 1})

    def test_unknown_sku(self):
        with self.assertRaises(ValueError):
            execute({"a": 4}, '[{"id":"o","items":[["missing",1]]}]')

    def test_duplicate_sku(self):
        with self.assertRaises(ValueError):
            execute({"a": 4}, '[{"id":"o","items":[["a",1],["a",2]]}]')

    def test_bad_quantity(self):
        with self.assertRaises(ValueError):
            execute({"a": 4}, '[{"id":"o","items":[["a",true]]}]')
