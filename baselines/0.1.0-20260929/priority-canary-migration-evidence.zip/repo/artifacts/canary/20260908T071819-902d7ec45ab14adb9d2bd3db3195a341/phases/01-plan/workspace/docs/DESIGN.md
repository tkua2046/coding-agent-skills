# Reservation design

The accepted boundary and state model from D1 remain unchanged: the JSON adapter
validates shapes, positive integer quantities, unique order IDs, and unique known
SKUs within each order. The engine trusts those inputs, copies stock once for
batch-local mutation, returns one ordered boolean result per order, and does not
mutate caller-owned stock or orders.

## D2: atomic acceptance per order

This decision supersedes only D1's former assumption that callers guarantee
sufficient inventory.

For each order, `inventory.reserve` first compares every requested quantity with
the corresponding quantity in the current batch-local stock. It deducts all items
only when every comparison succeeds. If any item is insufficient, it deducts none,
returns `accepted=False` for that order, and evaluates the next order against the
unchanged stock left by earlier accepted orders.

This preflight-then-apply choice makes the order the atomic unit without introducing
rollback bookkeeping or a transaction abstraction. It also preserves integer stock
counts and the existing APIs and result order. An empty order passes the universal
sufficiency check, is accepted, and changes no stock.

For example, given stock `{"a": 4, "b": 1}` and these ordered requests:

1. `o1` requests `a: 3, b: 2`; it is rejected and stock remains `a: 4, b: 1`.
2. `o2` requests `a: 4`; it is accepted and stock becomes `a: 0, b: 1`.

The second result demonstrates both all-or-nothing rejection and continued ordered
processing. Earlier successful orders still constrain later orders in the usual way.

No new validation policy belongs in the engine or adapter. Persistence, concurrency,
remote effects, and a transaction framework remain outside the design. Because all
state is local to one call and rejected orders perform no mutation, rejection leaves
an immediately usable state; callers may submit a later order or retry in a later
call using whichever returned stock they choose. An interrupted call has no external
state to recover.
