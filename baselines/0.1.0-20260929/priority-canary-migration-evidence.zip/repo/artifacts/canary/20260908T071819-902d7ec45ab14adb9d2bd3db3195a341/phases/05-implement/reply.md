Implemented atomic order reservation.

- Insufficient orders are rejected without deducting any stock; later orders continue normally.
- Successful and empty orders remain accepted.
- Added coverage through both APIs for atomicity, ordering, continued processing, validation, and input immutability.
- Updated [README.md](/private/var/folders/7w/2jmyflc53t3fhsxzmf590wk80000gn/T/canary-w4lnck74/worker/README.md) and recorded reviewer handoff/evidence in [docs/PLAN.md](/private/var/folders/7w/2jmyflc53t3fhsxzmf590wk80000gn/T/canary-w4lnck74/worker/docs/PLAN.md).

Checks passed:

- `"$CANARY_PYTHON" -m unittest discover -s tests -v` — 8/8 tests
- `"$CANARY_PYTHON" hooks/pre-commit` — 8/8 tests
- `git diff --check` — exit 0
- Installed and supplied hooks remain identical

The design/plan review is resolved as ready with no open findings. Independent implementation review and human review remain pending. No commit, dependency installation, release, or hook modification was performed.