Use skills/feature-design and skills/implementation-plan to address the current
document review against the original request. Verify each concern before applying
a correction; preserve valid decisions and prior review evidence. Make only necessary
changes. The author may record fixes but must leave the reviewer verdict unchanged
until independent recheck. This phase does not implement code.

The whole requested task has a 600-second usable-delivery target and a 900-second hard stop, including all required worker/reviewer/fix/check/handoff phases. This phase does not reset that allowance. The contractual clock sums actual worker invocation time, including model/tool waits and development reviews/fixes; separate evaluator reader/scorer and harness overhead are excluded and recorded separately. Preserve the supplied skill files and any installed required hook. Budgets are ceilings, not time to consume; preserve substantive requirements.
