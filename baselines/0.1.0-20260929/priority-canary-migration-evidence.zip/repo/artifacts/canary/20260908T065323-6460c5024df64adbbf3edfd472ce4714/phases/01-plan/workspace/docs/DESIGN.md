# Accepted design D1
Keep state local to each run; no global session. A caller supplies pose and commands.
A direction lookup supports translation; turns only affect heading. Unbounded
coordinates avoid imposing a board size. Unknown commands are programmer errors.

# Design amendment D2: fixed occupied cells
Status: ready for the requested design review; review is pending.

Extend the call as `run(pose, commands, occupied=())`, where `occupied` is an
iterable of `(x, y)` cells. Omitting it is equivalent to supplying an empty iterable,
so existing callers retain D1 behavior. Copy the supplied cells into run-local state
at entry. The navigator neither mutates the caller's collection nor carries it
between runs; this snapshot makes "fixed" mean that occupancy cannot change partway
through a command sequence.

For `F`, compute the adjacent coordinate using the current heading before changing
the pose. If that coordinate is occupied, append `False`, retain both the position
and heading, and continue with the next command. Otherwise move and append `True`.
`L` and `R` never consult occupancy and continue to turn successfully in place.
Unknown commands retain D1's `ValueError` behavior.

For example, with `(0, 1)` occupied, running from `(0, 0, 0)` with `"FRF"`
produces `(1, 0, 1)` and `[False, True, True]`: the first forward command is
blocked, the right turn still succeeds, and the final forward command moves east.

Occupancy constrains entry into a cell, not the validity of the supplied starting
pose. A run that starts on an occupied coordinate may turn or move out of it. This
keeps the extension focused on the requested forward-move rule and avoids adding
pose validation. Because all state remains local and a blocked move is represented
in the normal result, interruption or retry introduces no persistent cleanup or
recovery requirement.
