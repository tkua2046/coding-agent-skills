# Current behavior
Unbounded grid, integer coordinates, clockwise headings 0 through 3. F advances;
L/R turn in place. Unknown commands raise ValueError. No persistence or pathfinding.

# Occupied-cell addendum
This addendum defines the accepted target behavior; implementation is pending.

- The public call is `run(pose, commands, occupied=())`; `occupied` is an iterable
  of `(x, y)` coordinates. With no occupied argument, behavior and return shape
  remain unchanged.
- Occupied cells are fixed for the duration of one call and are not modified by the
  navigator.
- Before each `F`, the destination coordinate is checked. If occupied, the command
  returns `False`, position and heading are unchanged, and command processing
  continues. If unoccupied, the move occurs and the command returns `True`.
- `L` and `R` always turn in place and return `True`, including while the current
  coordinate is listed as occupied.
- Occupancy does not reject the initial pose. Unknown commands continue to raise
  `ValueError`. No routing, persistence, moving obstacles, board boundary, or
  configuration-file behavior is added.
