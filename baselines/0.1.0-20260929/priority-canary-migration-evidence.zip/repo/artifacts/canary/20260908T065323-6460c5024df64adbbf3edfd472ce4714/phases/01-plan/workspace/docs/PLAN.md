# Plan
Complete: basic translation and turns, accepted as D1. Existing navigation tests
cover turns and movement.

## Pending stage S1: fixed occupied cells
Status: implementation pending. The requested plan review is also pending and must
not be treated as performed by this planning pass.

Prerequisite: design amendment D2 and the occupied-cell addendum in `docs/SPEC.md`.
No package, service, migration, or persistent-state dependency is required.
Before implementation, perform the requested design and plan reviews and resolve
any material findings; neither review has been performed in this phase.

Deliver one coherent increment:

1. Extend the public `run` call compatibly with optional per-run occupied cells.
2. Enforce blocked-forward behavior while preserving successful moves, turns,
   unknown-command errors, result shape, and continued command processing.
3. Add focused automated coverage for a blocked forward move preserving the full
   pose, commands continuing after failure, turns while occupied, movement out of
   an occupied starting cell, and omitted/empty occupancy retaining current behavior.
4. Update `README.md` usage for the optional argument; update `DEVNOTES.md` only if
   the operational check command changes.

Acceptance requires the repository check
`python3 -m unittest discover -s tests -v` to pass with both the existing regression
coverage and the new occupied-cell cases. A decisive scenario is the D2 example:
from `(0, 0, 0)`, commands `"FRF"`, and occupied `{(0, 1)}` must return
`((1, 0, 1), [False, True, True])`. Existing two-argument calls must produce their
unchanged results, and an unknown command must still raise `ValueError`.

After implementation and checks, record S1 as complete in the historical progress
record. Design and plan reviews remain separate pending actions until a reviewer
actually performs them.
