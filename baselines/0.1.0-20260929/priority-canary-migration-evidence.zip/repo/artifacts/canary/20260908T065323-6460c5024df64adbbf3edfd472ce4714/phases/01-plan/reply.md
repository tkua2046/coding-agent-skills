Amended the accepted design and implementation plan without changing code:

- [DESIGN.md](/private/var/folders/7w/2jmyflc53t3fhsxzmf590wk80000gn/T/canary-gwg7uiu3/worker/docs/DESIGN.md:6) — compatible `occupied=()` API, snapshot ownership, blocked-move semantics, continuation behavior, and example.
- [SPEC.md](/private/var/folders/7w/2jmyflc53t3fhsxzmf590wk80000gn/T/canary-gwg7uiu3/worker/docs/SPEC.md:5) — occupied-cell behavioral addendum.
- [PLAN.md](/private/var/folders/7w/2jmyflc53t3fhsxzmf590wk80000gn/T/canary-gwg7uiu3/worker/docs/PLAN.md:5) — one pending implementation stage, coverage, documentation, and acceptance criteria.

Verification:

- Existing baseline suite passes: 3 tests.
- `git diff --check` reported no content issues.
- Design and plan reviews remain explicitly pending.
- No implementation, dependency installation, commit, or external action was performed.