Use skills/feature-design to amend the accepted design and skills/implementation-plan
to plan docs/OCCUPIED_REQUEST.md against this repository. Inspect the existing code
and checks. Keep implementation for a later task. Write the affected design/plan
and any necessary specification addendum. Local evidence files are allowed. Do not
commit, install dependencies, or perform external actions. Requested design and
plan reviews remain pending until actually performed.

The whole requested task has a 300-second usable-delivery target and a 600-second hard stop, including all required worker/reviewer/fix/check/handoff phases. This phase does not reset that allowance. The contractual clock sums actual worker invocation time, including model/tool waits and development reviews/fixes; separate evaluator reader/scorer and harness overhead are excluded and recorded separately. Preserve the supplied skill files and any installed required hook. Budgets are ceilings, not time to consume; preserve substantive requirements.


Use only this fixture and the supplied skills/. Read fixture AGENTS.md if present. This phase is a fresh context. Preserve prior reports. CANARY_PYTHON points to the prepared Python runtime. Do not install packages or use external services.

Workflow worker clock: 0.000s consumed; usable target remaining: 300.000s; hard budget remaining: 600.000s; this invocation cap: 600.000s.
