1. The `run` operation is being extended with optional fixed occupied cells. A forward command into an occupied cell returns `False` and leaves position and heading unchanged, while later commands continue. Existing two-argument behavior, successful movement, in-place turns, result shape, and `ValueError` for unknown commands must remain unchanged.

2. Occupied cells are copied into run-local state when `run` begins. This prevents mutation of the caller’s collection, avoids state leaking between runs, and ensures occupancy cannot change during a command sequence. The design intentionally does not validate whether the starting pose is occupied, so a navigator may turn or move out of an occupied starting cell.

3. The next unfinished outcome is stage S1: implement fixed occupied-cell behavior with focused tests and README documentation. It depends on design amendment D2, the occupied-cell addendum in `docs/SPEC.md`, and completion of the pending design and plan reviews. A decisive acceptance case is:

   `run((0, 0, 0), "FRF", {(0, 1)})` → `((1, 0, 1), [False, True, True])`