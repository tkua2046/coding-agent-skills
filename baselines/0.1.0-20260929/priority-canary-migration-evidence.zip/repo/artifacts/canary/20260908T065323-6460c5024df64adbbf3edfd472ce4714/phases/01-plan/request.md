Use skills/feature-design to amend the accepted design and skills/implementation-plan
to plan docs/OCCUPIED_REQUEST.md against this repository. Inspect the existing code
and checks. Keep implementation for a later task. Write the affected design/plan
and any necessary specification addendum. Local evidence files are allowed. Do not
commit, install dependencies, or perform external actions. Requested design and
plan reviews remain pending until actually performed.

The whole requested task has a 300-second usable-delivery target and a 600-second hard stop, including all required worker/reviewer/fix/check/handoff phases. This phase does not reset that allowance. The contractual clock sums actual worker invocation time, including model/tool waits and development reviews/fixes; separate evaluator reader/scorer and harness overhead are excluded and recorded separately. Preserve the supplied skill files and any installed required hook. Budgets are ceilings, not time to consume; preserve substantive requirements.
